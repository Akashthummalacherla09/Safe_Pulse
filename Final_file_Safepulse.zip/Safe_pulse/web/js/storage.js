const DB = {
    // Keys
    USERS: 'safepulse_users',
    REPORTS: 'safepulse_reports',
    SESSION: 'safepulse_current_user',
    ADMIN_SESSION: 'safepulse_admin_active',
    API_BASE: 'https://sized-carita-flowerless.ngrok-free.dev/api/',

    // Initialization
    init() {
        if (!localStorage.getItem(this.REPORTS)) {
            localStorage.setItem(this.REPORTS, JSON.stringify([]));
        }
    },

    getCurrentUser() {
        return JSON.parse(localStorage.getItem(this.SESSION));
    },

    isAdmin() {
        return localStorage.getItem(this.ADMIN_SESSION) === 'true';
    },

    // API Helpers
    async fetchWithAuth(endpoint, method = 'GET', body = null) {
        const user = this.getCurrentUser();
        if (!user || !user.token) return { success: false, message: 'Unauthorized' };

        try {
            const options = {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Token ${user.token}`,
                    'ngrok-skip-browser-warning': 'true'
                }
            };
            if (body) options.body = JSON.stringify(body);

            const response = await fetch(this.API_BASE + endpoint, options);
            if (response.status === 401) {
                this.logout();
                return { success: false, message: 'Session Expired' };
            }
            if (response.status === 204) return { success: true, data: [] };
            const data = await response.json();
            return { success: response.ok, data };
        } catch (e) {
            console.error('API Error:', e);
            return { success: false, message: 'Network Failure' };
        }
    },

    async login(username, password) {
        try {
            const response = await fetch(this.API_BASE + 'login/', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();
            if (response.ok && data.token) {
                const userSession = {
                    id: data.user_id,
                    name: data.name || data.username,
                    email: data.email,
                    role: data.role,
                    token: data.token
                };
                localStorage.setItem(this.SESSION, JSON.stringify(userSession));
                localStorage.removeItem(this.REPORTS); // Clear stale cache
                return { success: true, user: userSession };
            }
            return { success: false, message: data.error || 'Invalid Credentials' };
        } catch (e) {
            console.error('Login Error:', e);
            return { success: false, message: 'Server Unreachable' };
        }
    },

    async register(name, email, password) {
        try {
            const response = await fetch(this.API_BASE + 'register/', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                },
                body: JSON.stringify({ username: email, email, password, full_name: name })
            });
            const data = await response.json();
            if (response.ok) {
                // Add to local cache for forgot-password screens that still use local check
                const users = JSON.parse(localStorage.getItem(this.USERS) || '[]');
                if (!users.find(u => u.email === email)) {
                    users.push({ name, email, password });
                    localStorage.setItem(this.USERS, JSON.stringify(users));
                }
                return { success: true };
            }
            return { success: false, message: data.error || 'Registration Failed' };
        } catch (e) {
            return { success: false, message: 'Network Failure' };
        }
    },

    async checkEmail(email) {
        try {
            const response = await fetch(this.API_BASE + 'check-email/', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                },
                body: JSON.stringify({ email })
            });
            const data = await response.json();
            return { exists: data.exists };
        } catch (e) {
            console.error('CheckEmail Error:', e);
            return { exists: false, error: 'Server Unreachable' };
        }
    },

    async resetPassword(email, password) {
        try {
            const response = await fetch(this.API_BASE + 'reset-password/', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                },
                body: JSON.stringify({ email, password })
            });
            return { success: response.ok };
        } catch (e) {
            console.error('ResetPassword Error:', e);
            return { success: false, error: 'Server Unreachable' };
        }
    },

    logout() {
        localStorage.removeItem(this.SESSION);
        localStorage.removeItem(this.REPORTS);
        localStorage.removeItem(this.ADMIN_SESSION);
        localStorage.removeItem('last_admin_stats');
        window.location.href = 'login.html';
    },

    async getUserReports() {
        const res = await this.fetchWithAuth('assessments/');
        if (res.success && res.data) {
            return res.data;
        }
        console.error("Failed to fetch reports from backend.");
        return [];
    },

    async saveReport(module, score, risk, details) {
        const newReport = {
            assessment_type: module.toLowerCase(),
            inputs: details,
            score: score
        };

        const res = await this.fetchWithAuth('assessments/', 'POST', newReport);
        if (res.success) {
            return true;
        }
        return false;
    },

    async getAllReports() {
        const res = await this.fetchWithAuth('admin/reports/');
        return res.success ? res.data : [];
    },

    async getAdminUsers() {
        const res = await this.fetchWithAuth('admin/users/');
        return res.success ? res.data : [];
    },

    async deleteUser(id) {
        const res = await this.fetchWithAuth(`admin/users/${id}/delete/`, 'DELETE');
        return res.success;
    },

    async updateUser(id, data) {
        const res = await this.fetchWithAuth(`admin/users/${id}/update/`, 'PATCH', data);
        return res.success;
    },

    getRiskDistribution() {
        const stats = JSON.parse(localStorage.getItem('last_admin_stats') || '{}');
        const dist = stats.risk_distribution || { low: 0, med: 0, high: 0 };
        const total = (dist.low + dist.med + dist.high) || 1;
        return {
            low: { count: dist.low, percent: Math.round((dist.low/total)*100) },
            med: { count: dist.med, percent: Math.round((dist.med/total)*100) },
            high: { count: dist.high, percent: Math.round((dist.high/total)*100) }
        };
    },

    getPlatformAnalytics() {
        const stats = JSON.parse(localStorage.getItem('last_admin_stats') || '{}');
        const analytics = stats.module_analytics || {};
        return {
            labels: Object.keys(analytics),
            data: Object.values(analytics)
        };
    },

    getPlatformTrends() {
        const stats = JSON.parse(localStorage.getItem('last_admin_stats') || '{}');
        return stats.trends || [];
    },

    async saveDailyLog(data) {
        const user = this.getCurrentUser();
        if (!user) return false;

        const payload = {
            date: new Date().toISOString().split('T')[0],
            water: data.water,
            smoked: data.smoked,
            steps: data.steps,
            sleep: data.sleep,
            calories: data.calories,
            weight: data.weight,
            systolic: data.systolic,
            diastolic: data.diastolic
        };

        const res = await this.fetchWithAuth('tracker/', 'POST', payload);
        return res.success;
    },

    async getOverallHealthScore() {
        const user = this.getCurrentUser();
        if (!user) return -1;
        
        const res = await this.fetchWithAuth('sync/');
        if (!res.success || !res.data) return -1;
        
        const latestScores = {};
        
        // Process assessments
        if (res.data.assessments) {
            res.data.assessments.forEach(r => {
                const type = (r.assessment_type || r.module).toLowerCase();
                if (!latestScores[type]) latestScores[type] = r.score;
            });
        }
        
        // Process daily tracker
        if (res.data.tracker && res.data.tracker.length > 0) {
            // Get latest tracker entry
            const latestTracker = res.data.tracker[res.data.tracker.length - 1];
            if (latestTracker.score !== undefined) {
                latestScores['daily_tracker'] = latestTracker.score;
            }
        }

        let sum = 0;
        const allPossibleModules = ["kidney", "heart", "lung", "liver", "cancer", "brain", "daily_tracker"];
        allPossibleModules.forEach(m => {
            if (latestScores[m]) sum += latestScores[m];
        });

        return Math.round(sum / 7.0);
    },

    async getAdminStats() {
        const res = await this.fetchWithAuth('sync/');
        if (res.success && res.data) {
            localStorage.setItem('last_admin_stats', JSON.stringify(res.data));
            return {
                totalUsers: res.data.total_users || 0,
                totalReports: res.data.total_assessments || 0,
                totalCritical: res.data.critical_alerts || 0,
                activeToday: res.data.active_today || 0
            };
        }
        return { totalUsers: 0, totalReports: 0, totalCritical: 0, activeToday: 0 };
    },

    async getAdminAlerts() {
        const res = await this.fetchWithAuth('sync/');
        if (res.success && res.data && res.data.alerts) {
            return res.data.alerts;
        }
        return [];
    },

    async getTrends(days = 7) {
        const res = await this.fetchWithAuth(`sync/`); // Or a specific trends endpoint if exists
        const trends = {
            labels: [], water: [], steps: [], sleep: [], weight: [], calories: [], systolic: []
        };
        
        if (res.success && res.data && res.data.tracker) {
            const data = res.data.tracker.slice(-days);
            data.forEach(d => {
                trends.labels.push(new Date(d.date).toLocaleDateString('en-US', { weekday: 'short' }));
                trends.water.push(d.water || 0);
                trends.steps.push(d.steps || 0);
                trends.sleep.push(d.sleep || 0);
                trends.weight.push(d.weight || 0);
                trends.calories.push(d.calories || 0);
                trends.systolic.push(d.systolic || 0);
            });
        }
        
        // Fill defaults if empty
        if (trends.labels.length === 0) {
            for(let i=0; i<days; i++) {
                trends.labels.push('Day ' + (i+1));
                trends.water.push(0);
                trends.steps.push(0);
                trends.sleep.push(0);
                trends.weight.push(0);
                trends.calories.push(0);
                trends.systolic.push(0);
            }
        }
        return trends;
    }
};

DB.init();
window.DB = DB;
