const AssessmentEngine = {
    // --- DAILY TRACKER STANDARDS ---
    DailyTracker: {
        GOAL_WATER: 2.5,
        GOAL_STEPS: 8000,
        GOAL_SLEEP: 7.5,
        GOAL_CALORIES: 2500,

        calculateScore(water, smoked, steps, sleep, calories) {
            let score = 0;
            if (water >= this.GOAL_WATER) score += 20;
            if (!smoked) score += 20;
            if (steps >= this.GOAL_STEPS) score += 20;
            if (sleep >= this.GOAL_SLEEP) score += 20;
            if (calories > 0 && calories <= this.GOAL_CALORIES) score += 20;
            return score;
        }
    },

    // --- KIDNEY LOGIC ---
    calculateKidney(gfr, proteinPresent) {
        let riskVal = 0;
        let stage = "";

        if (gfr >= 90) { stage = "Stage 1 • Normal"; riskVal = 0; }
        else if (gfr >= 60) { stage = "Stage 2 • Mild"; riskVal = 0; }
        else if (gfr >= 45) { stage = "Stage 3 • Moderate"; riskVal = 1; }
        else if (gfr >= 30) { stage = "Stage 3 • Moderate"; riskVal = 1; }
        else if (gfr >= 15) { stage = "Stage 4 • Severe"; riskVal = 2; }
        else { stage = "Stage 5 • Kidney Failure"; riskVal = 3; }

        if (proteinPresent) {
            riskVal++;
            if (riskVal > 3) riskVal = 3;
        }

        let riskLevel = "Low";
        let score = 90;
        if (riskVal === 1) { riskLevel = "Medium"; score = 70; }
        else if (riskVal === 2) { riskLevel = "High"; score = 40; }
        else if (riskVal === 3) { riskLevel = "Critical"; score = 20; }

        return { riskLevel, score, stage };
    },

    // --- HEART LOGIC ---
    calculateHeart(sys, dia, chol, ldl, sugar, abnormalECG) {
        let pts = 0;
        if (sys >= 140 || dia >= 90) pts += 2;
        else if (sys >= 120 || dia >= 80) pts += 1;

        if (chol >= 240) pts += 2;
        else if (chol >= 200) pts += 1;

        if (ldl >= 160) pts += 2;
        else if (ldl >= 100) pts += 1;

        if (sugar >= 126) pts += 2;
        else if (sugar >= 100) pts += 1;

        if (abnormalECG) pts += 2;

        let riskLevel, riskPercent;
        if (pts >= 6) { riskLevel = "High Risk"; riskPercent = 35; }
        else if (pts >= 3) { riskLevel = "Medium Risk"; riskPercent = 20; }
        else { riskLevel = "Low Risk"; riskPercent = 5; }

        return { riskLevel, riskPercentage: riskPercent + "%", score: 100 - riskPercent };
    },

    // --- LIVER LOGIC ---
    calculateLiver(alt, ast, bili, albu, alp) {
        let pts = 0;
        if (alt > 300) pts += 3; else if (alt > 120) pts += 2; else if (alt > 56) pts += 1;
        if (ast > 300) pts += 3; else if (ast > 100) pts += 2; else if (ast > 40) pts += 1;
        if (bili > 3.0) pts += 3; else if (bili > 2.0) pts += 2; else if (bili > 1.2) pts += 1;
        if (albu < 2.5) pts += 3; else if (albu < 3.0) pts += 2; else if (albu < 3.5) pts += 1;
        if (alp > 400) pts += 3; else if (alp > 250) pts += 2; else if (alp > 147) pts += 1;

        let riskLevel, status, score;

        if (pts <= 2) { riskLevel = "Low Risk"; status = "Normal"; score = 95; }
        else if (pts <= 6) { riskLevel = "Moderate Risk"; status = "Mild"; score = 75; }
        else if (pts <= 10) { riskLevel = "High Risk"; status = "Moderate"; score = 50; }
        else { riskLevel = "Very High Risk"; status = "Severe"; score = 25; }

        return { riskLevel, status, score };
    },

    // --- LUNG LOGIC ---
    calculateLung(fev1, ratio, spo2, isSmoker) {
        let rFev1 = fev1 >= 80 ? 0 : fev1 >= 50 ? 1 : fev1 >= 30 ? 2 : 3;
        let rRatio = ratio < 0.70 ? 1 : 0;
        let rSpo2 = spo2 >= 95 ? 0 : spo2 >= 90 ? 1 : 3;

        let riskVal = Math.max(rFev1, rRatio, rSpo2);
        if (isSmoker && riskVal < 3) riskVal++;

        let riskLevel, status, score;
        if (riskVal === 0) { riskLevel = "LOW"; status = "Normal"; score = 95; }
        else if (riskVal === 1) { riskLevel = "LOW-MEDIUM"; status = "Mild"; score = 75; }
        else if (riskVal === 2) { riskLevel = "MEDIUM"; status = "Moderate"; score = 50; }
        else { riskLevel = "HIGH"; status = "Severe"; score = 25; }

        return { riskLevel, status, score };
    },

    // --- CANCER LOGIC ---
    calculateCancer(t, lymph, meta, grade) {
        let stage;
        let baseRiskVal;
        if (meta) { stage = "Stage IV"; baseRiskVal = 4; }
        else if ((t === "T3" || t === "T4") && lymph) { stage = "Stage III"; baseRiskVal = 3; }
        else if (t === "T4" && !lymph) { stage = "Stage III"; baseRiskVal = 3; }
        else if (((t === "T2" || t === "T3") && !lymph) || lymph) { stage = "Stage II"; baseRiskVal = 2; }
        else { stage = "Stage I"; baseRiskVal = 1; }

        let riskVal = baseRiskVal;
        if (grade === "High" && riskVal < 4) riskVal++;

        let riskLevel = riskVal === 1 ? "Low" : riskVal === 2 ? "Moderate" : riskVal === 3 ? "High" : "Very High";
        let score = stage === "Stage I" ? 85 : stage === "Stage II" ? 65 : stage === "Stage III" ? 40 : 20;

        return { stage, riskLevel, score };
    },

    // --- BRAIN (ALZHEIMER) LOGIC ---
    calculateBrain(mmse, age, clinical, familyHistory) {
        let pts = 0;
        if (mmse >= 27) pts += 0; else if (mmse >= 21) pts += 15; else if (mmse >= 10) pts += 35; else pts += 50;
        if (clinical === "MCI") pts += 15; else if (clinical === "Dementia") pts += 30;
        if (age >= 70) pts += 10; else if (age >= 60) pts += 5;
        if (familyHistory) pts += 10;

        let riskLevel = pts <= 25 ? "Low Risk" : pts <= 50 ? "Mild Risk" : pts <= 75 ? "Moderate Risk" : "High Risk";
        let score = Math.round((mmse / 30.0) * 100);

        return { riskLevel, score, points: pts };
    }
};

window.AssessmentEngine = AssessmentEngine;

window.AssessmentEngine = AssessmentEngine;
