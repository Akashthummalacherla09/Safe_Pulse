/**
 * SafePulse Universal PDF Generation Engine
 * Replicates Android PDFGenerator.java logic 1:1 for the Web Platform
 */

const PDFGenerator = {
    /**
     * Internal formatting function for medical parameter keys
     */
    formatKey(key) {
        if (!key) return "";
        return key.split(/[_\s]|(?=[A-Z])/)
            .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
            .join(' ');
    },

    /**
     * Generates a Medical Report PDF matching Android layout
     * @param {Object} report - The report object from storage
     */
    async downloadReport(report) {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        let y = 20;

        // 1. Draw Header (Navy Shield Pulse Style)
        doc.setFont("helvetica", "bold");
        doc.setFontSize(22);
        doc.setTextColor(30, 41, 59); // var(--brand-navy)
        doc.text("SafePulse Medical Report", 15, y);
        y += 10;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(10);
        doc.setTextColor(100, 116, 139);
        doc.text(`Generated on: ${new Date(report.timestamp).toLocaleString()}`, 15, y);
        y += 8;

        // Header Line
        doc.setDrawColor(226, 232, 240);
        doc.line(15, y, 195, y);
        y += 15;

        // 2. Assessment Summary Section
        doc.setFontSize(18);
        doc.setTextColor(0, 0, 0);
        const moduleName = report.assessment_type ? (report.assessment_type.charAt(0).toUpperCase() + report.assessment_type.slice(1)) : 'Unknown';
        doc.text(`${moduleName} Assessment Summary`, 15, y);
        y += 12;

        doc.setFontSize(14);
        doc.text("Current Risk Level:", 15, y);
        
        // Dynamic Risk Color Logic
        const riskStr = report.results && report.results.riskLevel ? report.results.riskLevel : (report.results && report.results.status ? report.results.status : 'Unknown');
        const risk = riskStr.toLowerCase();
        if (risk.includes("low") || risk.includes("normal") || risk.includes("safe") || risk.includes("mild")) {
            doc.setTextColor(16, 185, 129); // Emerald
        } else if (risk.includes("medium") || risk.includes("moderate") || risk.includes("caution") || risk.includes("high")) {
            if (risk.includes("high") && !risk.includes("very")) doc.setTextColor(239, 68, 68); // Red
            else doc.setTextColor(245, 158, 11); // Amber
        } else {
            doc.setTextColor(239, 68, 68); // Red
        }
        doc.setFont("helvetica", "bold");
        doc.text(riskStr.toUpperCase(), 70, y);
        y += 20;

        // 3. Detailed Parameters Table
        doc.setFontSize(16);
        doc.setTextColor(51, 65, 85);
        doc.text("Detailed Clinical Parameters:", 15, y);
        y += 8;

        const tableBody = [
            ["PARAMETER", "VALUE"],
            ["Patient Name", report.userName || "N/A"],
            ["Assessment ID", `SP-${report.id}`],
            ["Diagnostic Score", `${report.score}%`]
        ];

        // Add dynamic medical parameters
        if (report.inputs) {
            Object.entries(report.inputs).forEach(([key, val]) => {
                tableBody.push([this.formatKey(key), val]);
            });
        }

        doc.autoTable({
            startY: y,
            head: [tableBody[0]],
            body: tableBody.slice(1),
            theme: 'striped',
            headStyles: { 
                fillColor: [226, 232, 240], 
                textColor: [71, 85, 105], 
                fontStyle: 'bold',
                fontSize: 11
            },
            bodyStyles: { 
                textColor: [30, 41, 59],
                fontSize: 10
            },
            alternateRowStyles: {
                fillColor: [248, 250, 252]
            },
            margin: { left: 15, right: 15 }
        });

        // 4. Disclaimer Footer
        const finalY = doc.lastAutoTable.finalY + 20;
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9);
        doc.setTextColor(148, 163, 184);
        const disclaimer = "Disclaimer: This is an automatically generated screening report. It is NOT a medical diagnosis. Please consult with a healthcare professional for accurate diagnosis and treatment.";
        const splitDisclaimer = doc.splitTextToSize(disclaimer, 170);
        doc.text(splitDisclaimer, 15, finalY);

        // Save File
        doc.save(`SafePulse_${moduleName}_Report_${Date.now()}.pdf`);
    },

    /**
     * Generates a Platform Operations Summary for Admins
     */
    async downloadAdminSummary(stats) {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        doc.setFont("helvetica", "bold");
        doc.setFontSize(24);
        doc.text("SafePulse Platform Operations", 15, 30);
        
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.text(`Snapshot Date: ${new Date().toLocaleString()}`, 15, 40);

        doc.autoTable({
            startY: 50,
            head: [['METRIC', 'CURRENT VOLUME']],
            body: [
                ['Total Registered Patients', stats.totalUsers],
                ['Total Diagnostic Assessments', stats.totalReports],
                ['Critical/High Alerts Logged', stats.totalCritical],
                ['Active Users (24h)', stats.activeToday]
            ],
            theme: 'grid',
            headStyles: { fillColor: [15, 23, 42] }
        });

        doc.save(`SafePulse_Admin_Audit_${Date.now()}.pdf`);
    }
};
