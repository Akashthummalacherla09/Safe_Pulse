package com.simats.safe_pulse;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class ReportListResponse {
    @SerializedName("status")
    private String status;
    
    @SerializedName("message")
    private String message;
    
    @SerializedName("reports")
    private List<ReportResponse> reports;

    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public List<ReportResponse> getReports() { return reports; }
}
