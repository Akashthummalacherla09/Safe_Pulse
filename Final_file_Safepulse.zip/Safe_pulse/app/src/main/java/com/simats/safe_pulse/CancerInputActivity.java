package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CancerInputActivity extends AppCompatActivity {

    private EditText inputTumorSize;
    private Spinner spinnerLymphNode;
    private Spinner spinnerMetastasis;
    private Spinner spinnerBiopsyGrade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cancer_input);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView backButton = findViewById(R.id.btn_back);
        Button calculateButton = findViewById(R.id.btn_calculate);
        
        Spinner spinnerCancerType = findViewById(R.id.spinner_cancer_type);
        inputTumorSize = findViewById(R.id.input_tumor_size);
        spinnerLymphNode = findViewById(R.id.spinner_lymph_node);
        spinnerMetastasis = findViewById(R.id.spinner_metastasis);
        spinnerBiopsyGrade = findViewById(R.id.spinner_biopsy_grade);

        // Setup Spinners
        setupSpinner(spinnerCancerType, new String[]{"Lung Cancer", "Prostate Cancer", "Colorectal Cancer", "Skin Cancer", "Other"});
        setupSpinner(spinnerLymphNode, new String[]{"No", "Yes"});
        setupSpinner(spinnerMetastasis, new String[]{"No", "Yes"});
        setupSpinner(spinnerBiopsyGrade, new String[]{"Low", "Intermediate", "High"});

        // Back Logic
        backButton.setOnClickListener(v -> finish());

        // Calculate Logic
        calculateButton.setOnClickListener(v -> {
            String tumorSizeInput = inputTumorSize.getText().toString().trim();
            
            if (tumorSizeInput.isEmpty()) {
                inputTumorSize.setError("Please enter tumor size");
                return;
            }

            String tCategory = resolveTCategory(tumorSizeInput);
            if (tCategory == null) {
                inputTumorSize.setError("Invalid format. Use T1-T4 or numeric value.");
                return;
            }

            boolean hasLymph = spinnerLymphNode.getSelectedItem().toString().equalsIgnoreCase("Yes");
            boolean hasMets = spinnerMetastasis.getSelectedItem().toString().equalsIgnoreCase("Yes");
            String grade = spinnerBiopsyGrade.getSelectedItem().toString();

            Intent intent = new Intent(CancerInputActivity.this, CancerResultActivity.class);
            intent.putExtra("T_CATEGORY", tCategory);
            intent.putExtra("LYMPH", hasLymph);
            intent.putExtra("METASTASIS", hasMets);
            intent.putExtra("GRADE", grade);
            startActivity(intent);
        });
    }

    private String resolveTCategory(String input) {
        // Direct T1-T4 check
        if (input.equalsIgnoreCase("T1") || input.equalsIgnoreCase("T2") || 
            input.equalsIgnoreCase("T3") || input.equalsIgnoreCase("T4")) {
            return input.toUpperCase();
        }

        // Numeric Check
        try {
            double size = Double.parseDouble(input.replaceAll("[^0-9.]", "")); // Remove "cm" if present
             if (size <= 2) return "T1";
             if (size <= 5) return "T2";
             if (size <= 7) return "T3";
             return "T4";
        } catch (NumberFormatException e) {
            return null; // Invalid
        }
    }

    private void setupSpinner(Spinner spinner, String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }
}
