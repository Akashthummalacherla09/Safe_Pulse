package com.simats.safe_pulse;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {
    @SerializedName("token")
    private String token;

    @SerializedName("role")
    private String role;
    @SerializedName("name")
    private String name;
    @SerializedName("user_id")
    private int userId;

    public String getToken() {
        return token;
    }

    public String getRole() {
        return role;
    }

    public String getName() {
        return name;
    }

    public int getUserId() {
        return userId;
    }
}
