package com.simats.safe_pulse;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CancerPreventionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cancer_prevention);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String stage = getIntent().getStringExtra("STAGE");
        if (stage == null) stage = "Stage I";

        displayTips(stage);

        // Navigation
        findViewById(R.id.btn_back_prevention).setOnClickListener(v -> finish());
        
        Button btnDashboard = findViewById(R.id.btn_dashboard);
        btnDashboard.setOnClickListener(v -> {
            Intent intent = new Intent(CancerPreventionActivity.this, UserDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void displayTips(String stage) {
        LinearLayout container = findViewById(R.id.container_actions);

        String[] tips = {};

        switch (stage) {
            case "Stage I":
                tips = new String[]{
                    "Regular screening",
                    "Healthy diet rich in antioxidants",
                    "Avoid tobacco",
                    "Regular physical activity",
                    "Follow-up checkups"
                };
                break;
            case "Stage II":
                tips = new String[]{
                    "Strict follow-up schedule",
                    "Balanced diet",
                    "Immune strengthening",
                    "Avoid smoking and alcohol",
                    "Adhere to treatment plan"
                };
                break;
            case "Stage III":
                tips = new String[]{
                    "Immediate oncologist consultation",
                    "Adjuvant therapy compliance",
                    "Monitor side effects",
                    "Nutritional support",
                    "Mental health counseling"
                };
                break;
            case "Stage IV":
                tips = new String[]{
                    "Palliative care planning",
                    "Pain management",
                    "Advanced oncology treatment",
                    "Psychological support",
                    "Family counseling"
                };
                break;
        }

        for (String tip : tips) {
            TextView tipView = new TextView(this);
            tipView.setText("• " + tip);
            tipView.setTextColor(Color.parseColor("#455A64")); // role_subtext roughly
            tipView.setTextSize(14);
            tipView.setPadding(0, 8, 0, 0);
            container.addView(tipView);
        }
    }
}
