package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AssessmentIntroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_assessment_intro);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView btnBack = findViewById(R.id.btn_back);
        TextView moduleTitle = findViewById(R.id.text_module_title);
        TextView moduleSubtitle = findViewById(R.id.text_module_subtitle);
        
        ImageView introIcon = findViewById(R.id.img_module_icon);
        TextView introTitle = findViewById(R.id.text_intro_title);
        TextView introDesc = findViewById(R.id.text_intro_desc);
        
        TextView reqText = findViewById(R.id.text_requirements);
        TextView durationText = findViewById(R.id.text_duration);
        
        Button btnProceed = findViewById(R.id.btn_proceed);

        // Get Data
        String type = getIntent().getStringExtra("MODULE_TYPE");
        if (type == null) type = "Heart";

        configureContent(type, moduleTitle, moduleSubtitle, introIcon, introTitle, introDesc, reqText, durationText);

        final String moduleType = type;
        btnProceed.setOnClickListener(v -> {
            Class<?> target = getTargetActivity(moduleType);
            if (target != null) {
                Intent intent = new Intent(AssessmentIntroActivity.this, target);
                startActivity(intent);
                finish();
            }
        });

        btnBack.setOnClickListener(v -> finish());
    }

    private void configureContent(String type, TextView mTitle, TextView mSub, ImageView icon, TextView iTitle, TextView iDesc, TextView req, TextView dur) {
        switch (type.toLowerCase()) {
            case "heart":
                mTitle.setText("Heart Diagnostic");
                mSub.setText("Cardiovascular Health Screening");
                icon.setImageResource(R.drawable.ic_heart_logo); 
                iTitle.setText("Cardiovascular Assessment");
                iDesc.setText("This clinical tool calculates your cardiovascular risk profile based on blood pressure, lipid panels, and metabolic markers.");
                req.setText("Latest BP and Lipid Profile values.");
                dur.setText("Under 3 minutes.");
                break;
            case "kidney":
                mTitle.setText("Renal Diagnostic");
                mSub.setText("Kidney Function & eGFR Screening");
                icon.setImageResource(R.drawable.ic_kidney);
                iTitle.setText("Renal Assessment");
                iDesc.setText("Evaluates kidney performance and CKD stages using eGFR, creatinine levels, and urine protein presence.");
                req.setText("Latest Serum Creatinine and eGFR values.");
                dur.setText("Under 2 minutes.");
                break;
            case "liver":
                mTitle.setText("Hepatic Diagnostic");
                mSub.setText("Liver Function & Hepatic Screening");
                icon.setImageResource(R.drawable.ic_liver);
                iTitle.setText("Hepatic Assessment");
                iDesc.setText("Evaluates liver enzyme levels (ALT, AST, ALP) and metabolic markers (Bilirubin, Albumin) to determine hepatic risk stages.");
                req.setText("Latest LFT blood test report results.");
                dur.setText("Under 2 minutes.");
                break;
            case "lung":
                mTitle.setText("Pulmonary Diagnostic");
                mSub.setText("Lung Function & COPD Screening");
                icon.setImageResource(R.drawable.ic_bg_wind);
                iTitle.setText("Pulmonary Assessment");
                iDesc.setText("Analyzes pulmonary performance using FEV1, FEF25-75, and SpO2 to determine respiratory health status.");
                req.setText("Latest Spirometry and SpO2 values.");
                dur.setText("Under 3 minutes.");
                break;
            case "cancer":
                mTitle.setText("Oncology Screening");
                mSub.setText("Malignancy & Staging Analysis");
                icon.setImageResource(R.drawable.ic_pill);
                iTitle.setText("Oncology Assessment");
                iDesc.setText("Calculates clinical cancer staging (TNM) based on tumor size, lymph node involvement, and metastasis.");
                req.setText("Latest Biopsy or Imaging staging details.");
                dur.setText("Under 4 minutes.");
                break;
            case "brain":
            case "alzheimer":
                mTitle.setText("Neurological Screening");
                mSub.setText("Cognitive Health & Dementia Analysis");
                icon.setImageResource(R.drawable.ic_bg_brain);
                iTitle.setText("Cognitive Assessment");
                iDesc.setText("Evaluates risk for Alzheimer's disease based on MMSE scores, clinical history, and demographic factors.");
                req.setText("Latest MMSE score and clinical observation data.");
                dur.setText("Under 5 minutes.");
                break;
        }

        // Apply dynamic tint to ensure visibility
        int color = getModuleColor(type);
        icon.setImageTintList(android.content.res.ColorStateList.valueOf(color));
        // Also add a subtle circle background
        android.graphics.drawable.GradientDrawable circle = new android.graphics.drawable.GradientDrawable();
        circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        circle.setColor(color);
        circle.setAlpha(30); 
        icon.setBackground(circle);
        icon.setPadding(30, 30, 30, 30);
    }

    private int getModuleColor(String module) {
        if (module == null) return getResources().getColor(R.color.brand_dark);
        String m = module.toLowerCase();
        if (m.contains("kidney")) return getResources().getColor(R.color.assess_kidney);
        if (m.contains("heart")) return getResources().getColor(R.color.assess_heart);
        if (m.contains("lung")) return getResources().getColor(R.color.assess_lung);
        if (m.contains("liver")) return getResources().getColor(R.color.assess_liver);
        if (m.contains("cancer")) return getResources().getColor(R.color.assess_cancer);
        if (m.contains("brain") || m.contains("alzheimer")) return getResources().getColor(R.color.assess_brain);
        return getResources().getColor(R.color.brand_dark);
    }

    private Class<?> getTargetActivity(String type) {
        switch (type.toLowerCase()) {
            case "heart": return HeartInputActivity.class;
            case "kidney": return KidneyInputActivity.class;
            case "liver": return LiverInputActivity.class;
            case "lung": return LungInputActivity.class;
            case "cancer": return CancerInputActivity.class;
            case "brain":
            case "alzheimer": return AlzheimerInputActivity.class;
            default: return null;
        }
    }
}
