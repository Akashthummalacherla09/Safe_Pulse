package com.simats.safe_pulse;

import java.util.HashMap;
import java.util.Map;

/**
 * Centralized Scoring Engine for SafePulse.
 * All platforms MUST use this exact logic to ensure synchronization.
 */
public class AssessmentEngine {

    // --- DAILY TRACKER STANDARDS ---
    public static class DailyTracker {
        public static final float GOAL_WATER = 2.5f;
        public static final int GOAL_STEPS = 8000;
        public static final float GOAL_SLEEP = 7.5f;
        public static final int GOAL_CALORIES = 2500;

        public static int calculateScore(float water, boolean smoked, int steps, float sleep, int calories) {
            int score = 0;
            if (water >= GOAL_WATER) score += 20;
            if (!smoked) score += 20;
            if (steps >= GOAL_STEPS) score += 20;
            if (sleep >= GOAL_SLEEP) score += 20;
            if (calories > 0 && calories <= GOAL_CALORIES) score += 20;
            return score;
        }
    }

    // --- KIDNEY LOGIC ---
    public static Map<String, Object> calculateKidney(double gfr, boolean proteinPresent) {
        int riskVal = 0;
        String stage = "";

        if (gfr >= 90) { stage = "Stage 1 • Normal"; riskVal = 0; }
        else if (gfr >= 60) { stage = "Stage 2 • Mild"; riskVal = 0; }
        else if (gfr >= 45) { stage = "Stage 3 • Moderate"; riskVal = 1; }
        else if (gfr >= 30) { stage = "Stage 3 • Moderate"; riskVal = 1; }
        else if (gfr >= 15) { stage = "Stage 4 • Severe"; riskVal = 2; }
        else { stage = "Stage 5 • Kidney Failure"; riskVal = 3; }

        if (proteinPresent) {
            riskVal++;
            if (riskVal > 3) riskVal = 3;
        }

        String riskLevel = "Low";
        int score = 90;
        if (riskVal == 1) { riskLevel = "Medium"; score = 70; }
        else if (riskVal == 2) { riskLevel = "High"; score = 40; }
        else if (riskVal == 3) { riskLevel = "Critical"; score = 20; }

        Map<String, Object> result = new HashMap<>();
        result.put("riskLevel", riskLevel);
        result.put("score", score);
        result.put("stage", stage);
        return result;
    }

    // --- HEART LOGIC ---
    public static Map<String, Object> calculateHeart(int sys, int dia, int chol, int ldl, int sugar, boolean abnormalECG) {
        int pts = 0;
        if (sys >= 140 || dia >= 90) pts += 2;
        else if (sys >= 120 || dia >= 80) pts += 1;

        if (chol >= 240) pts += 2;
        else if (chol >= 200) pts += 1;

        if (ldl >= 160) pts += 2;
        else if (ldl >= 100) pts += 1;

        if (sugar >= 126) pts += 2;
        else if (sugar >= 100) pts += 1;

        if (abnormalECG) pts += 2;

        String riskLevel;
        int riskPercent;
        if (pts >= 6) { riskLevel = "High Risk"; riskPercent = 35; }
        else if (pts >= 3) { riskLevel = "Medium Risk"; riskPercent = 20; }
        else { riskLevel = "Low Risk"; riskPercent = 5; }

        Map<String, Object> result = new HashMap<>();
        result.put("riskLevel", riskLevel);
        result.put("riskPercentage", riskPercent + "%");
        result.put("score", 100 - riskPercent);
        return result;
    }

    // --- LIVER LOGIC ---
    public static Map<String, Object> calculateLiver(int alt, int ast, double bili, double albu, int alp) {
        int pts = 0;
        if (alt > 300) pts += 3; else if (alt > 120) pts += 2; else if (alt > 56) pts += 1;
        if (ast > 300) pts += 3; else if (ast > 100) pts += 2; else if (ast > 40) pts += 1;
        if (bili > 3.0) pts += 3; else if (bili > 2.0) pts += 2; else if (bili > 1.2) pts += 1;
        if (albu < 2.5) pts += 3; else if (albu < 3.0) pts += 2; else if (albu < 3.5) pts += 1;
        if (alp > 400) pts += 3; else if (alp > 250) pts += 2; else if (alp > 147) pts += 1;

        String riskLevel, status;
        int score;

        if (pts <= 2) { riskLevel = "Low Risk"; status = "Normal"; score = 95; }
        else if (pts <= 6) { riskLevel = "Moderate Risk"; status = "Mild"; score = 75; }
        else if (pts <= 10) { riskLevel = "High Risk"; status = "Moderate"; score = 50; }
        else { riskLevel = "Very High Risk"; status = "Severe"; score = 25; }

        Map<String, Object> result = new HashMap<>();
        result.put("riskLevel", riskLevel);
        result.put("status", status);
        result.put("score", score);
        return result;
    }

    // --- LUNG LOGIC ---
    public static Map<String, Object> calculateLung(double fev1, double ratio, double spo2, boolean isSmoker) {
        int rFev1 = fev1 >= 80 ? 0 : fev1 >= 50 ? 1 : fev1 >= 30 ? 2 : 3;
        int rRatio = ratio < 0.70 ? 1 : 0;
        int rSpo2 = spo2 >= 95 ? 0 : spo2 >= 90 ? 1 : 3;

        int riskVal = Math.max(rFev1, Math.max(rRatio, rSpo2));
        if (isSmoker && riskVal < 3) riskVal++;

        String riskLevel, status;
        int score;
        if (riskVal == 0) { riskLevel = "LOW"; status = "Normal"; score = 95; }
        else if (riskVal == 1) { riskLevel = "LOW-MEDIUM"; status = "Mild"; score = 75; }
        else if (riskVal == 2) { riskLevel = "MEDIUM"; status = "Moderate"; score = 50; }
        else { riskLevel = "HIGH"; status = "Severe"; score = 25; }

        Map<String, Object> result = new HashMap<>();
        result.put("riskLevel", riskLevel);
        result.put("status", status);
        result.put("score", score);
        return result;
    }

    // --- CANCER LOGIC ---
    public static Map<String, Object> calculateCancer(String t, boolean lymph, boolean meta, String grade) {
        String stage;
        int baseRiskVal;
        if (meta) { stage = "Stage IV"; baseRiskVal = 4; }
        else if ((t.equals("T3") || t.equals("T4")) && lymph) { stage = "Stage III"; baseRiskVal = 3; }
        else if (t.equals("T4") && !lymph) { stage = "Stage III"; baseRiskVal = 3; }
        else if (((t.equals("T2") || t.equals("T3")) && !lymph) || lymph) { stage = "Stage II"; baseRiskVal = 2; }
        else { stage = "Stage I"; baseRiskVal = 1; }

        int riskVal = baseRiskVal;
        if ("High".equalsIgnoreCase(grade) && riskVal < 4) riskVal++;

        String riskLevel = riskVal == 1 ? "Low" : riskVal == 2 ? "Moderate" : riskVal == 3 ? "High" : "Very High";
        int score = stage.equals("Stage I") ? 85 : stage.equals("Stage II") ? 65 : stage.equals("Stage III") ? 40 : 20;

        Map<String, Object> result = new HashMap<>();
        result.put("stage", stage);
        result.put("riskLevel", riskLevel);
        result.put("score", score);
        return result;
    }

    // --- ALZHEIMER (BRAIN) LOGIC ---
    public static Map<String, Object> calculateBrain(int mmse, int age, String clinical, boolean familyHistory) {
        int pts = 0;
        if (mmse >= 27) pts += 0; else if (mmse >= 21) pts += 15; else if (mmse >= 10) pts += 35; else pts += 50;
        if (clinical.equalsIgnoreCase("MCI")) pts += 15; else if (clinical.equalsIgnoreCase("Dementia")) pts += 30;
        if (age >= 70) pts += 10; else if (age >= 60) pts += 5;
        if (familyHistory) pts += 10;

        String riskLevel = pts <= 25 ? "Low Risk" : pts <= 50 ? "Mild Risk" : pts <= 75 ? "Moderate Risk" : "High Risk";
        int score = Math.round((mmse / 30.0f) * 100);

        Map<String, Object> result = new HashMap<>();
        result.put("riskLevel", riskLevel);
        result.put("score", score);
        result.put("points", pts);
        return result;
    }
}
