package com.simats.safe_pulse;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONObject;
import java.util.Iterator;
import java.util.Map;

public class ReportDetailsActivity extends AppCompatActivity {

    private String moduleName;
    private LinearLayout rowsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_report_details);

        View rootView = findViewById(android.R.id.content);
        if (rootView == null) rootView = getWindow().getDecorView();
        
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        moduleName = getIntent().getStringExtra("MODULE_NAME");
        if (moduleName == null) {
            finish();
            return;
        }

        rowsContainer = findViewById(R.id.layout_data_rows);
        findViewById(R.id.btn_back_details).setOnClickListener(v -> finish());
        
        loadDetails();
    }

    private void loadDetails() {
        int reportId = getIntent().getIntExtra("REPORT_ID", -1);
        String userName = getIntent().getStringExtra("USER_NAME");
        String riskLevel = getIntent().getStringExtra("RISK_LEVEL");
        String detailsJson = getIntent().getStringExtra("DETAILS_JSON");
        String timestamp = getIntent().getStringExtra("TIMESTAMP");

        if (userName == null) userName = "Patient";

        if (reportId != -1) {
            DatabaseHelper db = new DatabaseHelper(this);
            DatabaseHelper.Report r = db.getReportById(reportId);
            if (r == null) {
                finish();
                return;
            }
            moduleName = r.getModule();
            riskLevel = r.getRisk();
            detailsJson = r.getDetails();
            timestamp = r.getTimestamp();
        } else if (detailsJson == null) {
            Map<String, String> status = HealthScoreManager.getModuleStatus(this, moduleName);
            detailsJson = HealthScoreManager.getModuleDetails(this, moduleName);
            if (status.isEmpty()) {
                finish();
                return;
            }
            riskLevel = status.get("risk");
            timestamp = status.get("timestamp");
        }

        final String finalDetailsJson = detailsJson;
        final String finalRisk = riskLevel != null ? riskLevel : "Normal";
        final String finalTimestamp = timestamp;
        final String finalUserName = userName;

        findViewById(R.id.btn_download_full).setOnClickListener(v -> 
            PDFGenerator.exportUserReport(this, finalUserName, moduleName, finalRisk, finalTimestamp, finalDetailsJson));

        // Set Headers
        ((TextView) findViewById(R.id.text_subtitle)).setText((moduleName != null ? moduleName : "Medical") + " Assessment - " + userName);
        String displayRisk = finalRisk.replace(" Risk Level", "").replace(" Risk", "");
        ((TextView) findViewById(R.id.text_risk_level_big)).setText(displayRisk);

        // Hero Card Style
        androidx.cardview.widget.CardView heroCard = findViewById(R.id.card_risk_hero);
        TextView followUpText = findViewById(R.id.text_followup);
        
        String followUp = "Maintain healthy habits and monitor regularly.";
        int heroBg = Color.parseColor("#10B981"); // Green default

        if (finalRisk.contains("Low") || finalRisk.contains("Normal") || finalRisk.contains("Stage I")) {
            heroBg = Color.parseColor("#10B981"); // Green
            followUp = "No immediate follow-up required.";
        } else if (finalRisk.contains("Medium") || finalRisk.contains("Moderate") || finalRisk.contains("Stage II") || finalRisk.contains("Mild")) {
            heroBg = Color.parseColor("#FB923C"); // Orange
            followUp = "Follow-up recommended within 2 weeks.";
        } else {
            heroBg = Color.parseColor("#EF4444"); // Red
            followUp = "Urgent medical consultation advised.";
        }
        
        heroCard.setCardBackgroundColor(heroBg);
        followUpText.setText(followUp);

        // Standard Rows
        addRow("Date", timestamp);
        
        // Dynamic Rows from JSON
        if (detailsJson != null) {
            try {
                JSONObject json = new JSONObject(detailsJson);
                Iterator<String> keys = json.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    addRow(key, json.getString(key));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void addRow(String label, String value) {
        View rowView = LayoutInflater.from(this).inflate(R.layout.item_detail_row, rowsContainer, false);
        TextView labelTxt = rowView.findViewById(R.id.row_label);
        TextView valueTxt = rowView.findViewById(R.id.row_value);
        
        labelTxt.setText(label);
        valueTxt.setText(value);
        
        rowsContainer.addView(rowView);
    }
}
