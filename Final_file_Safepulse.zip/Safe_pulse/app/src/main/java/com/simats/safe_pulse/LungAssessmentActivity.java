package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LungAssessmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lung_assessment);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        Button startButton = findViewById(R.id.btn_start_assessment);
        Button backDashboardButton = findViewById(R.id.btn_back_dashboard);
        TextView backHeaderButton = findViewById(R.id.btn_back_header);

        // Start Assessment
        startButton.setOnClickListener(v -> {
             Intent intent = new Intent(LungAssessmentActivity.this, LungInputActivity.class);
             startActivity(intent);
        });

        // Back / Dashboard Navigation
        backDashboardButton.setOnClickListener(v -> finish());
        backHeaderButton.setOnClickListener(v -> finish());
    }
}
