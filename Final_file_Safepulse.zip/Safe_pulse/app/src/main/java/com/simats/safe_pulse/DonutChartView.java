package com.simats.safe_pulse;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class DonutChartView extends View {

    private Paint paint;
    private RectF rectF;
    private float[] percentages = {0, 0, 0}; // Low, Medium, High
    private int[] colors = {Color.parseColor("#10B981"), Color.parseColor("#F59E0B"), Color.parseColor("#EF4444")};
    private float strokeWidth = 40f;

    public DonutChartView(Context context) {
        super(context);
        init();
    }

    public DonutChartView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(strokeWidth);
        paint.setStrokeCap(Paint.Cap.ROUND);
        rectF = new RectF();
    }

    public void setData(float lowPercent, float medPercent, float highPercent) {
        this.percentages[0] = lowPercent;
        this.percentages[1] = medPercent;
        this.percentages[2] = highPercent;
        invalidate(); // Redraw
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float width = getWidth();
        float height = getHeight();
        float radius = Math.min(width, height) / 2 - strokeWidth;

        rectF.set(width / 2 - radius, height / 2 - radius, width / 2 + radius, height / 2 + radius);

        // Draw background circle
        paint.setColor(Color.parseColor("#F1F5F9"));
        canvas.drawCircle(width / 2, height / 2, radius, paint);

        float startAngle = -90f;
        for (int i = 0; i < percentages.length; i++) {
            float sweepAngle = (percentages[i] / 100f) * 360f;
            if (sweepAngle > 0) {
                paint.setColor(colors[i]);
                canvas.drawArc(rectF, startAngle, sweepAngle, false, paint);
                startAngle += sweepAngle;
            }
        }
    }
}
