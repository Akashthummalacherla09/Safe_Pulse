package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class HeartPreventionActivity extends AppCompatActivity {

    private LinearLayout tipsContainer;
    private TextView targetBP, targetCholesterol, targetLDL, targetHDL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_heart_prevention);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        tipsContainer = findViewById(R.id.tips_container);
        targetBP = findViewById(R.id.target_bp);
        targetCholesterol = findViewById(R.id.target_cholesterol);
        targetLDL = findViewById(R.id.target_ldl);
        targetHDL = findViewById(R.id.target_hdl);
        Button backButton = findViewById(R.id.btn_back_dashboard);

        // Get Data
        String riskLevel = getIntent().getStringExtra("RISK_LEVEL");
        if (riskLevel == null) riskLevel = "Low Risk Level";

        // Load Content
        loadContent(riskLevel);

        // Navigation
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(HeartPreventionActivity.this, UserDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadContent(String riskLevel) {
        List<Tip> tips = new ArrayList<>();

        if (riskLevel.contains("Low")) {
            tips.add(new Tip("Regular Exercise", "At least 150 minutes of moderate aerobic activity weekly", true));
            tips.add(new Tip("Heart-Healthy Diet", "Focus on fruits, vegetables, whole grains, and lean proteins", true));
            tips.add(new Tip("Manage Stress", "Practice meditation, yoga, or other relaxation techniques", true));
            tips.add(new Tip("Monitor Blood Pressure", "Check regularly and keep below 120/80 mmHg", true));
            tips.add(new Tip("Maintain Healthy Weight", "Keep BMI in the normal range (18.5-24.9)", true));
            tips.add(new Tip("Quit Smoking", "Smoking dramatically increases heart disease risk", false)); // Caution
            tips.add(new Tip("Reduce Salt Intake", "Limit sodium to under 2,300mg per day", false)); // Caution

            targetBP.setText("Below 120/80");
            targetCholesterol.setText("Below 200 mg/dL");
            targetLDL.setText("Below 100 mg/dL");
            targetHDL.setText("Above 40 mg/dL");

        } else if (riskLevel.contains("Medium")) {
            tips.add(new Tip("Regular Exercise", "At least 30 minutes daily", true));
            tips.add(new Tip("Heart-Healthy Diet", "Strict adherence to DASH or Mediterranean diet", true));
            tips.add(new Tip("Monitor Blood Pressure", "Weekly monitoring required", true));
            tips.add(new Tip("Quit Smoking", "Essential to stop immediately", false));
            tips.add(new Tip("Reduce Salt Intake", "Limit sodium under 1,500 mg/day", false));
            tips.add(new Tip("Limit Alcohol", "No more than 1 drink per day", false));
            tips.add(new Tip("Weight Reduction", "Aim for 5-10% weight loss if overweight", false));

            targetBP.setText("< 120/80 (Strict)");
            targetCholesterol.setText("< 180 mg/dL");
            targetLDL.setText("< 100 mg/dL");
            targetHDL.setText("> 45 mg/dL");

        } else { // High Risk
            tips.add(new Tip("Quit Smoking", "Consult doctor for cessation programs immediately", false));
            tips.add(new Tip("Reduce Salt Intake", "Strict limit under 1,500 mg/day", false));
            tips.add(new Tip("Strict Alcohol Control", "Ideally avoid alcohol completely", false));
            tips.add(new Tip("Daily BP Monitoring", "Log your readings daily", false));
            tips.add(new Tip("Immediate Weight Management", "Medical weight loss plan recommended", false));
            tips.add(new Tip("Structured Exercise Plan", "Only under doctor supervision", true));
            tips.add(new Tip("Medical Diet Plan", "Consult a nutritionist immediately", true));

            targetBP.setText("< 120/80 (Strict Control)");
            targetCholesterol.setText("< 160 mg/dL");
            targetLDL.setText("< 70 mg/dL");
            targetHDL.setText("> 50 mg/dL");
        }

        for (Tip tip : tips) {
            addTipView(tip);
        }
    }

    private void addTipView(Tip tip) {
        // Create CardView
        CardView card = new CardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 32); // Bottom margin (approx 12dp)
        card.setLayoutParams(params);
        card.setRadius(32); // approx 12dp
        card.setCardElevation(8); 
        card.setCardBackgroundColor(0xFFFFFFFF);

        // Inner Layout (Horizontal)
        LinearLayout innerLayout = new LinearLayout(this);
        innerLayout.setOrientation(LinearLayout.HORIZONTAL);
        innerLayout.setPadding(32, 32, 32, 32); // Padding inside card
        innerLayout.setGravity(Gravity.CENTER_VERTICAL);
        
        // Icon Image View
        ImageView iconView = new ImageView(this);
        int iconSize = 120; // 40-48dp approx
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(iconSize, iconSize);
        iconView.setLayoutParams(iconParams);
        
        if (tip.isPositive) {
            iconView.setBackgroundResource(R.drawable.bg_circle_success_light);
            iconView.setImageResource(R.drawable.ic_check_green);
        } else {
            iconView.setBackgroundResource(R.drawable.bg_circle_error_light);
            iconView.setImageResource(R.drawable.ic_close_red);
        }
        iconView.setPadding(32, 32, 32, 32); // Padding inside circle to make icon smaller
        
        // Text Container (Vertical)
        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textParams.setMargins(32, 0, 0, 0); // Start margin
        textLayout.setLayoutParams(textParams);
        
        // Title
        TextView titleView = new TextView(this);
        titleView.setText(tip.title);
        titleView.setTextSize(16); // sp
        titleView.setTextColor(getResources().getColor(R.color.brand_dark));
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        
        // Description
        TextView descView = new TextView(this);
        descView.setText(tip.description);
        descView.setTextSize(13); // sp
        descView.setTextColor(getResources().getColor(R.color.role_subtext));
        
        textLayout.addView(titleView);
        textLayout.addView(descView);
        
        innerLayout.addView(iconView);
        innerLayout.addView(textLayout);
        
        card.addView(innerLayout);
        tipsContainer.addView(card);
    }

    private static class Tip {
        String title;
        String description;
        boolean isPositive;

        Tip(String title, String description, boolean isPositive) {
            this.title = title;
            this.description = description;
            this.isPositive = isPositive;
        }
    }
}
