package com.simats.safe_pulse;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PersonalTrendsActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private SimpleDateFormat dayFormat = new SimpleDateFormat("EEE", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_personal_trends);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        prefs = getSharedPreferences("DailyTrackerPrefs", Context.MODE_PRIVATE);

        findViewById(R.id.btn_back_personal_trends).setOnClickListener(v -> finish());

        setupCharts();
    }

    private void setupCharts() {
        // Collect last 7 days keys
        List<String> dates = new ArrayList<>();
        List<String> dayLabels = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        for (int i = 6; i >= 0; i--) {
            Calendar c = (Calendar) cal.clone();
            c.add(Calendar.DATE, -i);
            dates.add(sdf.format(c.getTime()));
            dayLabels.add(dayFormat.format(c.getTime()));
        }

        // 1. Load Local Data first (as placeholder)
        renderWithDates(dates, dayLabels);

        // 2. Fetch from Server for synchronization
        RetrofitClient.getApiService(this).getSyncData().enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    java.util.List<java.util.Map<String, Object>> trackerData = (java.util.List<java.util.Map<String, Object>>) response.body().get("tracker");
                    if (trackerData != null) {
                        syncLocalData(trackerData);
                        renderWithDates(dates, dayLabels); // Re-render with synced data
                    }
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                // Silently fail and keep local data
            }
        });
    }

    private void syncLocalData(java.util.List<java.util.Map<String, Object>> trackerData) {
        SharedPreferences.Editor editor = prefs.edit();
        for (java.util.Map<String, Object> log : trackerData) {
            String date = (String) log.get("date");
            if (date == null) continue;

            // Map values carefully handling types
            if (log.containsKey("water")) editor.putFloat(date + "_water", ((Number)log.get("water")).floatValue());
            if (log.containsKey("steps")) editor.putString(date + "_steps", String.valueOf(log.get("steps")));
            if (log.containsKey("sleep")) editor.putString(date + "_sleep", String.valueOf(log.get("sleep")));
            if (log.containsKey("weight")) editor.putString(date + "_weight", String.valueOf(log.get("weight")));
            if (log.containsKey("calories")) editor.putString(date + "_calories", String.valueOf(log.get("calories")));
            if (log.containsKey("systolic")) editor.putString(date + "_systolic", String.valueOf(log.get("systolic")));
            if (log.containsKey("diastolic")) editor.putString(date + "_diastolic", String.valueOf(log.get("diastolic")));
        }
        editor.apply();
    }

    private void renderWithDates(List<String> dates, List<String> dayLabels) {
        setupWaterTrend(dates, dayLabels);
        setupStepsTrend(dates, dayLabels);
        setupSleepTrend(dates, dayLabels);
        setupWeightTrend(dates, dayLabels);
        setupCaloriesTrend(dates, dayLabels);
        setupBPTrend(dates, dayLabels);
    }

    private void setupWaterTrend(List<String> dates, List<String> dayLabels) {
        View card = findViewById(R.id.trend_water);
        TextView title = card.findViewById(R.id.card_title);
        TextView subtitle = card.findViewById(R.id.card_subtitle);
        TextView current = card.findViewById(R.id.current_value);
        
        title.setText("Water Intake");
        subtitle.setText("Last 7 Days (Liters)");
        
        List<Float> values = new ArrayList<>();
        for (String d : dates) {
            values.add(prefs.getFloat(d + "_water", 0.0f));
        }

        float latest = values.get(values.size() - 1);
        current.setText(String.format(Locale.getDefault(), "%.1fL", latest));
        current.setTextColor(Color.parseColor("#1E88E5")); // Blue

        renderBars(card, values, 3.5f, "#1E88E5", dayLabels);
    }

    private void setupStepsTrend(List<String> dates, List<String> dayLabels) {
        View card = findViewById(R.id.trend_steps);
        TextView title = card.findViewById(R.id.card_title);
        TextView subtitle = card.findViewById(R.id.card_subtitle);
        TextView current = card.findViewById(R.id.current_value);
        
        title.setText("Steps");
        subtitle.setText("Last 7 Days (Count)");

        List<Float> values = new ArrayList<>();
        for (String d : dates) {
            String valStr = prefs.getString(d + "_steps", "0");
            try { values.add(Float.parseFloat(valStr)); } catch (Exception e) { values.add(0.0f); }
        }

        float latest = values.get(values.size() - 1);
        current.setText(String.format(Locale.getDefault(), "%,.0f", latest));
        current.setTextColor(Color.parseColor("#7C4DFF")); // Purple

        renderBars(card, values, 15000f, "#7C4DFF", dayLabels);
    }

    private void setupSleepTrend(List<String> dates, List<String> dayLabels) {
        View card = findViewById(R.id.trend_sleep);
        TextView title = card.findViewById(R.id.card_title);
        TextView subtitle = card.findViewById(R.id.card_subtitle);
        TextView current = card.findViewById(R.id.current_value);
        
        title.setText("Sleep Duration");
        subtitle.setText("Last 7 Days (Hours)");

        List<Float> values = new ArrayList<>();
        for (String d : dates) {
            String valStr = prefs.getString(d + "_sleep", "0");
            try { values.add(Float.parseFloat(valStr)); } catch (Exception e) { values.add(0.0f); }
        }

        float latest = values.get(values.size() - 1);
        current.setText(String.format(Locale.getDefault(), "%.1f h", latest));
        current.setTextColor(Color.parseColor("#0891B2")); // Teal

        renderBars(card, values, 12f, "#0891B2", dayLabels);
    }

    private void setupWeightTrend(List<String> dates, List<String> dayLabels) {
        View card = findViewById(R.id.trend_weight);
        TextView title = card.findViewById(R.id.card_title);
        TextView subtitle = card.findViewById(R.id.card_subtitle);
        TextView current = card.findViewById(R.id.current_value);
        
        title.setText("Weight Tracking");
        subtitle.setText("Last 7 Days (kg)");

        List<Float> values = new ArrayList<>();
        for (String d : dates) {
            String valStr = prefs.getString(d + "_weight", "0");
            try { values.add(Float.parseFloat(valStr)); } catch (Exception e) { values.add(0.0f); }
        }

        float latest = values.get(values.size() - 1);
        current.setText(String.format(Locale.getDefault(), "%.1f kg", latest));
        current.setTextColor(Color.parseColor("#DB2777")); // Pink

        renderBars(card, values, 120f, "#DB2777", dayLabels);
    }

    private void setupCaloriesTrend(List<String> dates, List<String> dayLabels) {
        View card = findViewById(R.id.trend_calories);
        TextView title = card.findViewById(R.id.card_title);
        TextView subtitle = card.findViewById(R.id.card_subtitle);
        TextView current = card.findViewById(R.id.current_value);
        
        title.setText("Calorie Intake");
        subtitle.setText("Last 7 Days (kcal)");

        List<Float> values = new ArrayList<>();
        for (String d : dates) {
            String valStr = prefs.getString(d + "_calories", "0");
            try { values.add(Float.parseFloat(valStr)); } catch (Exception e) { values.add(0.0f); }
        }

        float latest = values.get(values.size() - 1);
        current.setText(String.format(Locale.getDefault(), "%,.0f kcal", latest));
        current.setTextColor(Color.parseColor("#F59E0B")); // Amber

        renderBars(card, values, 3500f, "#F59E0B", dayLabels);
    }

    private void setupBPTrend(List<String> dates, List<String> dayLabels) {
        View card = findViewById(R.id.trend_bp);
        TextView title = card.findViewById(R.id.card_title);
        TextView subtitle = card.findViewById(R.id.card_subtitle);
        TextView current = card.findViewById(R.id.current_value);
        
        title.setText("Blood Pressure");
        subtitle.setText("Systolic (Last 7 Days)");

        List<Float> values = new ArrayList<>();
        float latestSys = 0, latestDia = 0;
        for (String d : dates) {
            String sysStr = prefs.getString(d + "_systolic", "0");
            String diaStr = prefs.getString(d + "_diastolic", "0");
            try { 
                float sys = Float.parseFloat(sysStr);
                values.add(sys);
                latestSys = sys;
                latestDia = Float.parseFloat(diaStr);
            } catch (Exception e) { values.add(0.0f); }
        }

        if (latestSys > 0) {
            current.setText(String.format(Locale.getDefault(), "%.0f/%.0f", latestSys, latestDia));
        } else {
            current.setText("--/--");
        }
        current.setTextColor(Color.parseColor("#EF4444")); // Red

        renderBars(card, values, 200f, "#EF4444", dayLabels);
    }

    private void renderBars(View card, List<Float> values, float maxScale, String colorHex, List<String> dayLabels) {
        LinearLayout barsContainer = card.findViewById(R.id.bars_container);
        LinearLayout labelsContainer = card.findViewById(R.id.labels_container);
        
        barsContainer.removeAllViews();
        labelsContainer.removeAllViews();

        int chartHeight = barsContainer.getLayoutParams().height;
        if (chartHeight <= 0) chartHeight = (int) (120 * getResources().getDisplayMetrics().density);

        for (int i = 0; i < values.size(); i++) {
            float val = values.get(i);
            String label = dayLabels.get(i);

            // Bar Layout
            LinearLayout barLayout = new LinearLayout(this);
            barLayout.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f));
            barLayout.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            barLayout.setPadding(8, 0, 8, 0);

            // Bar View
            View bar = new View(this);
            float ratio = val / maxScale;
            if (ratio > 1.0f) ratio = 1.0f;
            int barHeight = (int) (chartHeight * ratio);
            if (barHeight < (int)(4 * getResources().getDisplayMetrics().density)) barHeight = (int)(4 * getResources().getDisplayMetrics().density); // Min height visibility

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, barHeight);
            bar.setLayoutParams(lp);

            // Style Bar
            GradientDrawable drawable = new GradientDrawable();
            drawable.setColor(Color.parseColor(colorHex));
            drawable.setCornerRadius(100);
            bar.setBackground(drawable);

            barLayout.addView(bar);
            barsContainer.addView(barLayout);

            // Label
            TextView labelTv = new TextView(this);
            labelTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
            labelTv.setText(label);
            labelTv.setGravity(Gravity.CENTER);
            labelTv.setTextSize(10);
            labelTv.setTextColor(Color.parseColor("#94A3B8"));
            labelsContainer.addView(labelTv);
        }
    }
}
