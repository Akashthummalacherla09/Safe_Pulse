package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class AllReportsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private LinearLayout reportsListContainer;
    private List<DatabaseHelper.ReportWithUser> allReports;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_all_reports);
        dbHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        reportsListContainer = findViewById(R.id.reports_list_container);
        findViewById(R.id.btn_back_to_dashboard_reports).setOnClickListener(v -> finish());
        
        EditText searchInput = findViewById(R.id.search_reports);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterReports(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        findViewById(R.id.btn_filter).setOnClickListener(v -> Toast.makeText(this, "Advanced Filters coming soon...", Toast.LENGTH_SHORT).show());

        loadAllReports();
    }

    private void loadAllReports() {
        RetrofitClient.getApiService(this).getAdminReports().enqueue(new retrofit2.Callback<List<java.util.Map<String, Object>>>() {
            @Override
            public void onResponse(retrofit2.Call<List<java.util.Map<String, Object>>> call, retrofit2.Response<List<java.util.Map<String, Object>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<java.util.Map<String, Object>> apiReports = response.body();
                    displayReportsFromApi(apiReports);
                } else {
                    // Fallback to local
                    allReports = dbHelper.getAllReportsWithUserDetails();
                    displayReports(allReports);
                }
            }

            @Override
            public void onFailure(retrofit2.Call<List<java.util.Map<String, Object>>> call, Throwable t) {
                // Fallback to local
                allReports = dbHelper.getAllReportsWithUserDetails();
                displayReports(allReports);
            }
        });
    }

    private void displayReportsFromApi(List<java.util.Map<String, Object>> reports) {
        reportsListContainer.removeAllViews();
        for (java.util.Map<String, Object> report : reports) {
            addApiReportItem(report);
        }
    }

    private void displayReports(List<DatabaseHelper.ReportWithUser> reports) {
        reportsListContainer.removeAllViews();
        for (DatabaseHelper.ReportWithUser report : reports) {
            addReportItem(report);
        }
    }

    private void addApiReportItem(java.util.Map<String, Object> report) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_admin_report_detailed, reportsListContainer, false);
        
        android.widget.ImageView icon = view.findViewById(R.id.report_icon);
        TextView userName = view.findViewById(R.id.report_user_name);
        TextView moduleName = view.findViewById(R.id.report_module_name);
        TextView riskBadge = view.findViewById(R.id.report_risk_badge);
        TextView date = view.findViewById(R.id.report_date);
        View btnView = view.findViewById(R.id.btn_view_report);

        String type = (String) report.get("module");
        String risk = (String) report.get("risk");
        String uName = (String) report.get("userName");
        String timestampRaw = (String) report.get("timestamp");
        
        // Formatting ISO timestamp for better display
        String timestamp = timestampRaw;
        if (timestampRaw != null && timestampRaw.contains("T")) {
            try {
                // Quick split for readability (YYYY-MM-DD HH:mm)
                String[] parts = timestampRaw.split("T");
                String dateStr = parts[0];
                String timeStr = parts[1].substring(0, 5);
                timestamp = dateStr + " • " + timeStr;
            } catch (Exception e) {
                timestamp = timestampRaw;
            }
        }

        userName.setText(uName);
        moduleName.setText(type);
        date.setText(timestamp);
        riskBadge.setText(risk);

        final String finalTimestamp = timestamp;
        final String finalType = type;
        final String finalUName = uName;
        final String finalRisk = risk;
        final String finalTimestampRaw = timestampRaw;

        // Styling based on risk
        if (risk != null && (risk.contains("Critical") || risk.contains("High") || risk.contains("Severe"))) {
            riskBadge.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FEF2F2")));
            riskBadge.setTextColor(android.graphics.Color.parseColor("#EF4444"));
            icon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FEF2F2")));
            icon.setColorFilter(android.graphics.Color.parseColor("#EF4444"));
        } else if (risk != null && (risk.contains("Medium") || risk.contains("Moderate") || risk.contains("Clinical"))) {
            riskBadge.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FFFBEB")));
            riskBadge.setTextColor(android.graphics.Color.parseColor("#F59E0B"));
            icon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FFFBEB")));
            icon.setColorFilter(android.graphics.Color.parseColor("#F59E0B"));
        } else {
            riskBadge.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#F0FDF4")));
            riskBadge.setTextColor(android.graphics.Color.parseColor("#10B981"));
            icon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#F0FDF4")));
            icon.setColorFilter(android.graphics.Color.parseColor("#10B981"));
        }

        btnView.setOnClickListener(v -> {
            Intent intent = new Intent(this, ReportDetailsActivity.class);
            intent.putExtra("MODULE_NAME", finalType);
            intent.putExtra("USER_NAME", finalUName);
            intent.putExtra("RISK_LEVEL", finalRisk);
            intent.putExtra("TIMESTAMP", finalTimestamp);
            
            Object detailsObj = report.get("details");
            String detailsJson = "{}";
            if (detailsObj instanceof String) {
                detailsJson = (String) detailsObj;
            } else if (detailsObj instanceof java.util.Map) {
                detailsJson = new org.json.JSONObject((java.util.Map) detailsObj).toString();
            }
            intent.putExtra("DETAILS_JSON", detailsJson);
            startActivity(intent);
        });

        view.findViewById(R.id.btn_download_report).setOnClickListener(v -> {
            Object detailsObj = report.get("details");
            String detailsJson = "{}";
            if (detailsObj instanceof String) {
                detailsJson = (String) detailsObj;
            } else if (detailsObj instanceof java.util.Map) {
                detailsJson = new org.json.JSONObject((java.util.Map) detailsObj).toString();
            }
            PDFGenerator.exportUserReport(this, finalUName, finalType, finalRisk, finalTimestamp, detailsJson);
        });

        reportsListContainer.addView(view);
    }

    private void filterReports(String query) {
        if (allReports == null) return;
        List<DatabaseHelper.ReportWithUser> filtered = new ArrayList<>();
        for (DatabaseHelper.ReportWithUser report : allReports) {
            if (report.getUserName().toLowerCase().contains(query.toLowerCase()) || 
                report.getModule().toLowerCase().contains(query.toLowerCase())) {
                filtered.add(report);
            }
        }
        displayReports(filtered);
    }

    private void addReportItem(final DatabaseHelper.ReportWithUser report) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_admin_report_detailed, reportsListContainer, false);

        android.widget.ImageView icon = view.findViewById(R.id.report_icon);
        TextView userName = view.findViewById(R.id.report_user_name);
        TextView moduleName = view.findViewById(R.id.report_module_name);
        TextView riskBadge = view.findViewById(R.id.report_risk_badge);
        TextView date = view.findViewById(R.id.report_date);
        View btnView = view.findViewById(R.id.btn_view_report);

        userName.setText(report.getUserName());
        moduleName.setText(report.getModule() + " Assessment");
        date.setText(report.getTimestamp());
        riskBadge.setText(report.getRisk());

        // Styling based on risk
        if ("Critical".equals(report.getRisk()) || "High".equals(report.getRisk())) {
            riskBadge.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FEF2F2")));
            riskBadge.setTextColor(android.graphics.Color.parseColor("#EF4444"));
            icon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FEF2F2")));
            icon.setColorFilter(android.graphics.Color.parseColor("#EF4444"));
        } else if ("Medium".equals(report.getRisk())) {
            riskBadge.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FFFBEB")));
            riskBadge.setTextColor(android.graphics.Color.parseColor("#F59E0B"));
            icon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FFFBEB")));
            icon.setColorFilter(android.graphics.Color.parseColor("#F59E0B"));
        } else {
            riskBadge.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#F0FDF4")));
            riskBadge.setTextColor(android.graphics.Color.parseColor("#10B981"));
            icon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#F0FDF4")));
            icon.setColorFilter(android.graphics.Color.parseColor("#10B981"));
        }

        // Set icon based on module
        if (report.getModule().toLowerCase().contains("heart")) {
            icon.setImageResource(R.drawable.ic_heart_logo);
        } else if (report.getModule().toLowerCase().contains("kidney")) {
            icon.setImageResource(R.drawable.ic_lightning); // Placeholder
        } else if (report.getModule().toLowerCase().contains("lung")) {
            icon.setImageResource(R.drawable.ic_wind_logo);
        } else if (report.getModule().toLowerCase().contains("cancer")) {
            icon.setImageResource(R.drawable.ic_pill);
        } else if (report.getModule().toLowerCase().contains("liver")) {
            icon.setImageResource(R.drawable.ic_lightning);
        } else if (report.getModule().toLowerCase().contains("alzheimer")) {
            icon.setImageResource(R.drawable.ic_bulb);
        }

        btnView.setOnClickListener(v -> {
            Intent intent = new Intent(this, ReportDetailsActivity.class);
            intent.putExtra("MODULE_NAME", report.getModule());
            intent.putExtra("USER_NAME", report.getUserName());
            intent.putExtra("RISK_LEVEL", report.getRisk());
            intent.putExtra("TIMESTAMP", report.getTimestamp());
            intent.putExtra("DETAILS_JSON", report.getDetails());
            startActivity(intent);
        });

        view.findViewById(R.id.btn_download_report).setOnClickListener(v -> 
            PDFGenerator.exportUserReport(this, report.getUserName(), report.getModule(), report.getRisk(), report.getTimestamp(), report.getDetails()));

        reportsListContainer.addView(view);
    }
}
