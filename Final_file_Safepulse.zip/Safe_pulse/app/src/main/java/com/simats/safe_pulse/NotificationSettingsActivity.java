package com.simats.safe_pulse;

import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

public class NotificationSettingsActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private static final String PREFS_NAME = "NotificationPrefs";

    private SwitchCompat switchPush, switchEmail, switchSound, switchHealth, 
                         switchAssess, switchMeds, switchProgress, switchUpdates, switchDnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Initialize Switches
        switchPush = findViewById(R.id.switch_push);
        switchEmail = findViewById(R.id.switch_email);
        switchSound = findViewById(R.id.switch_sound);
        switchHealth = findViewById(R.id.switch_health_alerts);
        switchAssess = findViewById(R.id.switch_assessment);
        switchMeds = findViewById(R.id.switch_meds);
        switchProgress = findViewById(R.id.switch_progress);
        switchUpdates = findViewById(R.id.switch_updates);
        switchDnd = findViewById(R.id.switch_dnd);

        // Load States
        loadSwitchStates();

        // Setup Linkage
        TextView btnBack = findViewById(R.id.btn_back);
        View btnSave = findViewById(R.id.btn_save_preferences);

        btnBack.setOnClickListener(v -> finish());
        btnSave.setOnClickListener(v -> saveSwitchStates());

        // Setup Listeners for visual feedback
        setupSwitchListener(switchPush, "@color/notif_blue");
        setupSwitchListener(switchEmail, "@color/notif_pink");
        setupSwitchListener(switchSound, "#0EA5E9"); // Default blue if not specified
        setupSwitchListener(switchHealth, "@color/notif_orange");
        setupSwitchListener(switchAssess, "@color/notif_blue");
        setupSwitchListener(switchMeds, "@color/notif_pink");
        setupSwitchListener(switchProgress, "@color/notif_green");
        setupSwitchListener(switchUpdates, "@color/notif_purple");
        setupSwitchListener(switchDnd, "@color/notif_purple");
    }

    private void setupSwitchListener(SwitchCompat s, String colorStr) {
        int color;
        if (colorStr.startsWith("@color/")) {
            int resId = getResources().getIdentifier(colorStr.substring(7), "color", getPackageName());
            color = ContextCompat.getColor(this, resId);
        } else {
            color = Color.parseColor(colorStr);
        }

        updateSwitchColors(s, color);
        s.setOnCheckedChangeListener((buttonView, isChecked) -> updateSwitchColors(s, color));
    }

    private void updateSwitchColors(SwitchCompat s, int colorOn) {
        int colorOff = Color.parseColor("#E2E8F0");
        int thumbOff = Color.WHITE;
        
        int[][] states = new int[][] {
            new int[] {android.R.attr.state_checked},
            new int[] {-android.R.attr.state_checked}
        };

        int[] thumbColors = new int[] { colorOn, thumbOff };
        int[] trackColors = new int[] { Color.argb(128, Color.red(colorOn), Color.green(colorOn), Color.blue(colorOn)), colorOff };

        s.setThumbTintList(new ColorStateList(states, thumbColors));
        s.setTrackTintList(new ColorStateList(states, trackColors));
    }

    private void loadSwitchStates() {
        switchPush.setChecked(prefs.getBoolean("push", true));
        switchEmail.setChecked(prefs.getBoolean("email", true));
        switchSound.setChecked(prefs.getBoolean("sound", false));
        switchHealth.setChecked(prefs.getBoolean("health", true));
        switchAssess.setChecked(prefs.getBoolean("assess", true));
        switchMeds.setChecked(prefs.getBoolean("meds", true));
        switchProgress.setChecked(prefs.getBoolean("progress", true));
        switchUpdates.setChecked(prefs.getBoolean("updates", true));
        switchDnd.setChecked(prefs.getBoolean("dnd", true));
    }

    private void saveSwitchStates() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("push", switchPush.isChecked());
        editor.putBoolean("email", switchEmail.isChecked());
        editor.putBoolean("sound", switchSound.isChecked());
        editor.putBoolean("health", switchHealth.isChecked());
        editor.putBoolean("assess", switchAssess.isChecked());
        editor.putBoolean("meds", switchMeds.isChecked());
        editor.putBoolean("progress", switchProgress.isChecked());
        editor.putBoolean("updates", switchUpdates.isChecked());
        editor.putBoolean("dnd", switchDnd.isChecked());
        editor.apply();

        Toast.makeText(this, "Notification preferences saved!", Toast.LENGTH_SHORT).show();
        finish();
    }
}
