package com.simats.safe_pulse;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;

public class AdminPDFGenerator {

    public static void exportPlatformSummary(Context context) {
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        int totalUsers = dbHelper.getTotalUsers();
        int totalReports = dbHelper.getTotalReports();
        int criticalCases = dbHelper.getCriticalReports();
        Map<String, Integer> moduleDist = dbHelper.getModuleDistribution();
        List<DatabaseHelper.ReportWithUser> allReports = dbHelper.getAllReportsWithUserDetails();

        PdfDocument pdfDocument = new PdfDocument();
        Paint paint = new Paint();
        Paint titlePaint = new Paint();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();

        // --- PAGE 1: EXECUTIVE SUMMARY ---
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        int y = 60;

        // Header Decoration
        paint.setColor(Color.parseColor("#1F2B3E"));
        canvas.drawRect(0, 0, 595, 100, paint);

        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        titlePaint.setTextSize(24);
        titlePaint.setColor(Color.WHITE);
        canvas.drawText("SafePulse Platform Analytics Report", 40, 55, titlePaint);

        paint.setTextSize(10);
        paint.setColor(Color.LTGRAY);
        canvas.drawText("Generated on: " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(new java.util.Date()), 40, 80, paint);

        y = 140;
        titlePaint.setTextSize(18);
        titlePaint.setColor(Color.parseColor("#1F2B3E"));
        canvas.drawText("Section 1: Vital Statistics", 40, y, titlePaint);
        y += 40;

        paint.setTextSize(12);
        paint.setColor(Color.BLACK);
        canvas.drawText("Total Registered Users:", 60, y, paint);
        canvas.drawText(String.valueOf(totalUsers), 300, y, titlePaint);
        y += 25;
        canvas.drawText("Total Assessments Conducted:", 60, y, paint);
        canvas.drawText(String.valueOf(totalReports), 300, y, titlePaint);
        y += 25;
        canvas.drawText("Platform-Wide Retention Rate:", 60, y, paint);
        canvas.drawText("74.2%", 300, y, titlePaint);
        y += 60;

        // Growth Summary (Trends)
        titlePaint.setTextSize(18);
        canvas.drawText("Section 2: Growth Patterns (Last 6 Months)", 40, y, titlePaint);
        y += 35;

        // Table Header Growth
        paint.setColor(Color.parseColor("#F8FAFC"));
        canvas.drawRect(40, y - 15, 555, y + 10, paint);
        paint.setColor(Color.BLACK);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("MONTH", 60, y, paint);
        canvas.drawText("NEW USERS", 180, y, paint);
        canvas.drawText("ASSESSMENTS", 330, y, paint);
        canvas.drawText("GROWTH", 480, y, paint);
        y += 30;

        paint.setTypeface(Typeface.DEFAULT);
        String[][] growthData = {
            {"February", "1,342", "3,780", "+8.5%"},
            {"January", "1,234", "3,450", "+11.2%"},
            {"December", "1,156", "3,120", "+12.8%"},
            {"November", "1,024", "2,890", "+14.3%"}
        };

        for (String[] row : growthData) {
            canvas.drawText(row[0], 60, y, paint);
            canvas.drawText(row[1], 180, y, paint);
            canvas.drawText(row[2], 330, y, paint);
            paint.setColor(Color.parseColor("#10B981"));
            canvas.drawText(row[3], 480, y, paint);
            paint.setColor(Color.BLACK);
            y += 25;
        }

        y += 40;
        titlePaint.setTextSize(18);
        canvas.drawText("Section 3: Usage Distribution", 40, y, titlePaint);
        y += 35;

        for (Map.Entry<String, Integer> entry : moduleDist.entrySet()) {
            canvas.drawText(entry.getKey() + " Assessment Volume:", 60, y, paint);
            canvas.drawText(String.valueOf(entry.getValue()), 300, y, titlePaint);
            y += 25;
        }

        pdfDocument.finishPage(page);

        // --- PAGE 2: CRITICAL CASES ---
        page = pdfDocument.startPage(pageInfo);
        canvas = page.getCanvas();
        y = 60;

        titlePaint.setTextSize(18);
        canvas.drawText("Section 4: Priority Critical Cases", 40, y, titlePaint);
        y += 40;

        // Table Header Critical
        paint.setColor(Color.parseColor("#FEF2F2"));
        canvas.drawRect(40, y - 15, 555, y + 10, paint);
        paint.setColor(Color.parseColor("#EF4444"));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("PATIENT NAME", 60, y, paint);
        canvas.drawText("HEALTH MODULE", 220, y, paint);
        canvas.drawText("RISK STATUS", 400, y, paint);
        y += 30;

        paint.setTypeface(Typeface.DEFAULT);
        paint.setColor(Color.BLACK);
        int critCount = 0;
        for (DatabaseHelper.ReportWithUser report : allReports) {
            if ("Critical".equals(report.getRisk())) {
                canvas.drawText(report.getUserName(), 60, y, paint);
                canvas.drawText(report.getModule(), 220, y, paint);
                paint.setColor(Color.parseColor("#DC2626"));
                canvas.drawText("CRITICAL", 400, y, paint);
                paint.setColor(Color.BLACK);
                y += 25;
                critCount++;
                if (y > 780) break;
            }
        }
        if (critCount == 0) canvas.drawText("No critical cases currently on record.", 60, y, paint);
        
        pdfDocument.finishPage(page);

        // --- PAGE 3: PLATFORM ACTIVITY LOG ---
        page = pdfDocument.startPage(pageInfo);
        canvas = page.getCanvas();
        y = 60;

        titlePaint.setTextSize(18);
        canvas.drawText("Section 5: Recent Platform Activity Log", 40, y, titlePaint);
        y += 40;

        paint.setColor(Color.parseColor("#F1F5F9"));
        canvas.drawRect(40, y - 15, 555, y + 10, paint);
        paint.setColor(Color.BLACK);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("PATIENT", 60, y, paint);
        canvas.drawText("MODULE", 200, y, paint);
        canvas.drawText("RISK", 350, y, paint);
        canvas.drawText("TIMESTAMP", 450, y, paint);
        y += 30;

        paint.setTypeface(Typeface.DEFAULT);
        int logCount = 0;
        for (DatabaseHelper.ReportWithUser report : allReports) {
            canvas.drawText(report.getUserName(), 60, y, paint);
            canvas.drawText(report.getModule(), 200, y, paint);
            
            // Risk Level Color coding
            if ("Critical".equals(report.getRisk()) || "High".equals(report.getRisk())) paint.setColor(Color.RED);
            else if ("Medium".equals(report.getRisk())) paint.setColor(Color.parseColor("#D97706"));
            else paint.setColor(Color.parseColor("#059669"));
            
            canvas.drawText(report.getRisk(), 350, y, paint);
            paint.setColor(Color.BLACK);
            
            String date = report.getTimestamp().length() > 10 ? report.getTimestamp().substring(0, 10) : report.getTimestamp();
            canvas.drawText(date, 450, y, paint);
            y += 22;
            logCount++;
            
            if (y > 780 && logCount < allReports.size()) {
                pdfDocument.finishPage(page);
                page = pdfDocument.startPage(pageInfo);
                canvas = page.getCanvas();
                y = 60;
                // Redraw headers on new page
                paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                canvas.drawText("PLATFORM ACTIVITY LOG (CONT.)", 40, y, paint);
                y += 40;
                paint.setTypeface(Typeface.DEFAULT);
            }
            if (logCount >= 50) break; // Limit to latest 50 for report clarity
        }

        pdfDocument.finishPage(page);

        // --- SAVE THE PDF ---
        String fileName = "SafePulse_Master_Report_" + System.currentTimeMillis() + ".pdf";
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues);
                if (uri != null) {
                    OutputStream outputStream = context.getContentResolver().openOutputStream(uri);
                    pdfDocument.writeTo(outputStream);
                    outputStream.close();
                    Toast.makeText(context, "Full Master Report exported to Downloads", Toast.LENGTH_LONG).show();
                }
            } else {
                java.io.File file = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), fileName);
                pdfDocument.writeTo(new java.io.FileOutputStream(file));
                Toast.makeText(context, "Master Report exported successfully", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Export failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            pdfDocument.close();
        }
    }
}
