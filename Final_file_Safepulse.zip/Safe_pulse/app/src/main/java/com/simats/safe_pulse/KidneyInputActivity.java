package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class KidneyInputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_kidney_input);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView backButton = findViewById(R.id.btn_back);
        Button calculateButton = findViewById(R.id.btn_calculate);
        
        EditText creatinineInput = findViewById(R.id.input_creatinine);
        EditText gfrInput = findViewById(R.id.input_gfr);
        EditText ureaInput = findViewById(R.id.input_urea);
        Spinner proteinSpinner = findViewById(R.id.spinner_protein);

        // Setup Urine Protein Spinner
        String[] proteinOptions = {"Absent", "Present"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, proteinOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        proteinSpinner.setAdapter(adapter);

        // Back Logic
        backButton.setOnClickListener(v -> finish());

        // Calculate Logic
        calculateButton.setOnClickListener(v -> {
            String creatinine = creatinineInput.getText().toString().trim();
            String gfr = gfrInput.getText().toString().trim();
            String urea = ureaInput.getText().toString().trim();
            String protein = proteinSpinner.getSelectedItem().toString();

            if (creatinine.isEmpty() || gfr.isEmpty() || urea.isEmpty()) {
                Toast.makeText(this, "Please enter all values", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(KidneyInputActivity.this, KidneyResultActivity.class);
                intent.putExtra("eGFR", gfr);
                intent.putExtra("PROTEIN", protein);
                intent.putExtra("CREATININE", creatinine);
                intent.putExtra("UREA", urea);
                startActivity(intent);
            }
        });
    }
}
