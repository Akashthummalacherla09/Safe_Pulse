package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AlzheimerInputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_alzheimer_input);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView backBtn = findViewById(R.id.btn_back_alz_input);
        Button calculateBtn = findViewById(R.id.btn_calculate_alz);
        
        EditText scoreInput = findViewById(R.id.input_score);
        EditText ageInput = findViewById(R.id.input_age);
        
        Spinner clinicalSpinner = findViewById(R.id.spinner_clinical);
        Spinner familySpinner = findViewById(R.id.spinner_family);

        // Setup Spinners
        ArrayAdapter<CharSequence> clinicalAdapter = ArrayAdapter.createFromResource(this,
                R.array.clinical_assessment_options, android.R.layout.simple_spinner_item);
        clinicalAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        clinicalSpinner.setAdapter(clinicalAdapter);

        ArrayAdapter<CharSequence> familyAdapter = ArrayAdapter.createFromResource(this,
                R.array.family_history_options, android.R.layout.simple_spinner_item);
        familyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        familySpinner.setAdapter(familyAdapter);


        // Listeners
        backBtn.setOnClickListener(v -> finish());

        calculateBtn.setOnClickListener(v -> {
            String scoreStr = scoreInput.getText().toString().trim();
            String ageStr = ageInput.getText().toString().trim();
            String clinical = clinicalSpinner.getSelectedItem().toString();
            String family = familySpinner.getSelectedItem().toString();

            if (scoreStr.isEmpty() || ageStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }
            
            try {
                int score = Integer.parseInt(scoreStr);
                int age = Integer.parseInt(ageStr);
                
                if (score > 30) {
                     Toast.makeText(this, "Score cannot be greater than 30", Toast.LENGTH_SHORT).show();
                     return;
                }

                // Navigate to Result Activity
                Intent intent = new Intent(AlzheimerInputActivity.this, AlzheimerResultActivity.class);
                intent.putExtra("SCORE", score);
                intent.putExtra("AGE", age);
                intent.putExtra("CLINICAL", clinical);
                intent.putExtra("FAMILY", family);
                startActivity(intent);
                finish(); // Close input form
                
            } catch (NumberFormatException e) {
                 Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
