package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPasswordActivity extends AppCompatActivity {
    
    private HealthDataRepository repository;
    private EditText emailInput;
    private Button btnSendCode;
    private TextView btnContactSupport;
    private LinearLayout btnBack;
    private Button btnCreateAccount; // New button for users not found

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forgot_password);
        repository = HealthDataRepository.getInstance(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initViews();
        setupListeners();
    }

    private void initViews() {
        emailInput = findViewById(R.id.input_email_forgot);
        btnSendCode = findViewById(R.id.btn_send_code);
        btnContactSupport = findViewById(R.id.btn_contact_support);
        btnBack = findViewById(R.id.btn_back);
        
        // Let's create a dynamic visibility for account creation button
        btnCreateAccount = findViewById(R.id.btn_create_account_instead);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnSendCode.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            if (email.isEmpty()) {
                Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show();
            } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            } else {
                handlePasswordResetCheck(email);
            }
        });

        if (btnCreateAccount != null) {
            btnCreateAccount.setOnClickListener(v -> {
                startActivity(new Intent(this, CreateAccountActivity.class));
            });
        }

        btnContactSupport.setOnClickListener(v -> {
            Toast.makeText(this, "Redirecting to support...", Toast.LENGTH_SHORT).show();
            // Could open dialer or email intent
        });
    }

    private void handlePasswordResetCheck(String email) {
        btnSendCode.setEnabled(false);
        btnSendCode.setText("VERIFYING...");

        // 1. Check Backend First
        Map<String, String> request = new HashMap<>();
        request.put("email", email);

        RetrofitClient.getApiService().checkEmail(request).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                btnSendCode.setEnabled(true);
                btnSendCode.setText("SEND RECOVERY CODE");

                boolean exists = false;
                if (response.isSuccessful() && response.body() != null) {
                    exists = (boolean) response.body().get("exists");
                }

                if (exists) {
                    Toast.makeText(ForgotPasswordActivity.this, "Identity Verified. Proceeding to reset.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(ForgotPasswordActivity.this, CreateNewPasswordActivity.class);
                    intent.putExtra("EMAIL", email);
                    startActivity(intent);
                } else {
                    // 2. Fallback to Local Check
                    if (repository.isEmailRegistered(email)) {
                         Toast.makeText(ForgotPasswordActivity.this, "Account Found Locally. Proceeding to reset.", Toast.LENGTH_SHORT).show();
                         Intent intent = new Intent(ForgotPasswordActivity.this, CreateNewPasswordActivity.class);
                         intent.putExtra("EMAIL", email);
                         startActivity(intent);
                    } else {
                         Toast.makeText(ForgotPasswordActivity.this, "No record found with this email. Please Create New Account.", Toast.LENGTH_LONG).show();
                         if (btnCreateAccount != null) {
                             btnCreateAccount.setVisibility(View.VISIBLE);
                             btnSendCode.setVisibility(View.GONE);
                         }
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                btnSendCode.setEnabled(true);
                btnSendCode.setText("SEND RECOVERY CODE");
                
                // Fallback to local check on failure
                if (repository.isEmailRegistered(email)) {
                     Toast.makeText(ForgotPasswordActivity.this, "Verified via local storage.", Toast.LENGTH_SHORT).show();
                     Intent intent = new Intent(ForgotPasswordActivity.this, CreateNewPasswordActivity.class);
                     intent.putExtra("EMAIL", email);
                     startActivity(intent);
                } else {
                     Toast.makeText(ForgotPasswordActivity.this, "Connection Error. No local record found.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
