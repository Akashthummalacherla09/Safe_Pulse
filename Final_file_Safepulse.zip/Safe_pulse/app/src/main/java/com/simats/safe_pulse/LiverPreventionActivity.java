package com.simats.safe_pulse;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LiverPreventionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_liver_prevention);

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });

            String riskLevel = getIntent().getStringExtra("RISK_LEVEL");
            if (riskLevel == null) {
                riskLevel = "Low Risk";
            } else {
                riskLevel = riskLevel.trim();
            }

            displayDynamicTips(riskLevel);

            // Navigation
            findViewById(R.id.btn_back_prev).setOnClickListener(v -> finish());
            
            findViewById(R.id.btn_dashboard_prev).setOnClickListener(v -> {
                Intent intent = new Intent(LiverPreventionActivity.this, UserDashboardActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        } catch (Exception e) {
            android.util.Log.e("LiverPrev", "Error in onCreate", e);
            Toast.makeText(this, "Screen Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void displayDynamicTips(String riskLevel) {
        try {
            LinearLayout container = findViewById(R.id.container_strategies);
            if (container == null) return;
            container.removeAllViews();

            // Define colors
            int colorRedBar = Color.parseColor("#E53935");
            int colorGreenBar = Color.parseColor("#43A047");
            
            int colorRedTitle = Color.parseColor("#B71C1C");
            int colorGreenTitle = Color.parseColor("#1B5E20");
            
            int colorRedDesc = Color.parseColor("#C62828");
            int colorGreenDesc = Color.parseColor("#2E7D32");
            
            int colorRedBg = Color.parseColor("#FFEBEE");
            int colorGreenBg = Color.parseColor("#E8F5E9");

            // Logic based on Risk Level
            if (riskLevel.contains("High") || riskLevel.contains("Severe")) {
                // High Risk Tips
                addTipCard(container, "Avoid Alcohol Completely", 
                    "Alcohol is extremely dangerous for your liver at this stage. Complete abstinence is mandatory.",
                    new String[]{
                        "Seek immediate medical support if you struggle with alcohol",
                        "Join support groups (AA, SMART Recovery)",
                        "Inform family and friends about your abstinence"
                    }, 
                    colorRedTitle, colorRedDesc, colorRedBg, colorRedBar);

                addTipCard(container, "Strict Liver Diet", 
                    "Provide your liver with the nutrients it needs to recover and avoid further stress.",
                    new String[]{
                        "Strictly limit salt intake to avoid fluid build-up",
                        "Eat small, frequent meals to ease digestion",
                        "Avoid raw shellfish and processed foods"
                    }, 
                    colorGreenTitle, colorGreenDesc, colorGreenBg, colorGreenBar);

            } else if (riskLevel.contains("Moderate") || riskLevel.contains("Moderate")) {
                // Moderate Risk Tips
                addTipCard(container, "Avoid Alcohol", 
                    "Alcohol is the leading cause of liver damage. Complete abstinence is best for liver health.",
                    new String[]{
                        "Even moderate drinking can harm the liver",
                        "Seek support if you struggle with alcohol",
                        "Consider support groups (AA, SMART Recovery)"
                    }, 
                    colorRedTitle, colorRedDesc, colorRedBg, colorRedBar);

                addTipCard(container, "Healthy Diet", 
                    "Nutrition is crucial for liver health and recovery.",
                    new String[]{
                        "Eat plenty of fruits and vegetables",
                        "Choose lean proteins and whole grains",
                        "Avoid processed foods and excess sugar"
                    }, 
                    colorGreenTitle, colorGreenDesc, colorGreenBg, colorGreenBar);

            } else {
                // Low Risk Tips
                addTipCard(container, "Liver Maintenance", 
                    "Maintain your healthy liver function with balanced habits.",
                    new String[]{
                        "Limit alcohol consumption strictly",
                        "Maintain a healthy weight through diet and exercise",
                        "Stay hydrated (8-10 glasses/day)"
                    }, 
                    colorGreenTitle, colorGreenDesc, colorGreenBg, colorGreenBar);

                addTipCard(container, "Avoid Toxins", 
                    "Be mindful of substances that can stress your liver.",
                    new String[]{
                        "Be careful with medications (like Paracetamol)",
                        "Avoid unnecessary herbal supplements",
                        "Ensure regular screening every year"
                    }, 
                    colorGreenTitle, colorGreenDesc, colorNeutralBg(), colorGreenBar);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int colorNeutralBg() {
        return Color.parseColor("#F8F9FA");
    }

    private void addTipCard(LinearLayout container, String title, String desc, String[] bullets, int titleColor, int descColor, int bgColor, int barColor) {
        try {
            View cardView = getLayoutInflater().inflate(R.layout.item_prevention_tip, container, false);

            LinearLayout bgLayout = cardView.findViewById(R.id.tip_bg);
            bgLayout.setBackgroundColor(bgColor);

            View barView = cardView.findViewById(R.id.tip_bar);
            barView.setBackgroundColor(barColor);

            TextView tvTitle = cardView.findViewById(R.id.tip_title);
            tvTitle.setText(title);
            tvTitle.setTextColor(titleColor);

            TextView tvDesc = cardView.findViewById(R.id.tip_desc);
            tvDesc.setText(desc);
            tvDesc.setTextColor(descColor);

            LinearLayout bulletsContainer = cardView.findViewById(R.id.tip_bullets_container);
            for (String bullet : bullets) {
                TextView tvBullet = new TextView(this);
                tvBullet.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                tvBullet.setText("• " + bullet);
                tvBullet.setTextColor(descColor);
                tvBullet.setTextSize(14);
                tvBullet.setPadding(0, 4, 0, 4);
                bulletsContainer.addView(tvBullet);
            }

            container.addView(cardView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
