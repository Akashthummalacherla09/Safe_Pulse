package com.simats.safe_pulse;

import android.content.Context;
import android.util.Log;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HealthDataRepository {

    private static HealthDataRepository instance;
    private final DatabaseHelper dbHelper;
    private final Context context;

    private HealthDataRepository(Context context) {
        this.dbHelper = new DatabaseHelper(context);
        this.context = context.getApplicationContext();
    }

    public static synchronized HealthDataRepository getInstance(Context context) {
        if (instance == null) {
            instance = new HealthDataRepository(context.getApplicationContext());
        }
        return instance;
    }

    private ApiService getApi() {
        return RetrofitClient.getApiService(context);
    }

    public void saveAssessmentResult(int userId, String module, int score, String risk, String data) {
        dbHelper.addReport(userId, module, score, risk, data);
        
        // Sync with Remote
        Map<String, Object> payload = new HashMap<>();
        payload.put("assessment_type", module.toLowerCase());
        payload.put("score", score);
        
        try {
            org.json.JSONObject jsonObject = new org.json.JSONObject(data);
            Map<String, Object> inputsMap = new HashMap<>();
            java.util.Iterator<String> keys = jsonObject.keys();
            while(keys.hasNext()) {
                String key = keys.next();
                inputsMap.put(key, jsonObject.get(key));
            }
            payload.put("inputs", inputsMap);
        } catch (Exception e) {
            payload.put("inputs", new HashMap<>());
        }

        getApi().createAssessment(payload).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful()) {
                    Log.d("SYNC", "Assessment sync successful");
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                Log.e("SYNC", "Assessment sync failed", t);
            }
        });
    }

    public void updateHealthTracker(TrackerRequest tracker) {
        getApi().createTracker(tracker).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful()) {
                    Log.d("SYNC", "Tracker sync successful");
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                Log.e("SYNC", "Tracker sync failed", t);
            }
        });
    }

    public interface OnSyncCompleteListener {
        void onSyncComplete();
    }

    public void syncAllData() {
        syncAllData(null);
    }

    public void syncAllData(final OnSyncCompleteListener listener) {
        if (getApi() == null) {
            if (listener != null) listener.onSyncComplete();
            return;
        }

        getApi().syncData(new java.util.HashMap<>()).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> body = response.body();
                    final int userId = context.getSharedPreferences("UserSession", context.MODE_PRIVATE).getInt("USER_ID", -1);
                    
                    if (userId != -1) {
                        dbHelper.deleteReportsByUserId(userId);
                    }
                    
                    // Sync Assessments
                    if (userId != -1 && body.containsKey("assessments") && body.get("assessments") != null) {
                        try {
                            java.util.List<Map<String, Object>> assessments = (java.util.List<Map<String, Object>>) body.get("assessments");
                            for (Map<String, Object> r : assessments) {
                                String module = (String) r.get("assessment_type");
                                int score = r.get("score") != null ? ((Number) r.get("score")).intValue() : 0;
                                
                                // Extract risk from results object
                                String risk = "N/A";
                                if (r.containsKey("results") && r.get("results") instanceof Map) {
                                    Map<String, Object> resObj = (Map<String, Object>) r.get("results");
                                    risk = (String) resObj.get("riskLevel");
                                }
                                
                                String details = r.containsKey("inputs") && r.get("inputs") != null ? r.get("inputs").toString() : null;
                                String timestamp = (String) r.get("timestamp"); 
                                if (timestamp == null) timestamp = (String) r.get("created_at"); // Fallback
                                
                                dbHelper.addReportUnique(userId, module, score, risk, details, timestamp);
                            }
                        } catch (Exception e) {
                            Log.e("SYNC", "Error parsing assessments", e);
                        }
                    }

                    // Sync Tracker
                    if (body.containsKey("tracker") && body.get("tracker") != null) {
                        try {
                            List<Map<String, Object>> trackerLogs = (List<Map<String, Object>>) body.get("tracker");
                            android.content.SharedPreferences trackerPrefs = context.getSharedPreferences("DailyTrackerPrefs", Context.MODE_PRIVATE);
                            android.content.SharedPreferences.Editor editor = trackerPrefs.edit();
                            
                            for (Map<String, Object> log : trackerLogs) {
                                String date = (String) log.get("date");
                                if (date == null) continue;
                                
                                editor.putFloat(date + "_water", log.get("water") != null ? ((Number) log.get("water")).floatValue() : 0.0f);
                                editor.putBoolean(date + "_smoked", log.get("smoked") != null ? (Boolean) log.get("smoked") : false);
                                editor.putString(date + "_steps", log.get("steps") != null ? String.valueOf(log.get("steps")) : "0");
                                editor.putString(date + "_sleep", log.get("sleep") != null ? String.valueOf(log.get("sleep")) : "0");
                                editor.putString(date + "_calories", log.get("calories") != null ? String.valueOf(log.get("calories")) : "0");
                                editor.putString(date + "_weight", log.get("weight") != null ? String.valueOf(log.get("weight")) : "0");
                                editor.putString(date + "_systolic", log.get("systolic") != null ? String.valueOf(log.get("systolic")) : "0");
                                editor.putString(date + "_diastolic", log.get("diastolic") != null ? String.valueOf(log.get("diastolic")) : "0");
                                
                                // Also save tracker score as a report module for overall health score consistency
                                int trackerScore = log.get("score") != null ? ((Number) log.get("score")).intValue() : 0;
                                String status = trackerScore > 80 ? "Excellent" : trackerScore > 50 ? "Moderate" : "Needs Improvement";
                                
                                // Save locally in module reports too
                                HealthScoreManager.saveModuleScoreLocalOnly(context, "daily_tracker", trackerScore, status);
                            }
                            editor.apply();
                        } catch (Exception e) {
                            Log.e("SYNC", "Error parsing tracker logs", e);
                        }
                    }

                    Log.d("SYNC", "Full data sync successful for user: " + userId);
                }
                if (listener != null) listener.onSyncComplete();
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                Log.e("SYNC", "Full data sync failed", t);
            }
        });
    }

    // Existing local methods...
    public boolean isEmailRegistered(String email) { return dbHelper.checkUserExistsByEmail(email); }
    public int getTotalUsers() { return dbHelper.getTotalUsers(); }
    public List<DatabaseHelper.ReportWithUser> getAllReports() { return dbHelper.getAllReportsWithUserDetails(); }
    public List<DatabaseHelper.Report> getReportsByUserId(int userId) { return dbHelper.getReportsByUserId(userId); }
    public int calculateOverallScore(int userId) { return HealthScoreManager.calculateScoreByUserId(dbHelper, userId); }

    public java.util.Map<String, Integer> getRiskDistribution() { return dbHelper.getRiskDistribution(); }
    public java.util.Map<String, Integer> getModuleDistribution() { return dbHelper.getModuleDistribution(); }
    public int getReportCount() { return dbHelper.getReportCount(); }
    public int getCriticalReports() { return dbHelper.getCriticalReports(); }
    public int getActiveToday() { return dbHelper.getActiveToday(); }
    public boolean updatePassword(String email, String newPassword) { return dbHelper.updatePassword(email, newPassword); }

    public void clearLocalReports(int userId) {
        dbHelper.deleteUser(userId); // Reusing deleteUser which clears user and reports
    }
}
