package com.simats.safe_pulse;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SettingsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);

        dbHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Setup User Data
        setupUserData();

        // Click Listeners
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
        
        findViewById(R.id.card_profile_overview).setOnClickListener(v -> {
            startActivity(new Intent(SettingsActivity.this, UserProfileActivity.class));
        });

        findViewById(R.id.btn_notifications_settings).setOnClickListener(v -> 
            startActivity(new Intent(SettingsActivity.this, NotificationSettingsActivity.class)));

        findViewById(R.id.btn_privacy_settings).setOnClickListener(v -> 
            startActivity(new Intent(SettingsActivity.this, PrivacyPolicyActivity.class)));

        findViewById(R.id.btn_help_settings).setOnClickListener(v -> 
            startActivity(new Intent(SettingsActivity.this, HelpSupportActivity.class)));

        findViewById(R.id.btn_about_settings).setOnClickListener(v -> 
            startActivity(new Intent(SettingsActivity.this, AboutActivity.class)));

        findViewById(R.id.btn_sign_out).setOnClickListener(v -> signOut());
    }

    private void setupUserData() {
        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        int userId = prefs.getInt("USER_ID", -1);
        String sessionName = prefs.getString("USER_NAME", null);
        String sessionEmail = prefs.getString("USER_EMAIL", null);

        TextView nameText = findViewById(R.id.text_user_name);
        TextView emailText = findViewById(R.id.text_user_email);
        TextView avatarText = findViewById(R.id.text_avatar);

        String finalName = "User";
        String finalEmail = "Not logged in";

        if (sessionName != null && !sessionName.isEmpty()) {
            finalName = sessionName;
            finalEmail = sessionEmail != null ? sessionEmail : "";
        } else if (userId != -1) {
            DatabaseHelper.User user = dbHelper.getUserById(userId);
            if (user != null) {
                finalName = user.getName();
                finalEmail = user.getEmail();
            }
        }

        nameText.setText(finalName);
        emailText.setText(finalEmail);
        
        // Setup Avatar
        if (finalName != null && !finalName.isEmpty()) {
            String initials = "";
            String[] parts = finalName.trim().split("\\s+");
            if (parts.length > 0 && !parts[0].isEmpty()) {
                initials += parts[0].substring(0, 1).toUpperCase();
            }
            if (parts.length > 1 && !parts[1].isEmpty()) {
                initials += parts[1].substring(0, 1).toUpperCase();
            }
            if (initials.isEmpty()) initials = "U";
            avatarText.setText(initials);
        }
    }

    private void signOut() {
        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        prefs.edit().clear().apply();
        
        Intent intent = new Intent(SettingsActivity.this, RoleSelectionActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
        Toast.makeText(this, "Signed out successfully", Toast.LENGTH_SHORT).show();
    }
}
