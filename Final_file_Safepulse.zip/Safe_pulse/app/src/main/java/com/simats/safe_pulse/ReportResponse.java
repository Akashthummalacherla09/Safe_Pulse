package com.simats.safe_pulse;

import com.google.gson.annotations.SerializedName;

public class ReportResponse {
    @SerializedName("id")
    private int id;
    
    @SerializedName("assessment_type")
    private String assessmentType;

    @SerializedName("score")
    private int score;

    @SerializedName("result")
    private String result;

    @SerializedName("created_at")
    private String createdAt;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getAssessmentType() { return assessmentType; }
    public void setAssessmentType(String assessmentType) { this.assessmentType = assessmentType; }
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
