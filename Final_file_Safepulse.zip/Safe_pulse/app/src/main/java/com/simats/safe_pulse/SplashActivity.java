package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // ONE-TIME GLOBAL FIX: Nanosurgically wipe all corrupt Ghost SharedPreferences from the user device
        getSharedPreferences("HealthScorePrefs_1", MODE_PRIVATE).edit().clear().apply();
        getSharedPreferences("HealthScorePrefs_-1", MODE_PRIVATE).edit().clear().apply();
        getSharedPreferences("DailyTrackerPrefs", MODE_PRIVATE).edit().clear().apply();
        getSharedPreferences("WeeklyHistory_1", MODE_PRIVATE).edit().clear().apply();

        // Delay for 3 seconds and navigate to MainActivity
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, RoleSelectionActivity.class);
            startActivity(intent);
            finish();
        }, 3000);
    }
}
