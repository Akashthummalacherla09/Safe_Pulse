package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;
import android.os.Build;
import android.content.pm.PackageManager;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;

public class UserDashboardActivity extends AppCompatActivity {

    private HealthDataRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_dashboard);
        repository = HealthDataRepository.getInstance(this);

        View rootView = findViewById(android.R.id.content);
        if (rootView == null) rootView = getWindow().getDecorView();
        
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views & Click Listeners
        
        // Profile, Settings & Notification
        findViewById(R.id.btn_settings).setOnClickListener(v -> {
            Toast.makeText(UserDashboardActivity.this, "Opening Settings...", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(UserDashboardActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
        findViewById(R.id.btn_notification).setOnClickListener(v -> {
            Toast.makeText(UserDashboardActivity.this, "Opening Notifications...", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(UserDashboardActivity.this, NotificationSettingsActivity.class);
            startActivity(intent);
        });

        // Assessment Icons (Unified Strategy)
        setupAssessmentClick(R.id.icon_kidney, "kidney");
        setupAssessmentClick(R.id.icon_heart, "heart");
        setupAssessmentClick(R.id.icon_lung, "lung");
        setupAssessmentClick(R.id.icon_cancer, "cancer");
        setupAssessmentClick(R.id.icon_liver, "liver");
        setupAssessmentClick(R.id.icon_brain, "brain");

        findViewById(R.id.btn_reports).setOnClickListener(v -> startActivity(new Intent(UserDashboardActivity.this, ReportsActivity.class)));
        findViewById(R.id.btn_tracker).setOnClickListener(v -> startActivity(new Intent(UserDashboardActivity.this, DailyTrackerActivity.class)));
        findViewById(R.id.btn_trends).setOnClickListener(v -> startActivity(new Intent(UserDashboardActivity.this, PersonalTrendsActivity.class)));

        // Welcome Text
        TextView welcomeText = findViewById(R.id.text_welcome);
        if (welcomeText != null) {
            android.content.SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
            String name = prefs.getString("USER_NAME", "User");
            welcomeText.setText("Welcome, " + name);
        }

        // Recent Tests Navigation
        findViewById(R.id.btn_view_all_tests).setOnClickListener(v -> startActivity(new Intent(this, ReportsActivity.class)));

        scheduleDailyGoalsNotification();
    }

    private void scheduleDailyGoalsNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        PeriodicWorkRequest workRequest = new PeriodicWorkRequest.Builder(
                GoalsNotificationWorker.class,
                24, TimeUnit.HOURS
        ).build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "DailyHealthGoalsNotification",
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
        );

        PeriodicWorkRequest urgentRequest = new PeriodicWorkRequest.Builder(
                UrgentNotificationWorker.class,
                2, TimeUnit.HOURS
        ).build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "UrgentHealthNotification",
                ExistingPeriodicWorkPolicy.KEEP,
                urgentRequest
        );

        PeriodicWorkRequest weeklyRequest = new PeriodicWorkRequest.Builder(
                WeeklyProgressWorker.class,
                24, TimeUnit.HOURS // Checked daily, but fires on Sunday
        ).build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "WeeklyHealthSummaryNotification",
                ExistingPeriodicWorkPolicy.KEEP,
                weeklyRequest
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateHealthScore();
        updateRecentTests();
        
        // Sync bi-directionally with Backend
        HealthScoreManager.syncAllLocalReports(this);
        HealthDataRepository.getInstance(this).syncAllData(new HealthDataRepository.OnSyncCompleteListener() {
            @Override
            public void onSyncComplete() {
                runOnUiThread(() -> {
                    updateHealthScore();
                    updateRecentTests();
                });
            }
        });
    }

    private void updateRecentTests() {
        LinearLayout container = findViewById(R.id.container_recent_tests);
        TextView noTestsText = findViewById(R.id.text_no_tests);
        TextView labelRecentTests = findViewById(R.id.label_recent_tests);
        TextView btnViewAllTests = findViewById(R.id.btn_view_all_tests);

        if (container == null) return;

        // Clear previous items except the "No tests" text
        for (int i = container.getChildCount() - 1; i >= 0; i--) {
            View child = container.getChildAt(i);
            if (child.getId() != R.id.text_no_tests) {
                container.removeViewAt(i);
            }
        }

        android.content.SharedPreferences sessionPrefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        int userId = sessionPrefs.getInt("USER_ID", -1);

        if (userId == -1) {
            if (labelRecentTests != null) labelRecentTests.setVisibility(View.GONE);
            if (btnViewAllTests != null) btnViewAllTests.setVisibility(View.GONE);
            container.setVisibility(View.GONE);
            return;
        }

        java.util.List<DatabaseHelper.Report> reports = repository.getReportsByUserId(userId);

        if (reports == null || reports.isEmpty()) {
            if (labelRecentTests != null) labelRecentTests.setVisibility(View.GONE);
            if (btnViewAllTests != null) btnViewAllTests.setVisibility(View.GONE);
            container.setVisibility(View.GONE);
        } else {
            if (labelRecentTests != null) labelRecentTests.setVisibility(View.VISIBLE);
            if (btnViewAllTests != null) btnViewAllTests.setVisibility(View.VISIBLE);
            container.setVisibility(View.VISIBLE);
            noTestsText.setVisibility(View.GONE);
            
            // Filter out DailyTracker and show only latest 3 assessment tests
            int addedCount = 0;
            for (DatabaseHelper.Report report : reports) {
                if (addedCount >= 3) break;
                if (!"DailyTracker".equals(report.getModule())) {
                    addRecentTestCard(container, report);
                    addedCount++;
                }
            }

            if (addedCount == 0) {
                if (labelRecentTests != null) labelRecentTests.setVisibility(View.GONE);
                if (btnViewAllTests != null) btnViewAllTests.setVisibility(View.GONE);
                container.setVisibility(View.GONE);
            }
        }
    }

    private void addRecentTestCard(LinearLayout container, DatabaseHelper.Report report) {
        View card = getLayoutInflater().inflate(R.layout.item_recent_test, container, false);

        ImageView iconView = card.findViewById(R.id.icon_test);
        TextView nameView = card.findViewById(R.id.text_test_name);
        TextView timeView = card.findViewById(R.id.text_test_time);
        TextView riskView = card.findViewById(R.id.text_test_risk);

        // Format time - for simplicity, we'll just show the date component if it's long
        // The DB stores CURRENT_TIMESTAMP which is 'YYYY-MM-DD HH:MM:SS'
        String timestamp = report.getTimestamp();
        if (timestamp != null && timestamp.length() > 10) {
            timeView.setText(timestamp.substring(0, 10)); // Just the date
        } else {
            timeView.setText("Recently");
        }
        
        String module = report.getModule();
        nameView.setText(module != null ? module + " Assessment" : "Assessment");

        // Set Icon and Color
        int iconRes = getModuleIcon(module);
        int color = getModuleColor(module);

        iconView.setImageResource(iconRes);
        
        // Create a dynamic circle background with transparency for the icon
        android.graphics.drawable.GradientDrawable circle = new android.graphics.drawable.GradientDrawable();
        circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        circle.setColor(color);
        circle.setAlpha(40); // 15% opacity (approx)
        iconView.setBackground(circle);
        iconView.setImageTintList(android.content.res.ColorStateList.valueOf(color));

        if (report != null) {
            String riskStr = report.getRisk() != null ? report.getRisk() : "Normal";
            riskView.setText(riskStr);

            // Risk Badge color
            int badgeBg, badgeText;
            if (riskStr.equalsIgnoreCase("Low") || riskStr.equalsIgnoreCase("Normal") || riskStr.equalsIgnoreCase("Good")) {
                badgeBg = getResources().getColor(R.color.badge_low_bg);
                badgeText = getResources().getColor(R.color.badge_low_text);
            } else if (riskStr.equalsIgnoreCase("Medium") || riskStr.equalsIgnoreCase("Moderate") || riskStr.equalsIgnoreCase("Fair")) {
                badgeBg = getResources().getColor(R.color.badge_med_bg);
                badgeText = getResources().getColor(R.color.badge_med_text);
            } else {
                badgeBg = getResources().getColor(R.color.badge_high_bg);
                badgeText = getResources().getColor(R.color.badge_high_text);
            }

            android.graphics.drawable.GradientDrawable badgeDrawable = new android.graphics.drawable.GradientDrawable();
            badgeDrawable.setColor(badgeBg);
            badgeDrawable.setCornerRadius(100);
            riskView.setBackground(badgeDrawable);
            riskView.setTextColor(badgeText);
        }

        card.setOnClickListener(v -> {
            Intent intent = new Intent(this, ReportDetailsActivity.class);
            intent.putExtra("MODULE_NAME", module);
            startActivity(intent);
        });

        container.addView(card);
    }

    private int getModuleIcon(String module) {
        if (module == null) return R.drawable.ic_safepulse_logo;
        String m = module.toLowerCase();
        if (m.contains("kidney")) return R.drawable.ic_kidney;
        if (m.contains("heart")) return R.drawable.ic_heart_logo;
        if (m.contains("lung")) return R.drawable.ic_bg_wind;
        if (m.contains("liver")) return R.drawable.ic_liver;
        if (m.contains("cancer")) return R.drawable.ic_pill;
        if (m.contains("brain") || m.contains("alzheimer")) return R.drawable.ic_bg_brain;
        return R.drawable.ic_safepulse_logo;
    }

    private int getModuleColor(String module) {
        if (module == null) return getResources().getColor(R.color.brand_dark);
        String m = module.toLowerCase();
        if (m.contains("kidney")) return getResources().getColor(R.color.assess_kidney);
        if (m.contains("heart")) return getResources().getColor(R.color.assess_heart);
        if (m.contains("lung")) return getResources().getColor(R.color.assess_lung);
        if (m.contains("liver")) return getResources().getColor(R.color.assess_liver);
        if (m.contains("cancer")) return getResources().getColor(R.color.assess_cancer);
        if (m.contains("brain") || m.contains("alzheimer")) return getResources().getColor(R.color.assess_brain);
        return getResources().getColor(R.color.brand_dark);
    }

    private void updateHealthScore() {
        TextView scoreView = findViewById(R.id.score_value);
        TextView scoreLabel = findViewById(R.id.score_label);
        View cardScore = findViewById(R.id.card_score);
        View percentSymbol = findViewById(R.id.score_percent);
        View trendValue = findViewById(R.id.score_trend_value);
        TextView scoreDesc = findViewById(R.id.score_desc);

        android.content.SharedPreferences sessionPrefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        int userId = sessionPrefs.getInt("USER_ID", -1);
        int overallScore = repository.calculateOverallScore(userId);

        if (overallScore == -1) {
            scoreLabel.setText("No Assessments Completed");
            scoreView.setText("--");
            if (percentSymbol != null) percentSymbol.setVisibility(View.GONE);
            if (trendValue != null) trendValue.setVisibility(View.GONE);
            if (scoreDesc != null) {
                scoreDesc.setText("Complete assessments to view your scores");
            }
            
            // Set dark background for empty state
            android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
            drawable.setColor(android.graphics.Color.parseColor("#0F172A")); // dashboard_bg_dark
            drawable.setCornerRadius(getResources().getDisplayMetrics().density * 32);
            cardScore.setBackground(drawable);
        } else {
            scoreLabel.setText("YOUR HEALTH SCORE");
            scoreView.setText(String.valueOf(overallScore));
            if (percentSymbol != null) percentSymbol.setVisibility(View.VISIBLE);
            if (trendValue != null) trendValue.setVisibility(View.VISIBLE);
            if (scoreDesc != null) {
                scoreDesc.setText(" vs last month");
            }

            // Set constant Dark Blue background
            android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
            drawable.setColor(android.graphics.Color.parseColor("#0F172A")); // Dark Blue
            drawable.setCornerRadius(getResources().getDisplayMetrics().density * 32);
            cardScore.setBackground(drawable);
        }
    }

    private void setupAssessmentClick(int viewId, String moduleType) {
        View view = findViewById(viewId);
        if (view != null) {
            view.setOnClickListener(v -> {
                Intent intent = new Intent(UserDashboardActivity.this, AssessmentIntroActivity.class);
                intent.putExtra("MODULE_TYPE", moduleType);
                startActivity(intent);
            });
        }
    }
}
