package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.util.Log;

public class CreateAccountActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_account);
        dbHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI components
        Button createAccountButton = findViewById(R.id.btn_create_account);
        Button backButton = findViewById(R.id.btn_back);
        TextView signInText = findViewById(R.id.text_sign_in);
        
        EditText nameInput = findViewById(R.id.input_name);
        EditText emailInput = findViewById(R.id.input_email);
        EditText phoneInput = findViewById(R.id.input_phone);
        EditText passwordInput = findViewById(R.id.input_password);
        EditText confirmPasswordInput = findViewById(R.id.input_confirm_password);

        // Create Account Action
        createAccountButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();
            String confirmPassword = confirmPasswordInput.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                // Save to local database for internal reporting / user management
                String phone = phoneInput != null ? phoneInput.getText().toString().trim() : "";
                dbHelper.addUser(name, email, phone, password);

                registerWithApi(name, email, password);
            }
        });

        // Back Action (Returns to previous screen, likely Login)
        backButton.setOnClickListener(v -> {
            finish();
        });

        // Sign In Action (Go to Login)
        signInText.setOnClickListener(v -> {
            Intent intent = new Intent(CreateAccountActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Navigate back to existing LoginActivity
            startActivity(intent);
        });
    }

    private void registerWithApi(String name, String email, String password) {
        java.util.Map<String, Object> request = new java.util.HashMap<>();
        request.put("username", email);
        request.put("email", email);
        request.put("password", password);
        request.put("full_name", name);

        RetrofitClient.getApiService().register(request).enqueue(new Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(Call<java.util.Map<String, Object>> call, Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(CreateAccountActivity.this, "Clinical Identity Created!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(CreateAccountActivity.this, LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    String msg = "Creation Failed";
                    try { if (response.errorBody() != null) msg = response.errorBody().string(); } catch (Exception e) {}
                    Toast.makeText(CreateAccountActivity.this, msg, Toast.LENGTH_SHORT).show();
                    Log.e("API_ERROR", "Registration failed: " + msg);
                }
            }

            @Override
            public void onFailure(Call<java.util.Map<String, Object>> call, Throwable t) {
                Log.e("API_ERROR", "Registration error", t);
                Toast.makeText(CreateAccountActivity.this, "Network Error: Server Unreachable", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
