package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.content.SharedPreferences;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.util.Log;

public class AdminLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_login);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText passwordInput = findViewById(R.id.admin_input_password);
        Button signInBtn = findViewById(R.id.btn_admin_sign_in);
        Button backBtn = findViewById(R.id.btn_admin_back);

        signInBtn.setOnClickListener(v -> {
            String token = passwordInput.getText().toString().trim();

            if (token.isEmpty()) {
                Toast.makeText(this, "Please enter Admin Access Token", Toast.LENGTH_SHORT).show();
            } else {
                // Perform real login against backend to get the Auth Token (synchronized with website)
                loginWithApi("admin@safepulse.com", token);
            }
        });

        backBtn.setOnClickListener(v -> finish());
    }

    private void loginWithApi(String email, String password) {
        LoginRequest request = new LoginRequest(email, password);
        RetrofitClient.getApiService(this).login(request).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body();
                    
                    // Verify if the user is actually an ADMIN (Case-insensitive check)
                    String role = loginResponse.getRole();
                    if (role != null && role.equalsIgnoreCase("admin")) {
                        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
                        prefs.edit()
                             .putString("AUTH_TOKEN", loginResponse.getToken())
                             .putString("USER_ROLE", loginResponse.getRole())
                             .putString("USER_EMAIL", email)
                             .apply();

                        Toast.makeText(AdminLoginActivity.this, "Admin Login successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AdminLoginActivity.this, AdminDashboardActivity.class));
                        finish();
                    } else {
                        Toast.makeText(AdminLoginActivity.this, "Access Denied: Not an Admin account", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AdminLoginActivity.this, "Login failed: Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e("API_ERROR", "Admin login failed", t);
                Toast.makeText(AdminLoginActivity.this, "Network Error: Check Tunnel", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
