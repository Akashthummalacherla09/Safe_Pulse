package com.simats.safe_pulse;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LiverResultActivity extends AppCompatActivity {

    private int riskScore = 0;
    private String riskLevel = "Low Risk"; // Default
    
    // Inputs
    private int alt, ast, alp; // U/L
    private double bilirubin, albumin; // mg/dL, g/dL

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_liver_result);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. Get Data
        Intent intent = getIntent();
        alt = intent.getIntExtra("ALT", 0);
        ast = intent.getIntExtra("AST", 0);
        alp = intent.getIntExtra("ALP", 0);
        bilirubin = intent.getDoubleExtra("BILIRUBIN", 0.0);
        albumin = intent.getDoubleExtra("ALBUMIN", 0.0);

        // 2. Calculate (Unified Engine)
        java.util.Map<String, Object> result = AssessmentEngine.calculateLiver(alt, ast, bilirubin, albumin, alp);
        
        String riskLevel = (String) result.get("riskLevel");
        String statusTitle = (String) result.get("status");
        int score = (int) result.get("score");

        // 3. Update UI
        TextView textStatus = findViewById(R.id.text_status_title);
        TextView textBadge = findViewById(R.id.text_risk_badge);
        TextView textExplanation = findViewById(R.id.text_explanation_main);
        TextView textWhatMeans = findViewById(R.id.text_what_means_bullet);
        TextView textAlt = findViewById(R.id.text_alt_val);
        TextView textAst = findViewById(R.id.text_ast_val);

        textAlt.setText(String.valueOf(alt));
        textAst.setText(String.valueOf(ast));

        String explanation = "";
        String badgeText = riskLevel;
        String whatMeansText = "";
        int colorRes = 0;

        if (statusTitle.equals("Normal")) {
            explanation = "Your liver function tests are within normal limits. \n\nIndication: Routine checkups with a general physician are sufficient.";
            colorRes = Color.parseColor("#00C853");
            whatMeansText = "• Healthy liver function • No significant inflammation detected • Maintain current lifestyle";
        } else if (statusTitle.equals("Mild")) {
            explanation = "Mild elevation detected. \n\nIndication: Routine checkups with a general physician are sufficient.";
            colorRes = Color.parseColor("#FFAB00");
            whatMeansText = "• Slight inflammation or fatty deposits • Reversible with lifestyle changes • Follow up in 3-6 months";
        } else if (statusTitle.equals("Moderate")) {
            explanation = "Significant liver dysfunction detected. \n\nIndication: You may want to consult a Hepatologist for a checkup.";
            colorRes = Color.parseColor("#FF5722");
            whatMeansText = "• Risk of fibrosis or chronic condition • Requires diagnosis (ultrasound/blood work) • Lifestyle intervention critical";
        } else {
            explanation = "Severe liver enzyme abnormalities detected. \n\nURGENT: Please visit a Hepatologist immediately.";
            colorRes = Color.parseColor("#D50000");
            whatMeansText = "• Possible liver damage, hepatitis, or liver disease • May experience fatigue or jaundice • Risk of progressive liver failure";
        }

        // Save Score (Standardized JSON)
        try {
            org.json.JSONObject details = new org.json.JSONObject();
            details.put("alt", alt);
            details.put("ast", ast);
            details.put("alp", alp);
            details.put("bilirubin", bilirubin);
            details.put("albumin", albumin);
            details.put("status", statusTitle);
            
            HealthScoreManager.saveModuleScore(this, "liver", score, statusTitle.toLowerCase(), details.toString());
        } catch (org.json.JSONException e) {
            e.printStackTrace();
        }

        textStatus.setText(statusTitle);
        textStatus.setTextColor(colorRes);
        textBadge.setText(badgeText);
        textBadge.setTextColor(colorRes);
        textExplanation.setText(explanation);
        textWhatMeans.setText(whatMeansText);
        generatePrevention(statusTitle);

        // 4. Navigation
        findViewById(R.id.btn_back_header).setOnClickListener(v -> {
            Intent intentNav = new Intent(this, UserDashboardActivity.class);
            intentNav.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intentNav);
            finish();
        });

        findViewById(R.id.btn_back_dashboard).setOnClickListener(v -> {
            Intent intentNav = new Intent(this, UserDashboardActivity.class);
            intentNav.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intentNav);
            finish();
        });
    }

    private void generatePrevention(String status) {
        android.widget.LinearLayout container = findViewById(R.id.list_prevention_tips);
        container.removeAllViews();

        class Tip {
            String t, d; boolean p;
            Tip(String t, String d, boolean p) { this.t = t; this.d = d; this.p = p; }
        }

        java.util.List<Tip> tips = new java.util.ArrayList<>();
        if (status.equals("Normal")) {
            tips.add(new Tip("Maintain Alcohol Moderation", "Avoid excessive alcohol consumption", true));
            tips.add(new Tip("Balanced Diet", "Eat low-fat, high-fiber foods", true));
            tips.add(new Tip("Hydration", "Drink plenty of water daily", true));
        } else if (status.equals("Mild")) {
            tips.add(new Tip("Fatty Liver Control", "Reduce sugar and processed carb intake", true));
            tips.add(new Tip("Weight Management", "Even 5% weight loss improves liver enzymes", true));
            tips.add(new Tip("Avoid NSAIDs", "Limit use of paracetamol/ibuprofen", false));
        } else {
            tips.add(new Tip("Hepatology Consult", "See a specialist for detailed screening", true));
            tips.add(new Tip("Complete Alcohol Cessation", "Stop alcohol consumption entirely", false));
            tips.add(new Tip("Low Protein Diet", "Restrict protein if advised by doctor", false));
        }

        for (Tip tip : tips) {
            android.view.View view = getLayoutInflater().inflate(R.layout.item_prevention_tip, container, false);
            TextView textT = view.findViewById(R.id.tip_title);
            TextView textD = view.findViewById(R.id.tip_desc);
            view.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor(tip.p ? "#E8F5E9" : "#FFEBEE")));
            textT.setText(tip.t);
            textD.setText(tip.d);
            container.addView(view);
        }
    }
}
