package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LungInputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lung_input);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView backButton = findViewById(R.id.btn_back);
        Button calculateButton = findViewById(R.id.btn_calculate);
        
        EditText inputFev1 = findViewById(R.id.input_fev1);
        EditText inputFvc = findViewById(R.id.input_fvc);
        EditText inputRatio = findViewById(R.id.input_ratio);
        EditText inputSpo2 = findViewById(R.id.input_spo2);
        Spinner spinnerSmoking = findViewById(R.id.spinner_smoking);

        // Setup Smoking Spinner
        String[] smokingOptions = {"No", "Yes"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, smokingOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSmoking.setAdapter(adapter);

        // Back Logic
        backButton.setOnClickListener(v -> finish());

        // Calculate Logic
        calculateButton.setOnClickListener(v -> {
            String fev1Str = inputFev1.getText().toString().trim();
            String fvcStr = inputFvc.getText().toString().trim();
            String ratioStr = inputRatio.getText().toString().trim();
            String spo2Str = inputSpo2.getText().toString().trim();
            String smoking = spinnerSmoking.getSelectedItem().toString();

            // Clear previous errors
            inputFev1.setError(null);
            inputFvc.setError(null);
            inputRatio.setError(null);
            inputSpo2.setError(null);

            if (fev1Str.isEmpty()) {
                inputFev1.setError("Required");
                return;
            }
            if (fvcStr.isEmpty()) {
                inputFvc.setError("Required");
                return;
            }
            if (ratioStr.isEmpty()) {
                inputRatio.setError("Required");
                return;
            }
            if (spo2Str.isEmpty()) {
                inputSpo2.setError("Required");
                return;
            }

            try {
                double fev1 = Double.parseDouble(fev1Str);
                double fvc = Double.parseDouble(fvcStr);
                double ratio = Double.parseDouble(ratioStr);
                double spo2 = Double.parseDouble(spo2Str);

                // Validation Rules
                // FEV1 / FVC between 0–150 (Assuming this applies to both singular values or ratio? 
                // Prompt: "FEV1 / FVC between 0–150". Usually means FEV1% and FVC% are 0-150.
                if (fev1 < 0 || fev1 > 150) {
                    inputFev1.setError("Must be 0-150");
                    return;
                }
                if (fvc < 0 || fvc > 150) {
                    inputFvc.setError("Must be 0-150");
                    return;
                }
                
                // Ratio must be between 0 and 1
                if (ratio < 0 || ratio > 1) {
                    inputRatio.setError("Must be 0-1");
                    return;
                }

                // SpO2 between 70–100
                if (spo2 < 70 || spo2 > 100) {
                    inputSpo2.setError("Must be 70-100");
                    return;
                }

                Intent intent = new Intent(LungInputActivity.this, LungResultActivity.class);
                intent.putExtra("FEV1", fev1);
                intent.putExtra("FVC", fvc);
                intent.putExtra("RATIO", ratio);
                intent.putExtra("SPO2", spo2);
                intent.putExtra("IS_SMOKER", smoking.equalsIgnoreCase("Yes"));
                startActivity(intent);

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
