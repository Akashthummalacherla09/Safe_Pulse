package com.simats.safe_pulse;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CancerResultActivity extends AppCompatActivity {

    private String tCategory;
    private boolean hasLymphNode;
    private boolean hasMetastasis;
    private String biopsyGrade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cancer_result);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get Data
        Intent intent = getIntent();
        tCategory = intent.getStringExtra("T_CATEGORY");
        hasLymphNode = intent.getBooleanExtra("LYMPH", false);
        hasMetastasis = intent.getBooleanExtra("METASTASIS", false);
        biopsyGrade = intent.getStringExtra("GRADE");

        calculateAndDisplayResults();

        // Navigation
        findViewById(R.id.btn_back_header).setOnClickListener(v -> {
            Intent intentNav = new Intent(this, UserDashboardActivity.class);
            intentNav.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intentNav);
        });
        findViewById(R.id.btn_back_dashboard).setOnClickListener(v -> {
            Intent intentNav = new Intent(this, UserDashboardActivity.class);
            intentNav.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intentNav);
        });
        
        findViewById(R.id.btn_view_prevention).setOnClickListener(v -> {
            Intent preventionIntent = new Intent(CancerResultActivity.this, CancerPreventionActivity.class);
            preventionIntent.putExtra("STAGE", calculatedStage);
            startActivity(preventionIntent);
        });
    }

    private String calculatedStage = "Stage I";
    private String calculatedRisk = "Low";

    private void calculateAndDisplayResults() {
        // 🧬 Centralized Scoring Engine (Calculated 1:1 with Web)
        java.util.Map<String, Object> result = AssessmentEngine.calculateCancer(tCategory, hasLymphNode, hasMetastasis, biopsyGrade);
        
        calculatedStage = (String) result.get("stage");
        calculatedRisk = (String) result.get("riskLevel");
        int score = (int) result.get("score");

        // 🟢 Standardized Data Struct (Ready for submit_report.php)
        try {
            org.json.JSONObject details = new org.json.JSONObject();
            details.put("tumor_size", tCategory);
            details.put("lymph_node", hasLymphNode);
            details.put("metastasis", hasMetastasis);
            details.put("biopsy_grade", biopsyGrade);
            
            HealthScoreManager.saveModuleScore(this, "cancer", score, calculatedStage.toLowerCase(), details.toString());
        } catch (org.json.JSONException e) {
            HealthScoreManager.saveModuleScore(this, "cancer", score, calculatedStage.toLowerCase());
        }

        // --- 3. Update UI ---
        TextView textRiskBadge = findViewById(R.id.text_risk_badge);
        TextView textStage = findViewById(R.id.text_stage_main);
        TextView textExplanation = findViewById(R.id.text_explanation);
        CardView cardResult = findViewById(R.id.card_result_status);

        textRiskBadge.setText(calculatedRisk);
        textStage.setText("Cancer Stage: " + calculatedStage);

        // Update Card Color based on Risk
        switch (calculatedRisk) {
            case "Low":
                cardResult.setCardBackgroundColor(Color.parseColor("#00C853"));
                break;
            case "Moderate":
                cardResult.setCardBackgroundColor(Color.parseColor("#FFAB00"));
                break;
            case "High":
                cardResult.setCardBackgroundColor(Color.parseColor("#FF5722"));
                break;
            default:
                cardResult.setCardBackgroundColor(Color.parseColor("#D50000"));
                break;
        }

        // Update Explanation Text based on STAGE
        if (calculatedStage.equals("Stage I")) {
            textExplanation.setText("Cancer detected at early stage. Localized and highly treatable. \n\nIndication: You may want to consult an Oncologist for a checkup.");
        } else if (calculatedStage.equals("Stage II")) {
            textExplanation.setText("Cancer has grown but remains localized. \n\nIndication: You may want to consult an Oncologist for a checkup.");
        } else if (calculatedStage.equals("Stage III")) {
            textExplanation.setText("Cancer has spread to nearby lymph nodes. \n\nURGENT: Please visit an Oncologist immediately.");
        } else {
            textExplanation.setText("Cancer has metastasized to distant organs. \n\nURGENT: Please visit an Oncologist immediately.");
        }
    }
}
