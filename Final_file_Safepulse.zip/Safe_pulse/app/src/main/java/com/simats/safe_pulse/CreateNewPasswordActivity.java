package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateNewPasswordActivity extends AppCompatActivity {

    private EditText newPasswordInput, confirmPasswordInput;
    private Button btnResetPassword;
    private LinearLayout btnBack;
    private String email, otp;
    private HealthDataRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_password);

        email = getIntent().getStringExtra("EMAIL");
        otp = getIntent().getStringExtra("OTP");
        repository = HealthDataRepository.getInstance(this);

        initViews();
        setupListeners();
    }

    private void initViews() {
        newPasswordInput = findViewById(R.id.input_new_password);
        confirmPasswordInput = findViewById(R.id.input_confirm_password);
        btnResetPassword = findViewById(R.id.btn_reset_password);
        btnBack = findViewById(R.id.btn_back);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnResetPassword.setOnClickListener(v -> {
            String newPass = newPasswordInput.getText().toString().trim();
            String confirmPass = confirmPasswordInput.getText().toString().trim();

            if (newPass.length() < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            } else if (!newPass.equals(confirmPass)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                updatePasswordOnBackend(newPass);
            }
        });
    }

    private void updatePasswordOnBackend(String newPassword) {
        PasswordResetRequest request = new PasswordResetRequest(email, otp, newPassword);
        RetrofitClient.getApiService().resetPassword(request).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(CreateNewPasswordActivity.this, "Password reset successfully!", Toast.LENGTH_LONG).show();
                    // Go back to login
                    Intent intent = new Intent(CreateNewPasswordActivity.this, LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    // FALLBACK: Local update for development or network issues
                    boolean success = repository.updatePassword(email, newPassword);
                    if (success) {
                        Toast.makeText(CreateNewPasswordActivity.this, "Password reset locally successfully!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(CreateNewPasswordActivity.this, LoginActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(CreateNewPasswordActivity.this, "Error: Invalid or Expired Session", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // FALLBACK: Local update for development or network issues
                boolean success = repository.updatePassword(email, newPassword);
                if (success) {
                    Toast.makeText(CreateNewPasswordActivity.this, "Identity Optimized & Synchronized Locally.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(CreateNewPasswordActivity.this, LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(CreateNewPasswordActivity.this, "Network Error. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
