package com.simats.safe_pulse;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Map;

public class AnalyticsDashboardActivity extends AppCompatActivity {

    private HealthDataRepository repository;
    private GridLayout distributionContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_analytics_dashboard);
        repository = HealthDataRepository.getInstance(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        distributionContainer = findViewById(R.id.distribution_container);
        findViewById(R.id.btn_back_to_dashboard_analytics).setOnClickListener(v -> finish());

        loadAnalytics();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAnalytics();
    }

    private void loadAnalytics() {
        RetrofitClient.getApiService(this).getSyncData().enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    java.util.Map<String, Object> data = response.body();
                    
                    Double totalUsers = (Double) data.get("total_users");
                    Double totalReports = (Double) data.get("total_assessments");
                    
                    if (totalUsers != null) ((TextView) findViewById(R.id.analytics_total_users)).setText(String.format("%,d", totalUsers.intValue()));
                    if (totalReports != null) ((TextView) findViewById(R.id.analytics_total_reports)).setText(String.format("%,d", totalReports.intValue()));

                    // Handle Risk Distribution
                    Map<String, Object> riskMap = (Map<String, Object>) data.get("risk_distribution");
                    if (riskMap != null) {
                        int low = ((Double) riskMap.getOrDefault("low", 0.0)).intValue();
                        int med = ((Double) riskMap.getOrDefault("med", 0.0)).intValue();
                        int high = ((Double) riskMap.getOrDefault("high", 0.0)).intValue();

                        int total = (totalReports != null && totalReports > 0) ? totalReports.intValue() : 1;
                        float lowP = (low * 100f / total);
                        float medP = (med * 100f / total);
                        float highP = (high * 100f / total);

                        ((TextView) findViewById(R.id.risk_low_count)).setText(String.valueOf(low));
                        ((TextView) findViewById(R.id.risk_low_percent)).setText(Math.round(lowP) + "%");
                        ((TextView) findViewById(R.id.risk_med_count)).setText(String.valueOf(med));
                        ((TextView) findViewById(R.id.risk_med_percent)).setText(Math.round(medP) + "%");
                        ((TextView) findViewById(R.id.risk_high_count)).setText(String.valueOf(high));
                        ((TextView) findViewById(R.id.risk_high_percent)).setText(Math.round(highP) + "%");

                        DonutChartView donut = findViewById(R.id.donut_risk);
                        donut.setData(lowP, medP, highP);
                        ((TextView) findViewById(R.id.text_risk_total)).setText("100%");
                    }

                    // Handle Module Analytics
                    Map<String, Object> moduleMap = (Map<String, Object>) data.get("module_analytics");
                    if (moduleMap != null) {
                        distributionContainer.removeAllViews();
                        String[] modules = {"Heart", "Kidney", "Lung", "Cancer", "Liver", "Alzheimer", "Vitals"};
                        int total = (totalReports != null && totalReports > 0) ? totalReports.intValue() : 1;
                        for (String m : modules) {
                            int count = ((Double) moduleMap.getOrDefault(m, 0.0)).intValue();
                            addDistributionItem(m, count, total);
                        }
                    }
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                // Keep existing UI or show error
            }
        });
    }

    private void addDistributionItem(String name, int count, int total) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_analytics_disease_card, distributionContainer, false);
        
        ImageView icon = view.findViewById(R.id.card_icon);
        TextView nameTxt = view.findViewById(R.id.card_name);
        TextView countTxt = view.findViewById(R.id.card_count);
        TextView percentTxt = view.findViewById(R.id.card_percent);
        ProgressBar progress = view.findViewById(R.id.card_progress);

        nameTxt.setText(name);
        countTxt.setText(String.format("%,d", count));
        int percentage = (count * 100 / total);
        percentTxt.setText(percentage + "%");
        progress.setProgress(percentage);

        // Styling
        int color = Color.parseColor("#0EA5E9");
        int iconRes = R.drawable.ic_heart_logo;

        if (name.equals("Kidney")) {
            color = Color.parseColor("#EC4899");
            iconRes = R.drawable.ic_lightning;
        } else if (name.equals("Lung")) {
            color = Color.parseColor("#10B981");
            iconRes = R.drawable.ic_wind_logo;
        } else if (name.equals("Cancer")) {
            color = Color.parseColor("#D946EF");
            iconRes = R.drawable.ic_pill;
        } else if (name.equals("Liver")) {
            color = Color.parseColor("#F59E0B");
            iconRes = R.drawable.ic_lightning;
        } else if (name.equals("Alzheimer")) {
            color = Color.parseColor("#6366F1");
            iconRes = R.drawable.ic_bulb;
        }

        icon.setImageResource(iconRes);
        icon.setColorFilter(color);
        icon.setBackgroundTintList(ColorStateList.valueOf(color).withAlpha(30));
        progress.setProgressTintList(ColorStateList.valueOf(color));

        distributionContainer.addView(view);
    }
}
