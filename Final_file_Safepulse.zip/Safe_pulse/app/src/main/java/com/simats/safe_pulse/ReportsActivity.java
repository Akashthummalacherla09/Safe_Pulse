package com.simats.safe_pulse;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Map;

public class ReportsActivity extends AppCompatActivity {

    private HealthDataRepository repository;
    private LinearLayout listContainer;
    private TextView noDataText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reports);
        repository = HealthDataRepository.getInstance(this);

        View rootView = findViewById(android.R.id.content);
        if (rootView == null) rootView = getWindow().getDecorView();
        
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        listContainer = findViewById(R.id.list_container);
        noDataText = findViewById(R.id.text_no_data);

        androidx.swiperefreshlayout.widget.SwipeRefreshLayout swipeRefresh = findViewById(R.id.swipe_refresh);
        swipeRefresh.setOnRefreshListener(() -> {
            repository.syncAllData(() -> {
                runOnUiThread(() -> {
                    loadReports();
                    swipeRefresh.setRefreshing(false);
                });
            });
        });

        findViewById(R.id.btn_back_dashboard).setOnClickListener(v -> finish());

        loadReports();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadReports();
    }

    private void loadReports() {
        listContainer.removeAllViews();
        android.content.SharedPreferences sessionPrefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        int userId = sessionPrefs.getInt("USER_ID", -1);
        
        if (userId == -1) {
            noDataText.setVisibility(View.VISIBLE);
            noDataText.setText("Please log in to view reports.");
            return;
        }

        java.util.List<DatabaseHelper.Report> localReports = repository.getReportsByUserId(userId);
        
        if (localReports == null || localReports.isEmpty()) {
            noDataText.setVisibility(View.VISIBLE);
            noDataText.setText("No assessments completed yet.");
            
            // Auto-trigger sync if empty to help the user
            repository.syncAllData(() -> {
                runOnUiThread(() -> {
                    // Try loading again after sync
                    java.util.List<DatabaseHelper.Report> refreshed = repository.getReportsByUserId(userId);
                    if (refreshed != null && !refreshed.isEmpty()) {
                        noDataText.setVisibility(View.GONE);
                        listContainer.removeAllViews();
                        for (DatabaseHelper.Report r : refreshed) {
                             if (r.getModule() != null && !r.getModule().toLowerCase().contains("tracker")) {
                                 addReportItem(r.getModule(), r);
                             }
                        }
                    }
                });
            });
        } else {
            noDataText.setVisibility(View.GONE);
            for (DatabaseHelper.Report r : localReports) {
                // Filter out daily tracker entries from the main report list if any
                if (r.getModule() != null && !r.getModule().toLowerCase().contains("tracker")) {
                    addReportItem(r.getModule(), r);
                }
            }
        }
    }

    private void addReportItem(String module, DatabaseHelper.Report report) {
        View itemView = LayoutInflater.from(this).inflate(R.layout.item_report, listContainer, false);

        ImageView icon = itemView.findViewById(R.id.report_icon);
        TextView name = itemView.findViewById(R.id.report_module_name);
        TextView date = itemView.findViewById(R.id.report_date);
        TextView risk = itemView.findViewById(R.id.report_risk_level);
        View btnViewDetails = itemView.findViewById(R.id.btn_view_details);
        View btnDownload = itemView.findViewById(R.id.btn_download);

        String displayModule = "";
        if (module != null && !module.isEmpty()) {
            displayModule = module.substring(0, 1).toUpperCase() + module.substring(1);
        }
        name.setText(displayModule + " Assessment");
        
        String timestamp = report.getTimestamp();
        if (timestamp != null && timestamp.length() > 10) {
            date.setText(timestamp.substring(0, 10));
        } else {
            date.setText("Recently");
        }
        
        String riskLevel = report.getRisk() != null ? report.getRisk() : "Normal";
        risk.setText(riskLevel);

        // Set specific icons and colors per module matching the dashboard/assessments
        switch (module.toLowerCase()) {
            case "kidney":
                icon.setImageResource(R.drawable.ic_bg_pulse);
                icon.setBackgroundResource(R.drawable.bg_circle_kidney);
                break;
            case "heart":
                icon.setImageResource(R.drawable.ic_heart_logo);
                icon.setBackgroundResource(R.drawable.bg_circle_heart);
                break;
            case "lung":
                icon.setImageResource(R.drawable.ic_bg_wind);
                icon.setBackgroundResource(R.drawable.bg_circle_lung);
                break;
            case "liver":
                icon.setImageResource(R.drawable.ic_lightning);
                icon.setBackgroundResource(R.drawable.bg_circle_liver);
                break;
            case "cancer":
                icon.setImageResource(R.drawable.ic_pill);
                icon.setBackgroundResource(R.drawable.bg_circle_cancer);
                break;
            case "brain":
            case "alzheimer":
                icon.setImageResource(R.drawable.ic_bg_brain);
                icon.setBackgroundResource(R.drawable.bg_circle_brain);
                break;
        }

        // Apply risk color logic for the badge
        if (riskLevel.contains("Low") || riskLevel.contains("Normal") || riskLevel.contains("Stage I")) {
            risk.setTextColor(Color.parseColor("#2E7D32"));
            risk.setBackgroundResource(R.drawable.bg_circle_icon_low);
        } else if (riskLevel.contains("Medium") || riskLevel.contains("Moderate") || riskLevel.contains("Stage II")) {
            risk.setTextColor(Color.parseColor("#B45309")); // Dark amber
            risk.setBackgroundResource(R.drawable.bg_circle_icon_med);
        } else {
            risk.setTextColor(Color.parseColor("#D32F2F"));
            risk.setBackgroundResource(R.drawable.bg_circle_icon_high);
        }

        btnViewDetails.setOnClickListener(v -> {
            Intent intent = new Intent(this, ReportDetailsActivity.class);
            intent.putExtra("MODULE_NAME", module);
            intent.putExtra("REPORT_ID", report.getId());
            startActivity(intent);
        });
        btnDownload.setOnClickListener(v -> PDFGenerator.downloadReport(this, module));

        listContainer.addView(itemView);
    }
}
