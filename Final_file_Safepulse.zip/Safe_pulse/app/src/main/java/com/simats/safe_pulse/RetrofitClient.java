package com.simats.safe_pulse;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    private static final String BASE_URL = "https://sized-carita-flowerless.ngrok-free.dev/api/";
    private static Retrofit retrofitWithAuth = null;
    private static Retrofit retrofitNoAuth = null;

    public static ApiService getApiService() {
        if (retrofitNoAuth == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(loggingInterceptor)
                    .addInterceptor(chain -> chain.proceed(chain.request().newBuilder()
                            .addHeader("ngrok-skip-browser-warning", "true")
                            .build()))
                    .build();

            retrofitNoAuth = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(client)
                    .build();
        }
        return retrofitNoAuth.create(ApiService.class);
    }

    public static ApiService getApiService(final android.content.Context context) {
        if (context == null) return getApiService();
        
        if (retrofitWithAuth == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

            final android.content.Context appContext = context.getApplicationContext();

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(loggingInterceptor)
                    .addInterceptor(new okhttp3.Interceptor() {
                        @Override
                        public okhttp3.Response intercept(Chain chain) throws java.io.IOException {
                            android.content.SharedPreferences prefs = appContext.getSharedPreferences("UserSession", android.content.Context.MODE_PRIVATE);
                            String token = prefs.getString("AUTH_TOKEN", null);
                            
                                okhttp3.Request.Builder builder = chain.request().newBuilder()
                                        .addHeader("ngrok-skip-browser-warning", "true");
                                
                                if (token != null) {
                                    builder.addHeader("Authorization", "Token " + token);
                                }
                                
                                okhttp3.Response response = chain.proceed(builder.build());
                                if (response.code() == 401) {
                                    prefs.edit().remove("AUTH_TOKEN").apply();
                                }
                                return response;
                        }
                    })
                    .build();

            retrofitWithAuth = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(client)
                    .build();
        }
        return retrofitWithAuth.create(ApiService.class);
    }
}
