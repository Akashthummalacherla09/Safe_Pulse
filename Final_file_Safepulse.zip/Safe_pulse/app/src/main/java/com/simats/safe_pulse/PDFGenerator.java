package com.simats.safe_pulse;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;

public class PDFGenerator {

    public static void downloadReport(Context context, String moduleName) {
        Map<String, String> status = HealthScoreManager.getModuleStatus(context, moduleName);
        String detailsJson = HealthScoreManager.getModuleDetails(context, moduleName);

        if (status.isEmpty()) {
            Toast.makeText(context, "No data available for " + moduleName, Toast.LENGTH_SHORT).show();
            return;
        }

        String riskLevel = status.get("risk");
        String timestamp = status.get("timestamp");

        exportUserReport(context, "Patient", moduleName, riskLevel, timestamp, detailsJson);
    }

    public static void exportUserReport(Context context, String userName, String moduleName, String riskLevel, String timestamp, String detailsJson) {
        generatePDF(context, userName, moduleName, riskLevel, timestamp, detailsJson);
    }

    private static void generatePDF(Context context, String userName, String moduleName, String riskLevel, String timestamp, String detailsJson) {
        PdfDocument pdfDocument = new PdfDocument();
        Paint paint = new Paint();
        Paint titlePaint = new Paint();

        // Page size: A4 (595 x 842 points)
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);
        Canvas canvas = page.getCanvas();

        int y = 60;

        // Draw Header
        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        titlePaint.setTextSize(26);
        titlePaint.setColor(Color.parseColor("#1E293B")); // Dark blue-gray
        canvas.drawText("SafePulse Medical Report", 50, y, titlePaint);
        y += 40;

        paint.setTextSize(14);
        paint.setColor(Color.BLACK);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("Patient Name: ", 50, y, paint);
        paint.setTypeface(Typeface.DEFAULT);
        canvas.drawText(userName, 160, y, paint);
        y += 25;

        paint.setTextSize(12);
        paint.setColor(Color.GRAY);
        canvas.drawText("Generated on: " + timestamp, 50, y, paint);
        y += 25;

        // Header Line
        paint.setColor(Color.LTGRAY);
        canvas.drawLine(50, y, 545, y, paint);
        y += 50;

        // Assessment Summary Section
        titlePaint.setTextSize(20);
        titlePaint.setColor(Color.BLACK);
        canvas.drawText(moduleName + " Assessment Summary", 50, y, titlePaint);
        y += 40;

        paint.setTextSize(16);
        paint.setColor(Color.BLACK);
        canvas.drawText("Current Risk Level:", 50, y, paint);
        
        Paint riskPaint = new Paint();
        riskPaint.setTextSize(18);
        riskPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        
        String safeRisk = riskLevel != null ? riskLevel.toLowerCase() : "normal";
        if (safeRisk.contains("low") || safeRisk.contains("normal") || safeRisk.contains("stage i")) {
            riskPaint.setColor(Color.parseColor("#10B981")); // Emerald Green
        } else if (safeRisk.contains("medium") || safeRisk.contains("moderate") || safeRisk.contains("stage ii")) {
            riskPaint.setColor(Color.parseColor("#F59E0B")); // Amber/Orange
        } else {
            riskPaint.setColor(Color.parseColor("#EF4444")); // Red
        }
        canvas.drawText(riskLevel, 200, y, riskPaint);
        y += 60;

        // Detailed Data Section
        titlePaint.setTextSize(18);
        titlePaint.setColor(Color.parseColor("#334155"));
        canvas.drawText("Detailed Parameters:", 50, y, titlePaint);
        y += 30;

        // Table Header Line
        paint.setColor(Color.parseColor("#E2E8F0"));
        canvas.drawRect(50, y, 545, y + 30, paint);
        
        paint.setColor(Color.parseColor("#475569"));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(14);
        canvas.drawText("PARAMETER", 70, y + 20, paint);
        canvas.drawText("VALUE", 300, y + 20, paint);
        y += 50;

        paint.setTypeface(Typeface.DEFAULT);
        paint.setColor(Color.BLACK);
        paint.setTextSize(14);
        
        // Add Common Row: Date
        canvas.drawText("Assessment Date", 70, y, paint);
        canvas.drawText(timestamp, 300, y, paint);
        y += 30;

        // Dynamic Rows from JSON
        if (detailsJson != null) {
            try {
                JSONObject json = new JSONObject(detailsJson);
                Iterator<String> keys = json.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    String value = json.getString(key);
                    
                    // Formatting key for display (e.g., camelCase to Proper Case)
                    String displayKey = formatKey(key);
                    
                    canvas.drawText(displayKey, 70, y, paint);
                    canvas.drawText(value, 300, y, paint);
                    y += 30;
                    
                    if (y > 750) { // New page if needed
                        pdfDocument.finishPage(page);
                        page = pdfDocument.startPage(pageInfo);
                        canvas = page.getCanvas();
                        y = 60;
                        
                        // Redraw table header on new page
                        paint.setColor(Color.parseColor("#E2E8F0"));
                        canvas.drawRect(50, y, 545, y + 30, paint);
                        paint.setColor(Color.parseColor("#475569"));
                        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                        canvas.drawText("PARAMETER", 70, y + 20, paint);
                        canvas.drawText("VALUE", 300, y + 20, paint);
                        y += 50;
                        paint.setTypeface(Typeface.DEFAULT);
                        paint.setColor(Color.BLACK);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Disclaimer at the bottom
        y = 790;
        paint.setTextSize(10);
        paint.setColor(Color.GRAY);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.ITALIC));
        canvas.drawText("Disclaimer: This is an automatically generated screening report. It is NOT a medical diagnosis.", 50, y, paint);
        canvas.drawText("Please consult with a healthcare professional for accurate diagnosis and treatment.", 50, y + 15, paint);

        pdfDocument.finishPage(page);

        // Save the PDF
        String fileName = "SafePulse_" + moduleName + "_Report_" + System.currentTimeMillis() + ".pdf";
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues);
                if (uri != null) {
                    OutputStream outputStream = context.getContentResolver().openOutputStream(uri);
                    pdfDocument.writeTo(outputStream);
                    outputStream.close();
                    Toast.makeText(context, "PDF downloaded to Downloads folder", Toast.LENGTH_LONG).show();
                }
            } else {
                java.io.File file = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), fileName);
                pdfDocument.writeTo(new java.io.FileOutputStream(file));
                Toast.makeText(context, "PDF saved to " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Error saving PDF: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            pdfDocument.close();
        }
    }

    private static String formatKey(String key) {
        if (key == null || key.isEmpty()) return "";
        
        // Remove underscores and capitalize each word
        String[] words = key.split("_");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                sb.append(Character.toUpperCase(word.charAt(0)));
                sb.append(word.substring(1).toLowerCase());
                sb.append(" ");
            }
        }
        return sb.toString().trim();
    }
}
