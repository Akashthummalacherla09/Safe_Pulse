package com.simats.safe_pulse;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Map;
import java.util.HashMap;

public class HealthScoreManager {
    private static final String PREF_NAME = "HealthScorePrefs";
    private static final String KEY_PREFIX_SCORE = "score_";
    private static final String KEY_PREFIX_RISK = "risk_";
    private static final String KEY_PREFIX_TIMESTAMP = "timestamp_";
    private static final String KEY_PREFIX_DETAILS = "details_";

    private static SharedPreferences getPrefs(Context context) {
        SharedPreferences sessionPrefs = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        int userId = sessionPrefs.getInt("USER_ID", 1); // Default to 1 if not found
        return context.getSharedPreferences(PREF_NAME + "_" + userId, Context.MODE_PRIVATE);
    }

    public static void saveModuleScore(Context context, String moduleName, int score, String riskLevel) {
        saveModuleScore(context, moduleName, score, riskLevel, null);
    }

    public static void saveModuleScore(Context context, String moduleName, int score, String riskLevel, String detailsJson) {
        SharedPreferences prefs = getPrefs(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_PREFIX_SCORE + moduleName, score);
        editor.putString(KEY_PREFIX_RISK + moduleName, riskLevel);
        editor.putLong(KEY_PREFIX_TIMESTAMP + moduleName, System.currentTimeMillis());
        if (detailsJson != null) {
            editor.putString(KEY_PREFIX_DETAILS + moduleName, detailsJson);
        }
        editor.apply();

        SharedPreferences sessionPrefs = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        int userId = sessionPrefs.getInt("USER_ID", -1);

        // Save through Repository for Cloud-Sync
        HealthDataRepository repository = HealthDataRepository.getInstance(context);
        repository.saveAssessmentResult(userId, moduleName, score, riskLevel, detailsJson);
        
        android.util.Log.d("REPO_SYNC", "HealthDataRepository synced " + moduleName + " with userId " + userId);
    }

    public static int calculateScoreByUserId(DatabaseHelper dbHelper, int userId) {
        java.util.List<DatabaseHelper.Report> reports = dbHelper.getReportsByUserId(userId);
        if (reports == null || reports.isEmpty()) return -1;

        java.util.Map<String, Integer> latestScores = new java.util.HashMap<>();
        for (DatabaseHelper.Report report : reports) {
            String module = report.getModule();
            if (module != null) {
                String normalizedModule = module.toLowerCase().replace("dailytracker", "daily_tracker");
                if (!latestScores.containsKey(normalizedModule)) {
                    latestScores.put(normalizedModule, report.getScore());
                }
            }
        }

        if (latestScores.isEmpty()) return -1;

        float sum = 0;
        // Include diagnostic modules + daily tracker
        String[] allPossibleModules = {"kidney", "heart", "lung", "liver", "cancer", "brain", "daily_tracker"};
        for (String m : allPossibleModules) {
            if (latestScores.containsKey(m)) {
                sum += latestScores.get(m);
            }
        }
        
        return Math.round(sum / 7.0f);
    }


    private static void syncWithBackend(Context context, String moduleName, int score, String riskLevel, String detailsJson) {
        // BACKEND REMOVED: Mocking sync success
        android.util.Log.d("BACKEND_SYNC", "MOCK: Sync bypassed for " + moduleName);
    }

    public static String getModuleDetails(Context context, String moduleName) {
        SharedPreferences prefs = getPrefs(context);
        return prefs.getString(KEY_PREFIX_DETAILS + moduleName, null);
    }

    public static Map<String, String> getModuleStatus(Context context, String moduleName) {
        SharedPreferences prefs = getPrefs(context);
        Map<String, String> status = new HashMap<>();
        if (prefs.contains(KEY_PREFIX_SCORE + moduleName)) {
            status.put("score", String.valueOf(prefs.getInt(KEY_PREFIX_SCORE + moduleName, 0)));
            status.put("risk", prefs.getString(KEY_PREFIX_RISK + moduleName, "N/A"));
            long ts = prefs.getLong(KEY_PREFIX_TIMESTAMP + moduleName, 0);
            status.put("timestamp", new java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(new java.util.Date(ts)));
        }
        return status;
    }

    public static Map<String, Integer> getAllScores(Context context) {
        SharedPreferences prefs = getPrefs(context);
        Map<String, Integer> scores = new HashMap<>();
        
        // Diagnostic Assessment Modules
        String[] diagnosticModules = {"kidney", "heart", "lung", "liver", "cancer", "brain"};
        for (String module : diagnosticModules) {
            if (prefs.contains(KEY_PREFIX_SCORE + module)) {
                scores.put(module, prefs.getInt(KEY_PREFIX_SCORE + module, 0));
            }
        }
        
        // Daily Tracker Score
        if (prefs.contains(KEY_PREFIX_SCORE + "daily_tracker")) {
            scores.put("daily_tracker", prefs.getInt(KEY_PREFIX_SCORE + "daily_tracker", 0));
        } else if (prefs.contains(KEY_PREFIX_SCORE + "DailyTracker")) {
            scores.put("daily_tracker", prefs.getInt(KEY_PREFIX_SCORE + "DailyTracker", 0));
        }
        
        return scores;
    }

    public static int calculateOverallScore(Context context) {
        Map<String, Integer> scores = getAllScores(context);
        if (scores.isEmpty()) return -1;

        float sum = 0;
        for (int score : scores.values()) {
            sum += score;
        }
        // Total modules used for division: 7 (Diagnostic + Daily Tracker)
        return Math.round(sum / 7.0f);
    }

    public static void deleteModuleData(Context context, String moduleName) {
        SharedPreferences prefs = getPrefs(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(KEY_PREFIX_SCORE + moduleName);
        editor.remove(KEY_PREFIX_RISK + moduleName);
        editor.remove(KEY_PREFIX_TIMESTAMP + moduleName);
        editor.apply();
    }

    public static void clearUserCache(Context context, int userId) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME + "_" + userId, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();
        android.util.Log.d("CACHE_PURGE", "Cleared local cache for User " + userId);
    }

    // Scoring logic is now centralized in AssessmentEngine. 
    // These methods remain for backward compatibility but call AssessmentEngine where possible.

    // Daily Tracker Score calculation
    public static int getDailyTrackerScore(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("DailyTrackerPrefs", Context.MODE_PRIVATE);
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
        
        float water = prefs.getFloat(today + "_water", 0.0f);
        boolean smoked = prefs.getBoolean(today + "_smoked", false);
        int steps = 0;
        try { steps = Integer.parseInt(prefs.getString(today + "_steps", "0")); } catch (Exception e) {}
        float sleep = 0.0f;
        try { sleep = Float.parseFloat(prefs.getString(today + "_sleep", "0")); } catch (Exception e) {}
        int calories = 0;
        try { calories = Integer.parseInt(prefs.getString(today + "_calories", "0")); } catch (Exception e) {}
        
        return AssessmentEngine.DailyTracker.calculateScore(water, smoked, steps, sleep, calories);
    }

    public static void syncTrackerWithBackend(Context context, TrackerRequest data) {
        HealthDataRepository.getInstance(context).updateHealthTracker(data);
        android.util.Log.d("REPO_SYNC", "Tracker sync triggered for Daily Data");
    }

    public static void saveWeeklyHistory(Context context, int score) {
        SharedPreferences sessionPrefs = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        int userId = sessionPrefs.getInt("USER_ID", 1);
        SharedPreferences historyPrefs = context.getSharedPreferences("WeeklyHistory_" + userId, Context.MODE_PRIVATE);
        
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(new java.util.Date());
        historyPrefs.edit().putInt(today, score).apply();
    }

    public static int getWeeklyAverage(Context context) {
        SharedPreferences sessionPrefs = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        int userId = sessionPrefs.getInt("USER_ID", 1);
        SharedPreferences historyPrefs = context.getSharedPreferences("WeeklyHistory_" + userId, Context.MODE_PRIVATE);
        
        Map<String, ?> allEntries = historyPrefs.getAll();
        if (allEntries.isEmpty()) return 0;
        
        int sum = 0;
        int count = 0;
        for (Object val : allEntries.values()) {
            if (val instanceof Integer) {
                sum += (Integer) val;
                count++;
            }
        }
        return count > 0 ? sum / count : 0;
    }

    public static void syncAllLocalReports(Context context) {
        // Now calling the repository sync
        HealthDataRepository.getInstance(context).syncAllData();
    }

    public static void pullReportsFromServer(Context context) {
        HealthDataRepository.getInstance(context).syncAllData();
    }

    public static void saveModuleScoreLocalOnly(Context context, String moduleName, int score, String riskLevel) {
        SharedPreferences prefs = getPrefs(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_PREFIX_SCORE + moduleName, score);
        editor.putString(KEY_PREFIX_RISK + moduleName, riskLevel);
        editor.putLong(KEY_PREFIX_TIMESTAMP + moduleName, System.currentTimeMillis());
        editor.apply();

        SharedPreferences sessionPrefs = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        int userId = sessionPrefs.getInt("USER_ID", -1);
        
        HealthDataRepository.getInstance(context).saveAssessmentResult(userId, moduleName, score, riskLevel, null);
    }
}
