package com.simats.safe_pulse;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UserProfileActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId;
    private EditText editName, editEmail, editPhone, editDob, editGender, editAddress, editEmergencyContact;
    private TextView avatarText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_profile);
        dbHelper = new DatabaseHelper(this);

        // Get User ID from Session if not provided by Intent (for Admin)
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
            userId = prefs.getInt("USER_ID", -1);
        }

        if (userId == -1) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        avatarText = findViewById(R.id.profile_avatar_text);
        editName = findViewById(R.id.edit_full_name);
        editEmail = findViewById(R.id.edit_email);
        editPhone = findViewById(R.id.edit_phone);
        editDob = findViewById(R.id.edit_dob);
        editGender = findViewById(R.id.edit_gender);
        editAddress = findViewById(R.id.edit_address);
        editEmergencyContact = findViewById(R.id.edit_emergency_contact);

        // Check for View-Only Mode
        boolean isViewOnly = getIntent().getBooleanExtra("IS_VIEW_ONLY", false);
        if (isViewOnly) {
            setupViewOnlyMode();
        }

        // Click Listeners
        findViewById(R.id.btn_back_to_settings).setOnClickListener(v -> finish());
        findViewById(R.id.btn_save_changes).setOnClickListener(v -> saveProfileChanges());

        // Load Data
        loadUserProfile();
    }

    private void loadUserProfile() {
        DatabaseHelper.User user = dbHelper.getUserById(userId);
        if (user != null) {
            editName.setText(user.getName());
            editEmail.setText(user.getEmail());
            editPhone.setText(user.getPhone() != null ? user.getPhone() : "");
            editDob.setText(user.getDob() != null ? user.getDob() : "");
            editGender.setText(user.getGender() != null ? user.getGender() : "");
            editAddress.setText(user.getAddress() != null ? user.getAddress() : "");
            editEmergencyContact.setText(user.getEmergencyContact() != null ? user.getEmergencyContact() : "");
            setAvatarInitials(user.getName());
        } else {
            // Check if full details were passed in intent (from Admin User Management)
            String intentName = getIntent().getStringExtra("USER_NAME");
            String intentEmail = getIntent().getStringExtra("USER_EMAIL");
            String intentPhone = getIntent().getStringExtra("USER_PHONE");
            String intentDob = getIntent().getStringExtra("USER_DOB");
            String intentGender = getIntent().getStringExtra("USER_GENDER");
            String intentAddress = getIntent().getStringExtra("USER_ADDRESS");
            String intentEmergency = getIntent().getStringExtra("USER_EMERGENCY");

            if (intentName != null && !intentName.isEmpty()) {
                editName.setText(intentName);
                editEmail.setText(intentEmail);
                editPhone.setText(intentPhone != null ? intentPhone : "");
                editDob.setText(intentDob != null ? intentDob : "");
                editGender.setText(intentGender != null ? intentGender : "");
                editAddress.setText(intentAddress != null ? intentAddress : "");
                editEmergencyContact.setText(intentEmergency != null ? intentEmergency : "");
                setAvatarInitials(intentName);
            } else {
                // Fallback to SharedPreferences (for the currently logged in user themselves)
                SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
                String name = prefs.getString("USER_NAME", "");
                String email = prefs.getString("USER_EMAIL", "");
                
                if (!name.isEmpty()) {
                    editName.setText(name);
                    editEmail.setText(email);
                    setAvatarInitials(name);
                }
            }
        }
    }

    private void setAvatarInitials(String name) {
        if (name != null && !name.isEmpty()) {
            String initials = "";
            String[] parts = name.split(" ");
            if (parts.length > 0 && !parts[0].isEmpty()) initials += parts[0].substring(0, 1).toUpperCase();
            if (parts.length > 1 && !parts[1].isEmpty()) initials += parts[1].substring(0, 1).toUpperCase();
            avatarText.setText(initials);
        }
    }

    private void saveProfileChanges() {
        String name = editName.getText().toString().trim();
        String email = editEmail.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();
        String dob = editDob.getText().toString().trim();
        String gender = editGender.getText().toString().trim();
        String address = editAddress.getText().toString().trim();
        String emergency = editEmergencyContact.getText().toString().trim();

        if (name.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Name and Email are required", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = dbHelper.updateUser(userId, name, email, phone, dob, gender, address, emergency);
        if (success) {
            Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show();
            
            // Sync with session if current user
            SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
            if (prefs.getInt("USER_ID", -1) == userId) {
                prefs.edit().putString("USER_NAME", name).putString("USER_EMAIL", email).apply();
                
                // NEW: Sync with Backend API
                syncProfileWithServer(name, phone, dob, gender, address, emergency);
            }
            
            // Refresh initials in case name changed
            loadUserProfile();
        } else {
            Toast.makeText(this, "Failed to update profile", Toast.LENGTH_SHORT).show();
        }
    }

    private void syncProfileWithServer(String name, String phone, String dob, String gender, String address, String emergency) {
        java.util.Map<String, Object> payload = new java.util.HashMap<>();
        payload.put("full_name", name);
        payload.put("phone", phone);
        payload.put("dob", dob);
        payload.put("gender", gender);
        payload.put("address", address);
        payload.put("emergency_contact", emergency);

        RetrofitClient.getApiService(this).updateProfile(payload).enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful()) {
                    android.util.Log.d("PROFILE_SYNC", "User profile synchronized with Cloud");
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                android.util.Log.e("PROFILE_SYNC", "Cloud synchronization failed", t);
            }
        });
    }

    private void fetchProfileFromServer() {
        RetrofitClient.getApiService(this).getProfile().enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    java.util.Map<String, Object> data = response.body();
                    // Update local DB and UI if needed
                    android.util.Log.d("PROFILE_SYNC", "Clinical profile fetched from Cloud");
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                android.util.Log.e("PROFILE_SYNC", "Cloud pull failed", t);
            }
        });
    }

    private void setupViewOnlyMode() {
        // Change Title
        TextView title = findViewById(R.id.profile_title);
        if (title != null) title.setText("User Profile");

        // Disable all inputs
        editName.setEnabled(false);
        editEmail.setEnabled(false);
        editPhone.setEnabled(false);
        editDob.setEnabled(false);
        editGender.setEnabled(false);
        editAddress.setEnabled(false);
        editEmergencyContact.setEnabled(false);

        // Hide Save Button
        findViewById(R.id.btn_save_changes).setVisibility(android.view.View.GONE);

        // Change Cancel button to 'Back'
        androidx.appcompat.widget.AppCompatButton backBtn = findViewById(R.id.btn_back_to_settings);
        if (backBtn != null) backBtn.setText("← Back to List");
    }
}
