package com.simats.safe_pulse;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AlzheimerPreventionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_alzheimer_prevention);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String riskLevel = getIntent().getStringExtra("RISK_LEVEL");
        if (riskLevel == null) riskLevel = "Low Risk";

        populateStrategies(riskLevel);
        populateLifestyle();

        // Navigation
        findViewById(R.id.btn_back_alz_prev).setOnClickListener(v -> finish());
        
        findViewById(R.id.btn_dashboard_alz_prev).setOnClickListener(v -> {
            Intent intent = new Intent(AlzheimerPreventionActivity.this, UserDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void populateStrategies(String riskLevel) {
        LinearLayout container = findViewById(R.id.container_prevention_strategies);

        // Define colors
        int blueDark = Color.parseColor("#0D47A1");
        int blueLight = Color.parseColor("#1565C0");
        int blueBg = Color.parseColor("#E3F2FD");
        int blueBar = Color.parseColor("#2196F3");

        int greenDark = Color.parseColor("#1B5E20");
        int greenLight = Color.parseColor("#2E7D32");
        int greenBg = Color.parseColor("#E8F5E9");
        int greenBar = Color.parseColor("#43A047");

        int purpleDark = Color.parseColor("#4A148C");
        int purpleLight = Color.parseColor("#6A1B9A");
        int purpleBg = Color.parseColor("#F3E5F5");
        int purpleBar = Color.parseColor("#8E24AA");
        
        int redDark = Color.parseColor("#B71C1C");
        int redLight = Color.parseColor("#C62828");
        int redBg = Color.parseColor("#FFEBEE");
        int redBar = Color.parseColor("#E53935");

        if (riskLevel.contains("Low") || riskLevel.contains("Normal")) {
            // Standard Prevention (Screenshot Content)
            
            addStrategyCard(container, "Keep Your Brain Active",
                "Mental stimulation builds cognitive reserve and may delay decline.",
                new String[]{
                    "Solve puzzles, crosswords, Sudoku daily",
                    "Learn new skills (language, instrument)",
                    "Read books and engage in discussions",
                    "Play strategy games (chess, bridge)"
                },
                blueDark, blueLight, blueBg, blueBar);

            addStrategyCard(container, "Physical Exercise",
                "Regular physical activity improves brain health and reduces dementia risk.",
                new String[]{
                    "30 minutes of exercise most days",
                    "Aerobic exercise boosts blood flow to brain",
                    "Walking, swimming, dancing are great",
                    "Reduces risk by up to 30%"
                },
                greenDark, greenLight, greenBg, greenBar);

            addStrategyCard(container, "Social Engagement",
                "Stay socially connected to maintain cognitive function.",
                new String[]{
                    "Maintain close friendships and family ties",
                    "Join clubs or volunteer organizations",
                    "Attend social events regularly",
                    "Isolation increases dementia risk"
                },
                purpleDark, purpleLight, purpleBg, purpleBar);

        } else if (riskLevel.contains("Mild") || riskLevel.contains("Moderate")) {
            // Need more structure
            
            addStrategyCard(container, "Cognitive Rehabilitation",
                "Structured mental exercises can help maintain current function.",
                new String[]{
                    "Memory training exercises",
                    "Use calendars and reminders for daily tasks",
                    "Break tasks into smaller steps",
                    "Maintain a consistent daily routine"
                },
                blueDark, blueLight, blueBg, blueBar);

            addStrategyCard(container, "Medical Management",
                "Close monitoring by healthcare professionals is key.",
                new String[]{
                    "Regular check-ups with a neurologist",
                    "Monitor and manage blood pressure and diabetes",
                    "Review medications for potential side effects",
                    "Consider clinical trials if eligible"
                },
                redDark, redLight, redBg, redBar);
                
        } else {
            // High Risk -> Care & Safety focus
            
            addStrategyCard(container, "Safety First",
                "Modifying the environment to ensure safety is priority.",
                new String[]{
                    "Remove trip hazards in the home",
                    "Install grab bars in bathrooms",
                    "Use medical alert systems",
                    "Ensure proper lighting throughout the home"
                },
                redDark, redLight, redBg, redBar);

            addStrategyCard(container, "Care Planning",
                "Discuss future care needs and legal arrangements.",
                new String[]{
                    "Establish power of attorney for health/finances",
                    "Discuss care preferences with family",
                    "Explore home care or assisted living options",
                    "Join caregiver support groups"
                },
                purpleDark, purpleLight, purpleBg, purpleBar);
        }
    }

    private void populateLifestyle() {
        LinearLayout container = findViewById(R.id.container_brain_lifestyle);
        
        // Always relevant
        
        addLifestyleCard(container, "Mediterranean Diet",
            "Rich in fruits, vegetables, fish, nuts, and olive oil. Reduces Alzheimer's risk by 40%.",
            Color.parseColor("#E8F5E9"), // Greenish
            Color.parseColor("#1B5E20"),
            Color.parseColor("#2E7D32"));

        addLifestyleCard(container, "Quality Sleep",
            "7-9 hours nightly. Sleep clears brain toxins that contribute to Alzheimer's.",
            Color.parseColor("#FFFDE7"), // Yellowish
            Color.parseColor("#F57F17"),
            Color.parseColor("#F9A825"));

        addLifestyleCard(container, "Manage Stress",
            "Chronic stress damages brain cells. Practice meditation, yoga, or relaxation techniques.",
            Color.parseColor("#FFEBEE"), // Pinkish
            Color.parseColor("#B71C1C"),
            Color.parseColor("#C62828"));
    }

    private void addStrategyCard(LinearLayout container, String title, String desc, String[] bullets, int titleColor, int descColor, int bgColor, int barColor) {
        View cardView = getLayoutInflater().inflate(R.layout.item_prevention_tip, container, false);

        // Customize Colors
        LinearLayout bgLayout = cardView.findViewById(R.id.tip_bg);
        bgLayout.setBackgroundColor(bgColor);

        View barView = cardView.findViewById(R.id.tip_bar);
        barView.setBackgroundColor(barColor);

        TextView tvTitle = cardView.findViewById(R.id.tip_title);
        tvTitle.setText(title);
        tvTitle.setTextColor(titleColor);

        TextView tvDesc = cardView.findViewById(R.id.tip_desc);
        tvDesc.setText(desc);
        tvDesc.setTextColor(descColor);

        // Add Bullets
        LinearLayout bulletsContainer = cardView.findViewById(R.id.tip_bullets_container);
        for (String bullet : bullets) {
            TextView tvBullet = new TextView(this);
            tvBullet.setText("• " + bullet);
            tvBullet.setTextColor(descColor);
            tvBullet.setTextSize(14);
            tvBullet.setPadding(0, 4, 0, 4);
            bulletsContainer.addView(tvBullet);
        }

        container.addView(cardView);
    }

    private void addLifestyleCard(LinearLayout container, String title, String desc, int bgColor, int titleColor, int descColor) {
        View cardView = getLayoutInflater().inflate(R.layout.item_brain_lifestyle, container, false);
        
        LinearLayout bg = cardView.findViewById(R.id.card_bg_brain);
        
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(32); // 12dp approx
        shape.setColor(bgColor);
        bg.setBackground(shape);

        TextView tvTitle = cardView.findViewById(R.id.card_title_brain);
        tvTitle.setText(title);
        tvTitle.setTextColor(titleColor);

        TextView tvDesc = cardView.findViewById(R.id.card_desc_brain);
        tvDesc.setText(desc);
        tvDesc.setTextColor(descColor);

        container.addView(cardView);
    }
}
