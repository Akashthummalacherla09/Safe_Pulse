package com.simats.safe_pulse;

import com.google.gson.annotations.SerializedName;
import java.util.Map;

public class ReportRequest {
    @SerializedName("user_id")
    private int userId;
    
    @SerializedName("assessment_type")
    private String assessmentType;
    
    @SerializedName("score")
    private int score;
    
    @SerializedName("result")
    private String result;

    @SerializedName("details")
    private Map<String, Object> details;

    public ReportRequest(int userId, String assessmentType, int score, String result) {
        this(userId, assessmentType, score, result, null);
    }

    public ReportRequest(int userId, String assessmentType, int score, String result, Map<String, Object> details) {
        this.userId = userId;
        this.assessmentType = assessmentType;
        this.score = score;
        this.result = result;
        this.details = details;
    }

    // Getters and Setters
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getAssessmentType() { return assessmentType; }
    public void setAssessmentType(String assessmentType) { this.assessmentType = assessmentType; }
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }
    public Map<String, Object> getDetails() { return details; }
    public void setDetails(Map<String, Object> details) { this.details = details; }
}
