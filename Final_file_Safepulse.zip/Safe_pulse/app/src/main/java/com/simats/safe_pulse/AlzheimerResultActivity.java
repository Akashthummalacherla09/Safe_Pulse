package com.simats.safe_pulse;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.drawable.GradientDrawable;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AlzheimerResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_alzheimer_result);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. Get Inputs
        int score = getIntent().getIntExtra("SCORE", 0);
        int age = getIntent().getIntExtra("AGE", 0);
        String clinical = getIntent().getStringExtra("CLINICAL");
        String family = getIntent().getStringExtra("FAMILY");
        
        if (clinical == null) clinical = "Normal";
        if (family == null) family = "No";

        // 🧬 Centralized Scoring Engine (Calculated 1:1 with Web)
        java.util.Map<String, Object> result = AssessmentEngine.calculateBrain(score, age, clinical, family.equalsIgnoreCase("Yes"));
        
        String riskLevelStr = (String) result.get("riskLevel");
        int finalScore = (int) result.get("score");
        String statusTitle = (String) result.get("statusTitle");

        // 🟢 Standardized Data Struct (Ready for submit_report.php)
        try {
            org.json.JSONObject details = new org.json.JSONObject();
            details.put("mmse", score);
            details.put("age", age);
            details.put("clinical", clinical);
            details.put("family_history", family.equalsIgnoreCase("Yes"));
            
            HealthScoreManager.saveModuleScore(this, "brain", finalScore, riskLevelStr.toLowerCase(), details.toString());
        } catch (org.json.JSONException e) {
            HealthScoreManager.saveModuleScore(this, "brain", finalScore, riskLevelStr.toLowerCase());
        }

        // Update UI
        TextView tvStatus = findViewById(R.id.tv_status_title);
        TextView tvBadge = findViewById(R.id.tv_risk_badge);
        TextView tvExplanation = findViewById(R.id.tv_explanation_text);
        android.widget.FrameLayout cardBg = findViewById(R.id.card_result_bg);

        tvStatus.setText(statusTitle);
        tvBadge.setText("Risk: " + riskLevelStr);

        if (riskLevelStr.contains("Low")) {
            cardBg.setBackgroundResource(R.drawable.bg_card_result_green);
            tvExplanation.setText("Your cognitive screening results are within normal limits. \n\nIndication: Routine checkups with a general physician are sufficient.");
        } else if (riskLevelStr.contains("Mild")) {
            cardBg.setBackgroundResource(R.drawable.bg_card_result_orange);
            tvExplanation.setText("Your results suggest mild cognitive changes. \n\nIndication: Routine checkups with a general physician are sufficient.");
        } else if (riskLevelStr.contains("Moderate")) {
            cardBg.setBackgroundResource(R.drawable.bg_card_result_orange);
            tvExplanation.setText("Your cognitive assessment indicates significant impairment. \n\nIndication: You may want to consult a Neurologist for a checkup.");
        } else {
            cardBg.setBackgroundResource(R.drawable.bg_card_result_red);
            tvExplanation.setText("Your results indicate severe cognitive impairment. \n\nURGENT: Please visit a Neurologist immediately.");
        }

        // 4. Navigation
        findViewById(R.id.btn_back_header).setOnClickListener(v -> finish());
        findViewById(R.id.btn_back_dashboard).setOnClickListener(v -> finish());
        
        findViewById(R.id.btn_prevention_tips_alz).setOnClickListener(v -> {
             Intent intent = new Intent(AlzheimerResultActivity.this, AlzheimerPreventionActivity.class);
             intent.putExtra("RISK_LEVEL", riskLevelStr);
             startActivity(intent);
        });
    }
}
