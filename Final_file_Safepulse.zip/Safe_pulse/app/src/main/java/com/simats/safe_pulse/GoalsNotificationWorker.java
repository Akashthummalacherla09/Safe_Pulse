package com.simats.safe_pulse;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class GoalsNotificationWorker extends Worker {

    private static final String CHANNEL_ID = "Goals_Progress_Channel";

    public GoalsNotificationWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();

        // Calculate progress
        java.util.Map<String, Integer> scores = HealthScoreManager.getAllScores(context);
        int heartScore = scores.containsKey("Heart") ? scores.get("Heart") : 85;
        int cholScore = scores.containsKey("Heart") ? Math.max(0, scores.get("Heart") - 5) : 60;
        int kidneyScore = scores.containsKey("Kidney") ? scores.get("Kidney") : 90;
        int lungScore = scores.containsKey("Lung") ? scores.get("Lung") : 100;

        int overallAverage = (heartScore + cholScore + kidneyScore + lungScore) / 4;

        String title = "Daily Health Goals Update\uD83C\uDFAF";
        String message;

        if (overallAverage >= 90) {
            message = "Exceptional progress! You're hitting almost all targets. Current score: " + overallAverage + "%";
        } else if (overallAverage >= 75) {
            message = "Great job! Keep progressing toward your objectives. Current score: " + overallAverage + "%";
        } else {
            message = "Keep going! Consistency is key to your health goals. Current score: " + overallAverage + "%";
        }

        sendNotification(title, message);

        return Result.success();
    }

    private void sendNotification(String title, String message) {
        Context context = getApplicationContext();
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Health Goals Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Daily notifications about health goals progress");
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        Intent intent = new Intent(context, DailyTrackerActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        if (notificationManager != null) {
            notificationManager.notify(1001, builder.build());
        }
    }
}
