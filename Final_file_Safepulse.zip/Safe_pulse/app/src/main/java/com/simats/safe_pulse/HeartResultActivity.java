package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.FrameLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HeartResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_heart_result);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView riskPercentageText = findViewById(R.id.text_risk_percentage);
        TextView riskLevelText = findViewById(R.id.text_risk_level);
        TextView explanationText = findViewById(R.id.text_explanation);
        FrameLayout cardResultBg = findViewById(R.id.card_result_bg);
        
        TextView metricCholesterol = findViewById(R.id.metric_cholesterol);
        TextView metricBP = findViewById(R.id.metric_bp);
        TextView metricLDL = findViewById(R.id.metric_ldl);
        TextView metricSugar = findViewById(R.id.metric_sugar);
        TextView metricECG = findViewById(R.id.metric_ecg);

        Button preventionButton = findViewById(R.id.btn_prevention);
        Button backDashboardButton = findViewById(R.id.btn_back_dashboard);

        // Get Data from Intent
        String systolicStr = getIntent().getStringExtra("SYSTOLIC");
        String diastolicStr = getIntent().getStringExtra("DIASTOLIC");
        String cholesterolStr = getIntent().getStringExtra("CHOLESTEROL");
        String ldlStr = getIntent().getStringExtra("LDL");
        String sugarStr = getIntent().getStringExtra("SUGAR");
        String ecgStr = getIntent().getStringExtra("ECG");

        // Parse Values (Safe)
        int systolic = parseInt(systolicStr, 120);
        int diastolic = parseInt(diastolicStr, 80);
        int cholesterol = parseInt(cholesterolStr, 200);
        int ldl = parseInt(ldlStr, 100);
        int sugar = parseInt(sugarStr, 90);
        boolean isAbnormalECG = (ecgStr != null && ecgStr.equalsIgnoreCase("Abnormal"));

        // *** Heart Risk Calculation Logic (Unified Engine) ***
        java.util.Map<String, Object> result = AssessmentEngine.calculateHeart(systolic, diastolic, cholesterol, ldl, sugar, isAbnormalECG);
        
        String riskLevel = (String) result.get("riskLevel");
        String riskPercentage = (String) result.get("riskPercentage");
        int score = (int) result.get("score");

        String explanation = "";
        int bgDrawable = R.drawable.bg_card_result_green;

        if (riskLevel.contains("High")) {
            explanation = "Your results indicate a high risk of cardiovascular disease. \n\nURGENT: Please visit a Cardiologist immediately.";
            bgDrawable = R.drawable.bg_card_result_red;
        } else if (riskLevel.contains("Medium")) {
            explanation = "Your results indicate a moderate risk. \n\nIndication: You may want to consult a Cardiologist for a checkup.";
            bgDrawable = R.drawable.bg_card_result_orange;
        } else {
            explanation = "Your heart health is good! \n\nIndication: Routine checkups with a general physician are sufficient.";
            bgDrawable = R.drawable.bg_card_result_green;
        }

        // 🟢 Standardized Data Struct (Ready for submit_report.php)
        try {
            org.json.JSONObject details = new org.json.JSONObject();
            details.put("systolic", systolic);
            details.put("diastolic", diastolic);
            details.put("cholesterol", cholesterol);
            details.put("ldl", ldl);
            details.put("sugar", sugar);
            details.put("abnormal_ecg", isAbnormalECG);
            
            HealthScoreManager.saveModuleScore(this, "heart", score, riskLevel.toLowerCase(), details.toString());
        } catch (org.json.JSONException e) {
            HealthScoreManager.saveModuleScore(this, "heart", score, riskLevel.toLowerCase());
        }

        // Update UI
        riskLevelText.setText(riskLevel);
        riskPercentageText.setText(riskPercentage);
        explanationText.setText(explanation);
        cardResultBg.setBackgroundResource(bgDrawable);

        // Update Metrics Display
        metricBP.setText(systolic + "/" + diastolic + " mmHg");
        metricCholesterol.setText(cholesterol + " mg/dL");
        metricLDL.setText(ldl + " mg/dL");
        metricSugar.setText(sugar + " mg/dL");
        metricECG.setText(ecgStr != null ? ecgStr : "Normal");

        // Navigation
        findViewById(R.id.btn_back_header).setOnClickListener(v -> {
            Intent intent = new Intent(this, UserDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });

        generatePrevention(riskLevel);

        backDashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, UserDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });
    }

    private void generatePrevention(String risk) {
        android.widget.LinearLayout container = findViewById(R.id.list_prevention_tips);
        container.removeAllViews();

        class Tip {
            String t, d; boolean p;
            Tip(String t, String d, boolean p) { this.t = t; this.d = d; this.p = p; }
        }

        java.util.List<Tip> tips = new java.util.ArrayList<>();
        if (risk.contains("Low")) {
            tips.add(new Tip("Regular Exercise", "At least 150 mins weekly", true));
            tips.add(new Tip("Healthy Diet", "Focus on fruits and vegetables", true));
            tips.add(new Tip("Quit Smoking", "Reduces CHD risk significantly", false));
        } else if (risk.contains("Medium")) {
            tips.add(new Tip("DASH Diet", "Restrict sodium and fats", true));
            tips.add(new Tip("BP Monitoring", "Log BP weekly", true));
            tips.add(new Tip("Stop Smoking", "Immediate cessation required", false));
        } else {
            tips.add(new Tip("Cardiology Consult", "Immediate specialist visit", true));
            tips.add(new Tip("Daily BP Monitoring", "Log readings twice daily", false));
            tips.add(new Tip("Strict Salt Control", "Less than 1500mg daily", false));
        }

        for (Tip tip : tips) {
            android.view.View view = getLayoutInflater().inflate(R.layout.item_prevention_tip, container, false);
            TextView textT = view.findViewById(R.id.tip_title);
            TextView textD = view.findViewById(R.id.tip_desc);
            view.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor(tip.p ? "#E8F5E9" : "#FFEBEE")));
            textT.setText(tip.t);
            textD.setText(tip.d);
            container.addView(view);
        }
    }

    private int parseInt(String value, int defaultValue) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
}
