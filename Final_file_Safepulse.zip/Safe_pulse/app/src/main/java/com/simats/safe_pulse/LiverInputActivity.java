package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LiverInputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_liver_input);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView backButton = findViewById(R.id.btn_back);
        Button calculateButton = findViewById(R.id.btn_calculate);
        
        EditText inputAlt = findViewById(R.id.input_alt);
        EditText inputAst = findViewById(R.id.input_ast);
        EditText inputBilirubin = findViewById(R.id.input_bilirubin);
        EditText inputAlbumin = findViewById(R.id.input_albumin);
        EditText inputAlp = findViewById(R.id.input_alp);

        // Back Logic
        backButton.setOnClickListener(v -> finish());

        // Calculate Logic
        calculateButton.setOnClickListener(v -> {
            String altStr = inputAlt.getText().toString().trim();
            String astStr = inputAst.getText().toString().trim();
            String biliStr = inputBilirubin.getText().toString().trim();
            String albStr = inputAlbumin.getText().toString().trim();
            String alpStr = inputAlp.getText().toString().trim();

            if (altStr.isEmpty() || astStr.isEmpty() || biliStr.isEmpty() || albStr.isEmpty() || alpStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int alt = Integer.parseInt(altStr);
                int ast = Integer.parseInt(astStr);
                double bilirubin = Double.parseDouble(biliStr);
                double albumin = Double.parseDouble(albStr);
                int alp = Integer.parseInt(alpStr);

                Intent intent = new Intent(LiverInputActivity.this, LiverResultActivity.class);
                intent.putExtra("ALT", alt);
                intent.putExtra("AST", ast);
                intent.putExtra("BILIRUBIN", bilirubin);
                intent.putExtra("ALBUMIN", albumin);
                intent.putExtra("ALP", alp);
                startActivity(intent);

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter valid numeric values", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
