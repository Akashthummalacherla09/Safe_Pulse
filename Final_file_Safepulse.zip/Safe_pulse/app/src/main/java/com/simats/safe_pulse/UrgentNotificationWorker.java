package com.simats.safe_pulse;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class UrgentNotificationWorker extends Worker {

    private static final String CHANNEL_ID = "Urgent_Health_Channel";

    public UrgentNotificationWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();

        // Check for any urgent risks
        boolean hasUrgentIssue = false;
        StringBuilder messageBuilder = new StringBuilder("Immediate attention required for: ");

        String[] modules = {"Kidney", "Heart", "Lung", "Liver", "Cancer", "Alzheimer"};
        for (String module : modules) {
            java.util.Map<String, String> status = HealthScoreManager.getModuleStatus(context, module);
            if (status.containsKey("risk")) {
                String risk = status.get("risk");
                if (risk != null && (risk.contains("High") || risk.contains("Critical") || risk.contains("Severe") || risk.contains("Stage III") || risk.contains("Stage IV"))) {
                    hasUrgentIssue = true;
                    messageBuilder.append(module).append(" ");
                }
            }
        }

        if (hasUrgentIssue) {
            String title = "\u26A0\uFE0F URGENT: Medical Consultation Needed";
            String message = messageBuilder.toString().trim() + ". Please consult a specialist immediately.";
            sendNotification(title, message);
        }

        return Result.success();
    }

    private void sendNotification(String title, String message) {
        Context context = getApplicationContext();
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Urgent Health Alerts",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Critical notifications for urgent health risks");
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        Intent intent = new Intent(context, UserDashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        if (notificationManager != null) {
            notificationManager.notify(2002, builder.build());
        }
    }
}
