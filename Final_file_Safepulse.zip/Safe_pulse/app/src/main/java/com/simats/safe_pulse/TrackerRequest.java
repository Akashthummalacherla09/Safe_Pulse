package com.simats.safe_pulse;

public class TrackerRequest {
    private String date;
    private float water;
    private float weight;
    private int steps;
    private float sleep;
    private int calories;
    private int systolic;
    private int diastolic;
    private boolean smoked;
    private int score;

    public TrackerRequest() {
    }

    public TrackerRequest(String date, float water, float weight, int steps, float sleep, int calories, int systolic, int diastolic, boolean smoked, int score) {
        this.date = date;
        this.water = water;
        this.weight = weight;
        this.steps = steps;
        this.sleep = sleep;
        this.calories = calories;
        this.systolic = systolic;
        this.diastolic = diastolic;
        this.smoked = smoked;
        this.score = score;
    }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public float getWater() { return water; }
    public void setWater(float water) { this.water = water; }

    public float getWeight() { return weight; }
    public void setWeight(float weight) { this.weight = weight; }

    public int getSteps() { return steps; }
    public void setSteps(int steps) { this.steps = steps; }

    public float getSleep() { return sleep; }
    public void setSleep(float sleep) { this.sleep = sleep; }

    public int getCalories() { return calories; }
    public void setCalories(int calories) { this.calories = calories; }

    public int getSystolic() { return systolic; }
    public void setSystolic(int systolic) { this.systolic = systolic; }

    public int getDiastolic() { return diastolic; }
    public void setDiastolic(int diastolic) { this.diastolic = diastolic; }

    public boolean isSmoked() { return smoked; }
    public void setSmoked(boolean smoked) { this.smoked = smoked; }

    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
}
