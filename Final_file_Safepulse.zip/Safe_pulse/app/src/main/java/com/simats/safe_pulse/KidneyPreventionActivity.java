package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class KidneyPreventionActivity extends AppCompatActivity {

    private LinearLayout tipsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_kidney_prevention);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tipsContainer = findViewById(R.id.tips_container);
        Button backDashboardButton = findViewById(R.id.btn_back_dashboard);

        // Get Risk Level
        String riskLevel = getIntent().getStringExtra("RISK_LEVEL");
        if (riskLevel == null) riskLevel = "Low"; // Safe Fallback

        // Load Tips
        loadTips(riskLevel);

        // Navigation
        backDashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(KidneyPreventionActivity.this, UserDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadTips(String riskLevel) {
        List<Tip> tips = new ArrayList<>();

        switch (riskLevel) {
            case "Low":
                tips.add(new Tip("Stay Hydrated", "Drink 8–10 glasses of water daily", true));
                tips.add(new Tip("Control Blood Pressure", "Keep BP below 120/80 mmHg", true));
                tips.add(new Tip("Limit Salt", "Reduce sodium intake to under 2,300 mg/day", true));
                tips.add(new Tip("Regular Exercise", "At least 30 minutes daily", true));
                tips.add(new Tip("Healthy Diet", "Fruits, vegetables, whole grains", true));
                break;
            case "Medium":
                tips.add(new Tip("Monitor Kidney Function", "Repeat blood and urine tests every 6 months", true));
                tips.add(new Tip("Control Blood Pressure Strictly", "Keep BP under 130/80 mmHg", true));
                tips.add(new Tip("Reduce Salt Intake", "Limit sodium under 1,500–2,000 mg/day", true));
                tips.add(new Tip("Avoid NSAIDs", "Avoid ibuprofen and similar drugs", false));
                tips.add(new Tip("Moderate Protein Intake", "Avoid high-protein diets", true));
                tips.add(new Tip("Stay Hydrated", "Drink adequate water unless restricted", true));
                break;
            case "High":
                tips.add(new Tip("Consult a Nephrologist", "Schedule specialist consultation", true));
                tips.add(new Tip("Strict BP Control", "Below 130/80 mmHg", true));
                tips.add(new Tip("Strict Diabetes Control", "Keep HbA1c under 7%", true));
                tips.add(new Tip("Avoid NSAIDs Completely", "Do not take ibuprofen or naproxen", false));
                tips.add(new Tip("Low-Sodium Diet", "Under 1,500 mg/day", true));
                tips.add(new Tip("Protein Restriction", "Medical dietary guidance required", true));
                tips.add(new Tip("Routine Monitoring", "Every 3 months", true));
                break;
            case "Critical":
                tips.add(new Tip("Immediate Nephrologist Consultation", "Urgent care required", true));
                tips.add(new Tip("Dialysis Evaluation", "Assess need for renal replacement therapy", true));
                tips.add(new Tip("Strict Fluid Monitoring", "Follow doctor's fluid restrictions", true));
                tips.add(new Tip("Strict Diet Control", "Low potassium, low sodium", true));
                tips.add(new Tip("Avoid All Nephrotoxic Drugs", "Consult before taking any medication", false));
                tips.add(new Tip("Frequent Lab Monitoring", "As prescribed by specialist", true));
                tips.add(new Tip("Prepare for Advanced Treatment", "Discuss transplant/dialysis options", true));
                break;
        }

        for (Tip tip : tips) {
            addTipView(tip);
        }
    }

    private void addTipView(Tip tip) {
        // Create CardView
        CardView card = new CardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 32); // Bottom margin (approx 12dp)
        card.setLayoutParams(params);
        card.setRadius(32); // approx 12dp
        card.setCardElevation(8); 
        card.setCardBackgroundColor(0xFFFFFFFF);

        // Inner Layout (Horizontal)
        LinearLayout innerLayout = new LinearLayout(this);
        innerLayout.setOrientation(LinearLayout.HORIZONTAL);
        innerLayout.setPadding(32, 32, 32, 32); // Padding inside card
        innerLayout.setGravity(Gravity.CENTER_VERTICAL);
        
        // Icon Image View
        ImageView iconView = new ImageView(this);
        int iconSize = 120; // 40-48dp approx
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(iconSize, iconSize);
        iconView.setLayoutParams(iconParams);
        
        if (tip.isPositive) {
            iconView.setBackgroundResource(R.drawable.bg_circle_success_light);
            iconView.setImageResource(R.drawable.ic_check_green);
        } else {
            iconView.setBackgroundResource(R.drawable.bg_circle_error_light);
            iconView.setImageResource(R.drawable.ic_close_red);
        }
        iconView.setPadding(32, 32, 32, 32); // Padding inside circle to make icon smaller
        
        // Text Container (Vertical)
        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textParams.setMargins(32, 0, 0, 0); // Start margin
        textLayout.setLayoutParams(textParams);
        
        // Title
        TextView titleView = new TextView(this);
        titleView.setText(tip.title);
        titleView.setTextSize(16); // sp
        titleView.setTextColor(getResources().getColor(R.color.brand_dark));
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        
        // Description
        TextView descView = new TextView(this);
        descView.setText(tip.description);
        descView.setTextSize(13); // sp
        descView.setTextColor(getResources().getColor(R.color.role_subtext));
        
        textLayout.addView(titleView);
        textLayout.addView(descView);
        
        innerLayout.addView(iconView);
        innerLayout.addView(textLayout);
        
        card.addView(innerLayout);
        tipsContainer.addView(card);
    }

    private static class Tip {
        String title;
        String description;
        boolean isPositive;

        Tip(String title, String description, boolean isPositive) {
            this.title = title;
            this.description = description;
            this.isPositive = isPositive;
        }
    }
}
