package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LungResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lung_result);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get data from intent
        double fev1 = getIntent().getDoubleExtra("FEV1", 0);
        double fvc = getIntent().getDoubleExtra("FVC", 0); // Not used in risk calc directly but maybe good to have
        double ratio = getIntent().getDoubleExtra("RATIO", 0);
        double spo2 = getIntent().getDoubleExtra("SPO2", 0);
        boolean isSmoker = getIntent().getBooleanExtra("IS_SMOKER", false);

        // 🧬 Centralized Scoring Engine (Calculated 1:1 with Web)
        java.util.Map<String, Object> result = AssessmentEngine.calculateLung(fev1, ratio, spo2, isSmoker);
        
        String riskLevelStr = (String) result.get("riskLevel");
        String statusLabel = (String) result.get("status");
        int score = (int) result.get("score");

        String descStr = statusLabel + (statusLabel.equals("Normal") ? " Function" : " Impairment");
        String explStr = "";
        if (statusLabel.equals("Normal")) {
            explStr = "Your lung health appears good. \n\nIndication: Routine checkups with a general physician are sufficient.";
        } else if (statusLabel.equals("Mild")) {
            explStr = "Mild reduction in lung performance detected. \n\nIndication: Routine checkups with a general physician are sufficient.";
        } else if (statusLabel.equals("Moderate")) {
            explStr = "Moderate impairment in lung function detected. \n\nIndication: You may want to consult a Pulmonologist for a checkup.";
        } else {
            explStr = "Severe lung impairment detected. \n\nURGENT: Please visit a Pulmonologist immediately.";
        }

        // 🟢 Standardized Data Struct (Ready for submit_report.php)
        try {
            org.json.JSONObject details = new org.json.JSONObject();
            details.put("fev1", fev1);
            details.put("ratio", ratio);
            details.put("spo2", spo2);
            details.put("is_smoker", isSmoker);
            details.put("status", statusLabel);
            HealthScoreManager.saveModuleScore(this, "lung", score, statusLabel.toLowerCase(), details.toString());
        } catch (org.json.JSONException e) {
            HealthScoreManager.saveModuleScore(this, "lung", score, statusLabel.toLowerCase());
        }

        ((TextView)findViewById(R.id.text_risk_level)).setText(riskLevelStr);
        ((TextView)findViewById(R.id.text_risk_description)).setText(descStr);
        ((TextView)findViewById(R.id.text_explanation)).setText(explStr);

        // Buttons
        findViewById(R.id.btn_prevention).setOnClickListener(v -> {
            Intent intent = new Intent(LungResultActivity.this, LungPreventionActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.btn_back_dashboard).setOnClickListener(v -> finish());
        findViewById(R.id.btn_back_header).setOnClickListener(v -> finish());
    }
}
