package com.simats.safe_pulse;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DailyTrackerActivity extends AppCompatActivity {

    private TextView textDate;
    private TextView statWater, statWeight, statSteps;
    private TextView btnSmokeFree, btnSmoked;
    private EditText inputWater, inputWeight, inputSteps, inputSleep, inputCalories, inputSystolic, inputDiastolic;
    private TextView btnWater25, btnWater50, btnWater100;
    private TextView textWaterPercent;
    private ProgressBar progressWater;
    private Button btnSave;

    private boolean isSmoked = false;
    private float currentWater = 0.0f;
    private final float WATER_GOAL = 2.5f;

    private String currentDateStr;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_daily_tracker);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        prefs = getSharedPreferences("DailyTrackerPrefs", Context.MODE_PRIVATE);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US); // Use US locale for API dates
        currentDateStr = sdf.format(new Date());

        initViews();
        setupListeners();
        loadData();
        
        // Sync from server to get latest data (e.g. if updated on web)
        RetrofitClient.getApiService(this).getSyncData().enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    java.util.List<java.util.Map<String, Object>> trackerData = (java.util.List<java.util.Map<String, Object>>) response.body().get("tracker");
                    if (trackerData != null) {
                        saveSyncedTrackerData(trackerData);
                        loadData(); // Refresh UI with synced data
                    }
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                // Keep local data on failure
            }
        });
    }

    private void saveSyncedTrackerData(java.util.List<java.util.Map<String, Object>> trackerData) {
        SharedPreferences.Editor editor = prefs.edit();
        for (java.util.Map<String, Object> log : trackerData) {
            String date = (String) log.get("date");
            if (date == null) continue;
            
            if (log.containsKey("water")) editor.putFloat(date + "_water", ((Number)log.get("water")).floatValue());
            if (log.containsKey("steps")) editor.putString(date + "_steps", String.valueOf(log.get("steps")));
            if (log.containsKey("sleep")) editor.putString(date + "_sleep", String.valueOf(log.get("sleep")));
            if (log.containsKey("weight")) editor.putString(date + "_weight", String.valueOf(log.get("weight")));
            if (log.containsKey("calories")) editor.putString(date + "_calories", String.valueOf(log.get("calories")));
            if (log.containsKey("systolic")) editor.putString(date + "_systolic", String.valueOf(log.get("systolic")));
            if (log.containsKey("diastolic")) editor.putString(date + "_diastolic", String.valueOf(log.get("diastolic")));
            if (log.containsKey("smoked")) editor.putBoolean(date + "_smoked", (Boolean)log.get("smoked"));
        }
        editor.apply();
    }

    private void initViews() {
        textDate = findViewById(R.id.text_date);
        statWater = findViewById(R.id.stat_water);
        statWeight = findViewById(R.id.stat_weight);
        statSteps = findViewById(R.id.stat_steps);

        btnSmokeFree = findViewById(R.id.btn_smokefree);
        btnSmoked = findViewById(R.id.btn_smoked);

        inputWater = findViewById(R.id.input_water);
        btnWater25 = findViewById(R.id.btn_water_25);
        btnWater50 = findViewById(R.id.btn_water_50);
        btnWater100 = findViewById(R.id.btn_water_100);
        textWaterPercent = findViewById(R.id.text_water_percent);
        progressWater = findViewById(R.id.progress_water);

        inputWeight = findViewById(R.id.input_weight);
        inputSteps = findViewById(R.id.input_steps);
        inputSleep = findViewById(R.id.input_sleep);
        inputCalories = findViewById(R.id.input_calories);
        inputSystolic = findViewById(R.id.input_systolic);
        inputDiastolic = findViewById(R.id.input_diastolic);

        btnSave = findViewById(R.id.btn_save_progress);
        LinearLayout btnBack = findViewById(R.id.btn_back_header);

        btnBack.setOnClickListener(v -> finish());

        SimpleDateFormat displaySdf = new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault());
        textDate.setText(displaySdf.format(new Date()));
    }

    private void setupListeners() {
        // Smoking Toggle
        btnSmokeFree.setOnClickListener(v -> setSmokingStatus(false));
        btnSmoked.setOnClickListener(v -> setSmokingStatus(true));

        // Water Buttons
        btnWater25.setOnClickListener(v -> addWater(0.25f));
        btnWater50.setOnClickListener(v -> addWater(0.5f));
        btnWater100.setOnClickListener(v -> addWater(1.0f));

        inputWater.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                try {
                    currentWater = Float.parseFloat(s.toString());
                    updateWaterUI();
                } catch (NumberFormatException e) {
                    currentWater = 0.0f;
                    updateWaterUI();
                }
            }
        });

        // Quick Stats Updates
        inputWeight.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                statWeight.setText(s.toString().isEmpty() ? "--kg" : s.toString() + "kg");
            }
        });

        inputSteps.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                statSteps.setText(s.toString().isEmpty() ? "--" : s.toString());
            }
        });

        // Save Button
        btnSave.setOnClickListener(v -> saveData());
    }

    private void addWater(float amount) {
        currentWater += amount;
        inputWater.setText(String.format(Locale.US, "%.2f", currentWater));
    }

    private void updateWaterUI() {
        statWater.setText(String.format(Locale.US, "%.1fL", currentWater));
        int percent = (int) ((currentWater / WATER_GOAL) * 100);
        if (percent > 100) percent = 100;
        progressWater.setProgress(percent);
        textWaterPercent.setText(percent + "%");
    }

    private void setSmokingStatus(boolean smoked) {
        isSmoked = smoked;
        if (!smoked) {
            btnSmokeFree.setBackgroundResource(R.drawable.bg_pill_button_blue);
            btnSmokeFree.setTextColor(Color.parseColor("#1E88E5"));
            btnSmoked.setBackgroundResource(R.drawable.bg_pill_button);
            btnSmoked.setTextColor(Color.parseColor("#64748B"));
        } else {
            btnSmoked.setBackgroundResource(R.drawable.bg_pill_button_blue); // Using blue as active color or can create orange
            btnSmoked.setTextColor(Color.parseColor("#1E88E5"));
            btnSmokeFree.setBackgroundResource(R.drawable.bg_pill_button);
            btnSmokeFree.setTextColor(Color.parseColor("#64748B"));
        }
    }

    private void loadData() {
        isSmoked = prefs.getBoolean(currentDateStr + "_smoked", false);
        setSmokingStatus(isSmoked);

        float water = prefs.getFloat(currentDateStr + "_water", 0.0f);
        if (water > 0) inputWater.setText(String.format(Locale.US, "%.2f", water));

        String weight = prefs.getString(currentDateStr + "_weight", "");
        if (!weight.isEmpty()) inputWeight.setText(weight);

        String steps = prefs.getString(currentDateStr + "_steps", "");
        if (!steps.isEmpty()) inputSteps.setText(steps);

        String sleep = prefs.getString(currentDateStr + "_sleep", "");
        if (!sleep.isEmpty()) inputSleep.setText(sleep);

        String calories = prefs.getString(currentDateStr + "_calories", "");
        if (!calories.isEmpty()) inputCalories.setText(calories);

        String systolic = prefs.getString(currentDateStr + "_systolic", "");
        if (!systolic.isEmpty()) inputSystolic.setText(systolic);

        String diastolic = prefs.getString(currentDateStr + "_diastolic", "");
        if (!diastolic.isEmpty()) inputDiastolic.setText(diastolic);
    }

    private void saveData() {
        SharedPreferences.Editor editor = prefs.edit();
        
        editor.putBoolean(currentDateStr + "_smoked", isSmoked);
        editor.putFloat(currentDateStr + "_water", currentWater);
        String weightStr = inputWeight.getText().toString();
        String stepsStr = inputSteps.getText().toString();
        String sleepStr = inputSleep.getText().toString();
        String calStr = inputCalories.getText().toString();
        String sysStr = inputSystolic.getText().toString();
        String diaStr = inputDiastolic.getText().toString();

        editor.putString(currentDateStr + "_weight", weightStr);
        editor.putString(currentDateStr + "_steps", stepsStr);
        editor.putString(currentDateStr + "_sleep", sleepStr);
        editor.putString(currentDateStr + "_calories", calStr);
        editor.putString(currentDateStr + "_systolic", sysStr);
        editor.putString(currentDateStr + "_diastolic", diaStr);

        editor.apply();
        
        // Update Health Score based on Daily Tracker
        int dailyScore = HealthScoreManager.getDailyTrackerScore(this);
        String status = dailyScore > 80 ? "Excellent" : dailyScore > 50 ? "Moderate" : "Needs Improvement";

        try {
            org.json.JSONObject details = new org.json.JSONObject();
            details.put("water", currentWater);
            details.put("weight", weightStr);
            details.put("steps", stepsStr);
            details.put("sleep", sleepStr);
            details.put("calories", calStr);
            details.put("systolic", sysStr);
            details.put("diastolic", diaStr);
            details.put("smoked", isSmoked);
            
            HealthScoreManager.saveModuleScore(this, "daily_tracker", dailyScore, status, details.toString());
        } catch (org.json.JSONException e) {
            HealthScoreManager.saveModuleScore(this, "DailyTracker", dailyScore, status);
        }
        
        // Sync with Backend via specialized Tracker endpoint
        TrackerRequest trackerRequest = new TrackerRequest();
        trackerRequest.setDate(currentDateStr); // REQUIRED for sync
        trackerRequest.setWater(currentWater);
        trackerRequest.setSmoked(isSmoked);
        try {
            trackerRequest.setSteps(Integer.parseInt(stepsStr.isEmpty() ? "0" : stepsStr));
            trackerRequest.setSleep(Float.parseFloat(sleepStr.isEmpty() ? "0" : sleepStr));
            trackerRequest.setCalories(Integer.parseInt(calStr.isEmpty() ? "0" : calStr));
            trackerRequest.setWeight(Float.parseFloat(weightStr.isEmpty() ? "0" : weightStr));
            trackerRequest.setSystolic(Integer.parseInt(sysStr.isEmpty() ? "0" : sysStr));
            trackerRequest.setDiastolic(Integer.parseInt(diaStr.isEmpty() ? "0" : diaStr));
            trackerRequest.setScore(dailyScore);
        } catch (Exception e) {
            android.util.Log.e("SYNC", "Error parsing tracker data", e);
        }

        HealthScoreManager.syncTrackerWithBackend(this, trackerRequest);
        
        Toast.makeText(this, "Progress saved! Daily Score: " + dailyScore + "%", Toast.LENGTH_SHORT).show();
        finish();
    }

    private abstract class SimpleTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}
    }
}
