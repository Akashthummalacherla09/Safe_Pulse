package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.Button;
import android.graphics.Color;
import android.content.res.ColorStateList;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AdminDashboardActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private TextView tvTotalUsers, tvTotalReports, tvTotalCritical, tvActiveToday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_dashboard);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.btn_admin_logout).setOnClickListener(v -> {
            finish(); // Go back to login or role selection
        });
        
        findViewById(R.id.btn_admin_export).setOnClickListener(v -> AdminPDFGenerator.exportPlatformSummary(this));

        findViewById(R.id.card_user_management).setOnClickListener(v -> {
            startActivity(new Intent(this, UserManagementActivity.class));
        });

        findViewById(R.id.card_all_reports).setOnClickListener(v -> {
            startActivity(new Intent(this, AllReportsActivity.class));
        });

        findViewById(R.id.card_analytics).setOnClickListener(v -> {
            startActivity(new Intent(this, AnalyticsDashboardActivity.class));
        });

        findViewById(R.id.card_trends).setOnClickListener(v -> {
            startActivity(new Intent(this, PlatformTrendsActivity.class));
        });

        loadCriticalAlerts();
        setupStats();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStats();
        loadCriticalAlerts();
    }

    private void setupStats() {
        dbHelper = new DatabaseHelper(this);
        
        tvTotalUsers = findViewById(R.id.admin_total_users);
        tvTotalReports = findViewById(R.id.admin_total_reports);
        tvTotalCritical = findViewById(R.id.admin_total_critical);
        tvActiveToday = findViewById(R.id.admin_active_today);

        refreshStats();
    }

    private void refreshStats() {
        RetrofitClient.getApiService(this).getSyncData().enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    java.util.Map<String, Object> data = response.body();
                    
                    Double totalUsers = (Double) data.get("total_users");
                    Double totalReports = (Double) data.get("total_assessments");
                    Double totalCritical = (Double) data.get("critical_alerts");
                    Double activeToday = (Double) data.get("active_today");

                    if (totalUsers != null) tvTotalUsers.setText(String.format("%,d", totalUsers.intValue()));
                    if (totalReports != null) tvTotalReports.setText(String.format("%,d", totalReports.intValue()));
                    if (totalCritical != null) tvTotalCritical.setText(String.valueOf(totalCritical.intValue()));
                    if (activeToday != null) tvActiveToday.setText(String.valueOf(activeToday.intValue()));
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                // Fallback to local DB on failure
                if (dbHelper != null) {
                    tvTotalUsers.setText(String.format("%,d", dbHelper.getTotalUsers()));
                    tvTotalReports.setText(String.format("%,d", dbHelper.getTotalReports()));
                }
            }
        });
    }

    private void loadCriticalAlerts() {
        LinearLayout container = findViewById(R.id.admin_alerts_container);
        
        RetrofitClient.getApiService(this).getSyncData().enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    container.removeAllViews();
                    java.util.List<java.util.Map<String, Object>> alerts = (java.util.List<java.util.Map<String, Object>>) response.body().get("alerts");
                    
                    if (alerts != null && !alerts.isEmpty()) {
                        for (java.util.Map<String, Object> a : alerts) {
                            String module = (String) a.get("assessment_type");
                            String risk = (String) a.get("result");
                            String userName = (String) a.get("userName");
                            String time = (String) a.get("timestamp");

                            String color = (risk != null && risk.contains("Critical")) ? "#EF4444" : "#F59E0B";
                            int bg = (risk != null && risk.contains("Critical")) ? R.drawable.bg_alert_card_red : R.drawable.bg_alert_card_orange;
                            
                            addAlertItem(container, risk + ": " + module, "User: " + userName + " • " + time, color, bg);
                        }
                    } else {
                        showNoAlerts(container);
                    }
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                // Local fallback logic
                showNoAlerts(container);
            }
        });
    }

    private void showNoAlerts(LinearLayout container) {
        container.removeAllViews();
        TextView noData = new TextView(AdminDashboardActivity.this);
        noData.setText("No critical or high risk alerts at the moment.");
        noData.setTextColor(Color.parseColor("#64748B"));
        noData.setPadding(32, 32, 32, 32);
        noData.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        container.addView(noData);
    }

    private void addAlertItem(LinearLayout container, String title, String subtitle, String colorHex, int backgroundDrawable) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_admin_alert, container, false);
        
        LinearLayout bg = view.findViewById(R.id.layout_alert_bg);
        ImageView icon = view.findViewById(R.id.alert_icon);
        TextView textTitle = view.findViewById(R.id.alert_title);
        TextView textSubtitle = view.findViewById(R.id.alert_subtitle);
        Button btnView = view.findViewById(R.id.btn_alert_view);
        
        bg.setBackgroundResource(backgroundDrawable);
        textTitle.setText(title);
        textSubtitle.setText(subtitle);
        icon.setColorFilter(Color.parseColor(colorHex));
        btnView.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorHex)));

        btnView.setOnClickListener(v -> {
            Toast.makeText(this, "Reviewing: " + title, Toast.LENGTH_SHORT).show();
        });

        container.addView(view);
    }
}
