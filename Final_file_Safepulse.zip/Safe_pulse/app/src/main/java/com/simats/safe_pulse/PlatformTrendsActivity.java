package com.simats.safe_pulse;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PlatformTrendsActivity extends AppCompatActivity {

    private LinearLayout growthContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_platform_trends);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        growthContainer = findViewById(R.id.trends_growth_container);
        findViewById(R.id.btn_back_to_dashboard_trends).setOnClickListener(v -> finish());

        loadMockTrends();
    }

    private void loadMockTrends() {
        RetrofitClient.getApiService(this).getSyncData().enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    growthContainer.removeAllViews();
                    java.util.List<java.util.Map<String, Object>> trends = (java.util.List<java.util.Map<String, Object>>) response.body().get("trends");
                    
                    if (trends != null) {
                        for (java.util.Map<String, Object> t : trends) {
                            String m = (String) t.get("m");
                            int u = ((Double) t.get("u")).intValue();
                            int a = ((Double) t.get("a")).intValue();
                            int up = ((Double) t.get("up")).intValue();
                            int ap = ((Double) t.get("ap")).intValue();
                            
                            addGrowthItem(m, u, a, up, ap);
                        }
                    }
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                // Keep empty or show error
            }
        });
    }

    private void addGrowthItem(String month, int users, int assessments, int userProg, int assessProg) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_trend_growth, growthContainer, false);

        TextView monthTxt = view.findViewById(R.id.trend_month_name);
        TextView userTxt = view.findViewById(R.id.trend_user_count);
        TextView assessTxt = view.findViewById(R.id.trend_assessment_count);
        ProgressBar userBar = view.findViewById(R.id.progress_users);
        ProgressBar assessBar = view.findViewById(R.id.progress_assessments);

        monthTxt.setText(month);
        userTxt.setText(String.valueOf(users));
        
        // Shorten assessment count if large
        if (assessments >= 1000) {
            assessTxt.setText(String.format("%.1f k", assessments / 1000.0));
        } else {
            assessTxt.setText(String.valueOf(assessments));
        }
        
        userBar.setProgress(userProg);
        assessBar.setProgress(assessProg);

        growthContainer.addView(view);
    }
}
