package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class VerifyOtpActivity extends AppCompatActivity {

    private EditText otpInput;
    private Button btnVerify;
    private TextView btnResend;
    private LinearLayout btnBack;
    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_otp);

        email = getIntent().getStringExtra("EMAIL");

        initViews();
        setupListeners();
    }

    private void initViews() {
        otpInput = findViewById(R.id.input_otp);
        btnVerify = findViewById(R.id.btn_verify);
        btnResend = findViewById(R.id.btn_resend);
        btnBack = findViewById(R.id.btn_back);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnVerify.setOnClickListener(v -> {
            String otp = otpInput.getText().toString().trim();
            if (otp.length() < 6) {
                Toast.makeText(this, "Please enter 6-digit code", Toast.LENGTH_SHORT).show();
            } else {
                // Navigate to Create New Password
                Intent intent = new Intent(this, CreateNewPasswordActivity.class);
                intent.putExtra("EMAIL", email);
                intent.putExtra("OTP", otp);
                startActivity(intent);
            }
        });

        btnResend.setOnClickListener(v -> {
            // logic to resend otp
            Toast.makeText(this, "OTP Resent", Toast.LENGTH_SHORT).show();
        });
    }
}
