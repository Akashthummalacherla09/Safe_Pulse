package com.simats.safe_pulse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.PUT;
import retrofit2.http.DELETE;
import java.util.List;
import java.util.Map;

public interface ApiService {
    @POST("login/")
    Call<LoginResponse> login(@Body LoginRequest loginRequest);

    @POST("reset-password/")
    Call<Void> resetPassword(@Body PasswordResetRequest resetRequest);

    @POST("register/")
    Call<java.util.Map<String, Object>> register(@Body java.util.Map<String, Object> registerRequest);

    @GET("patients/")
    Call<List<java.util.Map<String, Object>>> getPatients();

    @POST("patients/")
    Call<java.util.Map<String, Object>> createPatient(@Body java.util.Map<String, Object> patientData);

    @GET("assessments/")
    Call<List<java.util.Map<String, Object>>> getAssessments();

    @POST("assessments/")
    Call<java.util.Map<String, Object>> createAssessment(@Body java.util.Map<String, Object> assessmentData);

    @GET("clinical-data/")
    Call<List<java.util.Map<String, Object>>> getClinicalData();

    @POST("clinical-data/")
    Call<java.util.Map<String, Object>> createClinicalData(@Body java.util.Map<String, Object> clinicalData);

    @POST("sync/")
    Call<java.util.Map<String, Object>> syncData(@Body java.util.Map<String, Object> syncData);
    
    @GET("sync/")
    Call<java.util.Map<String, Object>> getSyncData();
    
    @GET("tracker/")
    Call<List<java.util.Map<String, Object>>> getTracker();

    @POST("tracker/")
    Call<java.util.Map<String, Object>> createTracker(@Body TrackerRequest trackerData);

    @PUT("profile/")
    Call<java.util.Map<String, Object>> updateProfile(@Body java.util.Map<String, Object> profileData);
    
    @GET("profile/")
    Call<java.util.Map<String, Object>> getProfile();

    @GET("admin/users/")
    Call<List<UserResponse>> getUsers();

    @GET("admin/reports/")
    Call<List<java.util.Map<String, Object>>> getAdminReports();

    @DELETE("admin/users/{id}/delete/")
    Call<Void> deleteUser(@retrofit2.http.Path("id") int id);

    @POST("check-email/")
    Call<java.util.Map<String, Object>> checkEmail(@Body java.util.Map<String, String> emailRequest);
}
