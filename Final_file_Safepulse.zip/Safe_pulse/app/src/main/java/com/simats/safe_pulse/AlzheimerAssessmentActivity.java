package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AlzheimerAssessmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_alzheimer_assessment);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView backHeaderButton = findViewById(R.id.btn_back_header);
        Button startButton = findViewById(R.id.btn_start_alz);
        Button backDashboardButton = findViewById(R.id.btn_back_dashboard);

        // Click Listeners
        backHeaderButton.setOnClickListener(v -> finish());
        backDashboardButton.setOnClickListener(v -> finish());

        startButton.setOnClickListener(v -> {
            Intent intent = new Intent(AlzheimerAssessmentActivity.this, AlzheimerInputActivity.class);
            startActivity(intent);
        });
    }
}
