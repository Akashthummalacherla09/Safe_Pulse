package com.simats.safe_pulse;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "SafePulse.db";
    private static final int DATABASE_VERSION = 5;

    // Users Table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USER_NAME = "name";
    private static final String COLUMN_USER_EMAIL = "email";
    private static final String COLUMN_USER_PHONE = "phone";
    private static final String COLUMN_USER_PASSWORD = "password";
    private static final String COLUMN_USER_DOB = "dob";
    private static final String COLUMN_USER_GENDER = "gender";
    private static final String COLUMN_USER_ADDRESS = "address";
    private static final String COLUMN_USER_EMERGENCY_CONTACT = "emergency_contact";
    private static final String COLUMN_USER_CREATED_AT = "created_at";

    // Reports Table
    private static final String TABLE_REPORTS = "reports";
    private static final String COLUMN_REPORT_ID = "id";
    private static final String COLUMN_REPORT_USER_ID = "user_id";
    private static final String COLUMN_REPORT_MODULE = "module";
    private static final String COLUMN_REPORT_SCORE = "score";
    private static final String COLUMN_REPORT_RISK = "risk";
    private static final String COLUMN_REPORT_DETAILS = "details";
    private static final String COLUMN_REPORT_TIMESTAMP = "timestamp";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_NAME + " TEXT,"
                + COLUMN_USER_EMAIL + " TEXT UNIQUE,"
                + COLUMN_USER_PHONE + " TEXT,"
                + COLUMN_USER_PASSWORD + " TEXT,"
                + COLUMN_USER_DOB + " TEXT,"
                + COLUMN_USER_GENDER + " TEXT,"
                + COLUMN_USER_ADDRESS + " TEXT,"
                + COLUMN_USER_EMERGENCY_CONTACT + " TEXT,"
                + COLUMN_USER_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                + ")";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_REPORTS_TABLE = "CREATE TABLE " + TABLE_REPORTS + "("
                + COLUMN_REPORT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_REPORT_USER_ID + " INTEGER,"
                + COLUMN_REPORT_MODULE + " TEXT,"
                + COLUMN_REPORT_SCORE + " INTEGER,"
                + COLUMN_REPORT_RISK + " TEXT,"
                + COLUMN_REPORT_DETAILS + " TEXT,"
                + COLUMN_REPORT_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                + ")";
        db.execSQL(CREATE_REPORTS_TABLE);
        
        // No mock data - using purely real time info
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REPORTS);
        onCreate(db);
    }

    // Removed addMockData() per request for strictly real-time analytics.

    public long addUser(String name, String email, String phone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, name);
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_USER_PHONE, phone);
        values.put(COLUMN_USER_PASSWORD, password);
        return db.insert(TABLE_USERS, null, values);
    }

    public boolean updateUser(int userId, String name, String email, String phone, String dob, String gender, String address, String emergency) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, name);
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_USER_PHONE, phone);
        values.put(COLUMN_USER_DOB, dob);
        values.put(COLUMN_USER_GENDER, gender);
        values.put(COLUMN_USER_ADDRESS, address);
        values.put(COLUMN_USER_EMERGENCY_CONTACT, emergency);
        int rows = db.update(TABLE_USERS, values, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        return rows > 0;
    }

    public boolean updatePassword(String email, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_PASSWORD, newPassword);
        int rows = db.update(TABLE_USERS, values, COLUMN_USER_EMAIL + " = ?", new String[]{email});
        return rows > 0;
    }

    public void addReport(int userId, String module, int score, String risk) {
        addReport(userId, module, score, risk, null);
    }

    public void addReport(int userId, String module, int score, String risk, String details) {
        addReportUnique(userId, module, score, risk, details, null);
    }

    public void addReportUnique(int userId, String module, int score, String risk, String details, String timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        // Smarter duplicate check to prevent local/server duplicates
        String query;
        String[] args;
        
        if (timestamp != null) {
            // SYNC MODE: Check if an exact match exists OR a fuzzy match (same user, module, score within 1 hour)
            query = "SELECT id FROM " + TABLE_REPORTS + " WHERE " + COLUMN_REPORT_USER_ID + " = ? AND " + COLUMN_REPORT_MODULE + " = ? AND (" + COLUMN_REPORT_TIMESTAMP + " = ? OR (abs(strftime('%s', " + COLUMN_REPORT_TIMESTAMP + ") - strftime('%s', ?)) < 3600 AND " + COLUMN_REPORT_SCORE + " = ?))";
            args = new String[]{String.valueOf(userId), module, timestamp, timestamp, String.valueOf(score)};
        } else {
            // LOCAL MODE: Check if we just saved this in the last minute (avoid double clicks)
            query = "SELECT id FROM " + TABLE_REPORTS + " WHERE " + COLUMN_REPORT_USER_ID + " = ? AND " + COLUMN_REPORT_MODULE + " = ? AND " + COLUMN_REPORT_SCORE + " = ? AND " + COLUMN_REPORT_TIMESTAMP + " >= datetime('now', '-1 minute')";
            args = new String[]{String.valueOf(userId), module, String.valueOf(score)};
        }

        Cursor cursor = db.rawQuery(query, args);
        if (cursor.moveToFirst()) {
            // If it's a sync update (timestamp != null), update the existing record's timestamp to the server's canonical one
            if (timestamp != null) {
                int id = cursor.getInt(0);
                ContentValues v = new ContentValues();
                v.put(COLUMN_REPORT_TIMESTAMP, timestamp);
                db.update(TABLE_REPORTS, v, "id = ?", new String[]{String.valueOf(id)});
            }
            cursor.close();
            return; // Duplicate found and handled
        }
        cursor.close();

        ContentValues values = new ContentValues();
        values.put(COLUMN_REPORT_USER_ID, userId);
        values.put(COLUMN_REPORT_MODULE, module);
        values.put(COLUMN_REPORT_SCORE, score);
        values.put(COLUMN_REPORT_RISK, risk);
        values.put(COLUMN_REPORT_DETAILS, details);
        if (timestamp != null) {
            values.put(COLUMN_REPORT_TIMESTAMP, timestamp);
        }
        db.insert(TABLE_REPORTS, null, values);
    }

    public void deleteUser(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_USERS, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        deleteReportsByUserId(userId);
    }

    public void deleteReportsByUserId(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_REPORTS, COLUMN_REPORT_USER_ID + " = ?", new String[]{String.valueOf(userId)});
    }

    public int getTotalUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_USERS, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getTotalReports() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_REPORTS, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getCriticalReports() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(DISTINCT " + COLUMN_REPORT_USER_ID + ") FROM " + TABLE_REPORTS + " WHERE " + COLUMN_REPORT_RISK + " = 'Critical'", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getActiveToday() {
        SQLiteDatabase db = this.getReadableDatabase();
        // Simplified "active today" as reports created in last 24h
        Cursor cursor = db.rawQuery("SELECT COUNT(DISTINCT " + COLUMN_REPORT_USER_ID + ") FROM " + TABLE_REPORTS + " WHERE " + COLUMN_REPORT_TIMESTAMP + " >= date('now')", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " ORDER BY " + COLUMN_USER_NAME + " ASC", null);

        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(cursor.getInt(0));
                user.setName(cursor.getString(1));
                user.setEmail(cursor.getString(2));
                user.setPhone(cursor.getString(3));
                user.setDob(cursor.getString(5));
                user.setGender(cursor.getString(6));
                user.setAddress(cursor.getString(7));
                user.setEmergencyContact(cursor.getString(8));
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return userList;
    }

    public int getUserReportsCount(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_REPORTS + " WHERE " + COLUMN_REPORT_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public User getUserById(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE id = ?", new String[]{String.valueOf(userId)});
        User user = null;
        if (cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)));
            user.setName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NAME)));
            user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_EMAIL)));
            user.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_PHONE)));
            
            // Check if new columns exist (to handle potential migration edge cases)
            int dobIdx = cursor.getColumnIndex(COLUMN_USER_DOB);
            if (dobIdx != -1) user.setDob(cursor.getString(dobIdx));
            
            int genderIdx = cursor.getColumnIndex(COLUMN_USER_GENDER);
            if (genderIdx != -1) user.setGender(cursor.getString(genderIdx));
            
            int addressIdx = cursor.getColumnIndex(COLUMN_USER_ADDRESS);
            if (addressIdx != -1) user.setAddress(cursor.getString(addressIdx));
            
            int emergencyIdx = cursor.getColumnIndex(COLUMN_USER_EMERGENCY_CONTACT);
            if (emergencyIdx != -1) user.setEmergencyContact(cursor.getString(emergencyIdx));
        }
        cursor.close();
        return user;
    }

    public boolean checkUserExistsByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_USERS + " WHERE " + COLUMN_USER_EMAIL + " = ?", new String[]{email});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    public int getUserCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_USERS, null);
        int count = 0;
        if (cursor.moveToFirst()) count = cursor.getInt(0);
        cursor.close();
        return count;
    }

    public int getReportCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_REPORTS, null);
        int count = 0;
        if (cursor.moveToFirst()) count = cursor.getInt(0);
        cursor.close();
        return count;
    }

    public java.util.Map<String, Integer> getModuleDistribution() {
        java.util.Map<String, Integer> map = new java.util.HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_REPORT_MODULE + ", COUNT(*) FROM " + TABLE_REPORTS + " GROUP BY " + COLUMN_REPORT_MODULE, null);
        if (cursor.moveToFirst()) {
            do {
                map.put(cursor.getString(0), cursor.getInt(1));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return map;
    }

    public java.util.Map<String, Integer> getRiskDistribution() {
        java.util.Map<String, Integer> map = new java.util.HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_REPORT_RISK + ", COUNT(*) FROM " + TABLE_REPORTS + " GROUP BY " + COLUMN_REPORT_RISK, null);
        if (cursor.moveToFirst()) {
            do {
                map.put(cursor.getString(0), cursor.getInt(1));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return map;
    }

    public List<ReportWithUser> getAllReportsWithUserDetails() {
        List<ReportWithUser> reports = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT r.*, u.name FROM " + TABLE_REPORTS + " r JOIN " + TABLE_USERS + " u ON r." + COLUMN_REPORT_USER_ID + " = u.id ORDER BY r." + COLUMN_REPORT_TIMESTAMP + " DESC";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                ReportWithUser report = new ReportWithUser();
                report.setId(cursor.getInt(0));
                report.setModule(cursor.getString(2));
                report.setScore(cursor.getInt(3));
                report.setRisk(cursor.getString(4));
                report.setTimestamp(cursor.getString(5));
                report.setUserName(cursor.getString(6));
                reports.add(report);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return reports;
    }

    public List<Report> getReportsByUserId(int userId) {
        List<Report> reports = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_REPORTS + " WHERE user_id = ? ORDER BY timestamp DESC", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            do {
                Report report = new Report();
                report.setId(cursor.getInt(0));
                report.setModule(cursor.getString(2));
                report.setScore(cursor.getInt(3));
                report.setRisk(cursor.getString(4));
                report.setDetails(cursor.getString(5));
                report.setTimestamp(cursor.getString(6));
                reports.add(report);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return reports;
    }

    public Report getReportById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_REPORTS, null, COLUMN_REPORT_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
        
        if (cursor != null && cursor.moveToFirst()) {
            Report report = new Report();
            report.setId(cursor.getInt(0));
            report.setModule(cursor.getString(2));
            report.setScore(cursor.getInt(3));
            report.setRisk(cursor.getString(4));
            report.setDetails(cursor.getString(5));
            report.setTimestamp(cursor.getString(6));
            cursor.close();
            return report;
        }
        if (cursor != null) cursor.close();
        return null;
    }

    public static class ReportWithUser extends Report {
        private String userName;
        public String getUserName() { return userName; }
        public void setUserName(String userName) { this.userName = userName; }
    }

    public static class Report {
        private int id;
        private String module;
        private int score;
        private String risk;
        private String details;
        private String timestamp;

        public int getId() { return id; }
        public void setId(int id) { this.id = id; }
        public String getModule() { return module; }
        public void setModule(String module) { this.module = module; }
        public int getScore() { return score; }
        public void setScore(int score) { this.score = score; }
        public String getRisk() { return risk; }
        public void setRisk(String risk) { this.risk = risk; }
        public String getDetails() { return details; }
        public void setDetails(String details) { this.details = details; }
        public String getTimestamp() { return timestamp; }
        public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    }

    public static class User {
        private int id;
        private String name;
        private String email;
        private String phone;
        private String dob;
        private String gender;
        private String address;
        private String emergencyContact;

        public int getId() { return id; }
        public void setId(int id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
        public String getDob() { return dob; }
        public void setDob(String dob) { this.dob = dob; }
        public String getGender() { return gender; }
        public void setGender(String gender) { this.gender = gender; }
        public String getAddress() { return address; }
        public void setAddress(String address) { this.address = address; }
        public String getEmergencyContact() { return emergencyContact; }
        public void setEmergencyContact(String emergencyContact) { this.emergencyContact = emergencyContact; }
    }
}
