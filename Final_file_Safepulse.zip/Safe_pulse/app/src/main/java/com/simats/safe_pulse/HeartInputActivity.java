package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HeartInputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_heart_input);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView backButton = findViewById(R.id.btn_back);
        Button calculateButton = findViewById(R.id.btn_calculate);
        
        EditText systolicInput = findViewById(R.id.input_systolic);
        EditText diastolicInput = findViewById(R.id.input_diastolic);
        EditText cholesterolInput = findViewById(R.id.input_cholesterol);
        EditText ldlInput = findViewById(R.id.input_ldl);
        EditText sugarInput = findViewById(R.id.input_sugar);
        Spinner ecgSpinner = findViewById(R.id.spinner_ecg);

        // Setup ECG Spinner
        String[] ecgOptions = {"Normal", "Abnormal"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ecgOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ecgSpinner.setAdapter(adapter);

        // Back Logic
        backButton.setOnClickListener(v -> finish());

        // Calculate Logic
        calculateButton.setOnClickListener(v -> {
            String systolic = systolicInput.getText().toString().trim();
            String diastolic = diastolicInput.getText().toString().trim();
            String cholesterol = cholesterolInput.getText().toString().trim();
            String ldl = ldlInput.getText().toString().trim();
            String sugar = sugarInput.getText().toString().trim();
            String ecg = ecgSpinner.getSelectedItem().toString();

            if (systolic.isEmpty() || diastolic.isEmpty() || cholesterol.isEmpty() || ldl.isEmpty() || sugar.isEmpty()) {
                Toast.makeText(this, "Please enter all health metrics", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(HeartInputActivity.this, HeartResultActivity.class);
                intent.putExtra("SYSTOLIC", systolic);
                intent.putExtra("DIASTOLIC", diastolic);
                intent.putExtra("CHOLESTEROL", cholesterol);
                intent.putExtra("LDL", ldl);
                intent.putExtra("SUGAR", sugar);
                intent.putExtra("ECG", ecg);
                startActivity(intent);
            }
        });
    }
}
