package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.SharedPreferences;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.util.Log;

public class LoginActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        dbHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI components
        EditText emailInput = findViewById(R.id.input_email);
        EditText passwordInput = findViewById(R.id.input_password);
        Button signInButton = findViewById(R.id.btn_sign_in);
        Button backButton = findViewById(R.id.btn_back);
        TextView forgotPasswordText = findViewById(R.id.text_forgot_password);
        TextView signUpText = findViewById(R.id.text_sign_up);
        ImageView logoContainer = findViewById(R.id.logo_container);

        // Sign In Button Click
        signInButton.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get role from intent
            String role = getIntent().getStringExtra("ROLE");
            
            if ("ADMIN".equals(role)) {
                // Keep a small local check for safety if needed, or just go to API
                loginWithApi(email, password);
            } else {
                // API Login
                loginWithApi(email, password);
            }
        });
        // Back to Role Selection
        backButton.setOnClickListener(v -> {
            finish(); // Closes Login and returns to Role Selection
        });

        // Forgot Password
        forgotPasswordText.setOnClickListener(v -> {
             startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class));
        });

        // Sign Up
        signUpText.setOnClickListener(v -> {
             Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
             startActivity(intent);
        });
    }

    private void loginWithApi(final String email, String password) {
        LoginRequest request = new LoginRequest(email, password);
        RetrofitClient.getApiService().login(request).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body();
                    
                     // Store Session Data
                    // Clear session to prevent leakage
                    SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
                    prefs.edit().clear().apply();
                    
                    prefs.edit()
                          .putString("AUTH_TOKEN", loginResponse.getToken())
                          .putString("USER_ROLE", loginResponse.getRole())
                          .putString("USER_EMAIL", email)
                          .putString("USER_NAME", loginResponse.getName())
                          .putInt("USER_ID", loginResponse.getUserId())
                          .apply();
                     
                    // Clean start
                    HealthScoreManager.clearUserCache(LoginActivity.this, loginResponse.getUserId());
                    HealthDataRepository.getInstance(LoginActivity.this).clearLocalReports(loginResponse.getUserId());

                    Toast.makeText(LoginActivity.this, "Clinical Login Successful", Toast.LENGTH_SHORT).show();
                    
                    Intent intent;
                    if ("ADMIN".equals(loginResponse.getRole())) {
                        intent = new Intent(LoginActivity.this, AdminDashboardActivity.class);
                    } else {
                        intent = new Intent(LoginActivity.this, UserDashboardActivity.class);
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Authentication Failed: Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e("API_ERROR", "Login failed", t);
                Toast.makeText(LoginActivity.this, "Network Error: Check Server Connectivity", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private int checkUser(String email, String password) {
        android.database.sqlite.SQLiteDatabase db = dbHelper.getReadableDatabase();
        android.database.Cursor cursor = db.rawQuery("SELECT id FROM users WHERE email=? AND password=?", new String[]{email, password});
        int id = -1;
        if (cursor.moveToFirst()) {
            id = cursor.getInt(0);
        }
        cursor.close();
        return id;
    }
}
