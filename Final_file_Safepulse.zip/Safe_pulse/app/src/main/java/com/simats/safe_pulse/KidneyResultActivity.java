package com.simats.safe_pulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class KidneyResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_kidney_result);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        TextView riskLevelText = findViewById(R.id.text_risk_level);
        TextView stageInfoText = findViewById(R.id.text_stage_info);
        TextView explanationText = findViewById(R.id.text_explanation);
        Button preventionButton = findViewById(R.id.btn_prevention);
        Button backDashboardButton = findViewById(R.id.btn_back_dashboard);

        // Get Data from Intent
        String eGFRStr = getIntent().getStringExtra("eGFR");
        String proteinStr = getIntent().getStringExtra("PROTEIN");
        String creatinineStr = getIntent().getStringExtra("CREATININE");
        String ureaStr = getIntent().getStringExtra("UREA");
        
        double gfrValue = 0.0;
        try { gfrValue = Double.parseDouble(eGFRStr); } catch (Exception e) { e.printStackTrace(); }
        boolean isProteinPresent = (proteinStr != null && proteinStr.equals("Present"));
        
        // 🧬 Centralized Scoring Engine (Calculated 1:1 with Web)
        java.util.Map<String, Object> result = AssessmentEngine.calculateKidney(gfrValue, isProteinPresent);
        
        String riskLevelDisplay = (String) result.get("riskLevel");
        String stageLabel = (String) result.get("stage");
        int score = (int) result.get("score");

        // UI Text
        String explanation = riskLevelDisplay.equals("Low") ? "Healthy kidney function." : "Impairment detected.";
        if (riskLevelDisplay.equals("Low")) {
            explanation = "Your kidney function is within normal range. \n\nIndication: Routine checkups with a general physician are sufficient.";
        } else if (riskLevelDisplay.equals("Medium")) {
            explanation = "Your kidney function shows moderate impairment. \n\nIndication: You may want to consult a Nephrologist for a checkup.";
        } else {
            explanation = "Your kidney function is significantly reduced. \n\nURGENT: Please visit a Nephrologist immediately.";
        }

        // 🟢 Standardized Data Struct (Ready for submit_report.php)
        try {
            org.json.JSONObject details = new org.json.JSONObject();
            details.put("gfr", gfrValue);
            details.put("protein_present", isProteinPresent);
            
            try { details.put("creatinine", Double.parseDouble(creatinineStr)); } catch (Exception e) { details.put("creatinine", 0.0); }
            try { details.put("urea", Double.parseDouble(ureaStr)); } catch (Exception e) { details.put("urea", 0.0); }
            
            HealthScoreManager.saveModuleScore(this, "kidney", score, riskLevelDisplay.toLowerCase(), details.toString());
        } catch (org.json.JSONException e) {
            HealthScoreManager.saveModuleScore(this, "kidney", score, riskLevelDisplay.toLowerCase());
        }

        riskLevelText.setText(riskLevelDisplay);
        stageInfoText.setText(stageLabel);
        explanationText.setText(explanation);

        // Navigation
        findViewById(R.id.btn_back_header).setOnClickListener(v -> {
            Intent intent = new Intent(this, UserDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
        
        preventionButton.setOnClickListener(v -> {
            Intent intent = new Intent(KidneyResultActivity.this, KidneyPreventionActivity.class);
            intent.putExtra("RISK_LEVEL", riskLevelDisplay);
            startActivity(intent);
        });

        backDashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, UserDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }
}
