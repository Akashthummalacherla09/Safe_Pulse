package com.simats.safe_pulse;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class UserManagementActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private LinearLayout userListContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_management);
        dbHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        userListContainer = findViewById(R.id.user_list_container);
        findViewById(R.id.btn_back_to_dashboard).setOnClickListener(v -> finish());

        loadUsers();
    }

    private void loadUsers() {
        userListContainer.removeAllViews();
        
        // Attempt to load from API (Backend Database)
        RetrofitClient.getApiService(this).getUsers().enqueue(new retrofit2.Callback<List<UserResponse>>() {
            @Override
            public void onResponse(retrofit2.Call<List<UserResponse>> call, retrofit2.Response<List<UserResponse>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<UserResponse> apiUsers = response.body();
                    for (UserResponse apiUser : apiUsers) {
                        DatabaseHelper.User userObj = new DatabaseHelper.User();
                        userObj.setId(apiUser.getId());
                        userObj.setName(apiUser.getName() != null ? apiUser.getName() : "Unknown");
                        userObj.setEmail(apiUser.getEmail());
                        userObj.setPhone(apiUser.getPhone());
                        userObj.setDob(apiUser.getDob());
                        userObj.setGender(apiUser.getGender());
                        userObj.setAddress(apiUser.getAddress());
                        userObj.setEmergencyContact(apiUser.getEmergencyContact());
                        
                        addUserItem(userObj, apiUser.getReportCount()); 
                    }
                } else {
                    android.util.Log.e("UserManagement", "API Error: " + response.code());
                    loadLocalUsersFallback();
                }
            }

            @Override
            public void onFailure(retrofit2.Call<List<UserResponse>> call, Throwable t) {
                // If network fails, load from SQLite
                loadLocalUsersFallback();
            }
        });
    }

    private void loadLocalUsersFallback() {
        List<DatabaseHelper.User> userList = dbHelper.getAllUsers();

        if (userList == null || userList.isEmpty()) {
            TextView noUsersText = new TextView(this);
            noUsersText.setText("No registered users found.");
            noUsersText.setTextColor(android.graphics.Color.parseColor("#64748B"));
            noUsersText.setPadding(32, 32, 32, 32);
            noUsersText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            userListContainer.addView(noUsersText);
            return;
        }

        for (DatabaseHelper.User user : userList) {
            addUserItem(user, dbHelper.getUserReportsCount(user.getId()));
        }
    }

    private void addUserItem(DatabaseHelper.User user, int reportCount) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_user_management, userListContainer, false);

        TextView initial = view.findViewById(R.id.user_initial);
        TextView name = view.findViewById(R.id.user_name);
        TextView email = view.findViewById(R.id.user_email);
        TextView status = view.findViewById(R.id.user_status);
        TextView reportsCount = view.findViewById(R.id.user_reports_count);
        View btnViewProfile = view.findViewById(R.id.btn_view_profile);

        String firstLetter = (user.getName() != null && !user.getName().trim().isEmpty()) 
                             ? user.getName().trim().substring(0, 1).toUpperCase() 
                             : "U";
        initial.setText(firstLetter);
        name.setText(user.getName());
        email.setText(user.getEmail());
        
        reportsCount.setText(reportCount + " Reports");

        // Delete User Button
        View btnDelete = view.findViewById(R.id.btn_delete_user);
        btnDelete.setOnClickListener(v -> showDeleteConfirmation(user));

        // Simple logic for status (mocked as Active for users with reports)
        if (reportCount > 0) {
            status.setText("Active");
            status.setBackgroundResource(R.drawable.bg_status_active);
            status.setTextColor(android.graphics.Color.parseColor("#10B981"));
        } else {
            status.setText("Inactive");
            status.setBackgroundResource(R.drawable.bg_status_inactive);
            status.setTextColor(android.graphics.Color.parseColor("#64748B"));
        }

        btnViewProfile.setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(this, UserProfileActivity.class);
            intent.putExtra("USER_ID", user.getId());
            intent.putExtra("USER_NAME", user.getName());
            intent.putExtra("USER_EMAIL", user.getEmail());
            intent.putExtra("USER_PHONE", user.getPhone());
            intent.putExtra("USER_DOB", user.getDob());
            intent.putExtra("USER_GENDER", user.getGender());
            intent.putExtra("USER_ADDRESS", user.getAddress());
            intent.putExtra("USER_EMERGENCY", user.getEmergencyContact());
            intent.putExtra("IS_VIEW_ONLY", true); // Pass view-only flag
            startActivity(intent);
        });

        userListContainer.addView(view);
    }

    private void showDeleteConfirmation(DatabaseHelper.User user) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Delete User")
            .setMessage("Are you sure you want to delete " + user.getName() + "? This action cannot be undone.")
            .setPositiveButton("Delete", (dialog, which) -> deleteUser(user))
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void deleteUser(DatabaseHelper.User user) {
        // Delete from API
        RetrofitClient.getApiService(this).deleteUser(user.getId()).enqueue(new retrofit2.Callback<Void>() {
            @Override
            public void onResponse(retrofit2.Call<Void> call, retrofit2.Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(UserManagementActivity.this, "User deleted successfully", Toast.LENGTH_SHORT).show();
                    // Also delete from local (for cleanup)
                    dbHelper.deleteUser(user.getId());
                    loadUsers(); // Refresh list
                } else {
                    Toast.makeText(UserManagementActivity.this, "Failed to delete user from server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(retrofit2.Call<Void> call, Throwable t) {
                // If API fails, try local only or show error
                Toast.makeText(UserManagementActivity.this, "Network error. Could not delete user.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
